#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
explore.py —— 「绕路 Detour」城市长尾探索引擎

做什么：
  给定 城市 + 主题（建筑/动漫/夜游/非遗/美食/自由）+ 可选出发点，
  调用 flyai CLI 拉取候选 POI，算出「小众分」，按 800m 步行半径聚成街区簇，
  输出给 Agent 直接消费的紧凑 JSON / Markdown 简报。

为什么需要它：
  LLM 自己算经纬度距离、做地理聚类不可靠；把确定性计算外置成工具，
  让模型只负责「选、讲、排」，这是本作品的核心工程取舍。

依赖：只要 python3；数据来自 flyai CLI（npm i -g @fly-ai/flyai-cli）

用法：
  python3 explore.py --city 杭州 --theme 夜游 --hours 4 --anchor 武林广场
  python3 explore.py --city 杭州 --theme 建筑 --json-only > cand.json
  FLYAI_BIN=./node_modules/.bin/flyai python3 explore.py --city 成都 --theme 非遗
"""

from __future__ import annotations

import argparse
import json
import math
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.parse
import urllib.request
from typing import Any

FLYAI_BIN = os.environ.get("FLYAI_BIN") or shutil.which("flyai") or "flyai"
TIMEOUT = 60

# 主题 -> 检索用的类目（flyai search-poi 支持的中文类目）
THEMES: dict[str, dict[str, list[str]]] = {
    "建筑": {
        "categories": ["地标建筑", "历史古迹", "人文古迹", "园林花园", "宗教场所"],
        "keywords": ["老建筑", "教堂", "洋房"],
    },
    "夜游": {
        "categories": ["市集", "文创街区", "城市观光", "演出赛事",
                        "剧院剧场", "地标建筑", "历史古迹", "人文古迹"],
        "keywords": ["夜景", "夜市", "livehouse", "酒吧", "老街", "小吃"],
    },
    "非遗": {
        "categories": ["人文古迹", "纪念馆", "博物馆", "文创街区"],
        "keywords": ["非遗", "手作", "作坊"],
    },
    "动漫": {
        "categories": ["文创街区", "展览馆", "市集", "主题乐园"],
        "keywords": ["二次元", "动漫", "手办", "谷子"],
    },
    "美食": {
        "categories": ["市集", "文创街区"],
        "keywords": ["老字号", "小吃", "菜市场"],
    },
    "自由": {
        "categories": ["文创街区", "市集", "博物馆", "公园乐园", "城市观光"],
        "keywords": ["小众", "街区"],
    },
}

# 「长尾类目」加分：这些类目天然比主题乐园/海洋馆更小众
TAIL_CATEGORIES = {
    "市集", "文创街区", "纪念馆", "展览馆", "人文古迹",
    "历史古迹", "园林花园", "公园乐园", "城市观光",
}

# 明显的大众/亲子流量款，且无榜单时也不该被当成「小众」
MASS_TOKENS = ("乐园", "海洋馆", "动物园", "植物园", "水世界", "影视城", "温泉")


CACHE_DIR = os.environ.get("DETOUR_CACHE") or os.path.join(
    os.path.dirname(os.path.abspath(__file__)), ".cache")
POI_TTL = 7 * 24 * 3600
CACHE_TTL = 24 * 3600  # 秒
SLEEP_BETWEEN = float(os.environ.get("DETOUR_SLEEP", "1.2"))
# 飞猪调用间隔：预热/回归时连打 30+ 次会触发风控（HTTP 451），默认放慢到 3.5 s
FLYAI_SLEEP = float(os.environ.get("DETOUR_FLYAI_SLEEP", "1.5"))
STATS = {"calls": 0, "cache_hits": 0, "retries": 0}


def _cache_path(args: list[str]) -> str:
    key = re.sub(r"[^\w\u4e00-\u9fa5-]+", "_", "_".join(args))[:120]
    return os.path.join(CACHE_DIR, key + ".json")


def _cache_get(args: list[str]) -> dict[str, Any] | None:
    p = _cache_path(args)
    try:
        if os.path.exists(p) and (time.time() - os.path.getmtime(p)) < CACHE_TTL:
            with open(p, encoding="utf-8") as f:
                return json.load(f)
    except (OSError, json.JSONDecodeError):
        pass
    return None


def _cache_put(args: list[str], data: dict[str, Any]) -> None:
    try:
        os.makedirs(CACHE_DIR, exist_ok=True)
        with open(_cache_path(args), "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False)
    except OSError:
        pass


FLYAI_READY: dict[str, Any] = {"ok": None, "tried": False, "note": "", "installed": False}


def flyai_ready() -> bool:
    """flyai 是否可用（第一次调用时探测一次并记住）。"""
    if FLYAI_READY["ok"] is None:
        return ensure_flyai(verbose=False)
    return bool(FLYAI_READY["ok"])


def ensure_flyai(verbose: bool = True) -> bool:
    """确保 flyai CLI 可用：没有就装一次，有 Key 就写进它的配置。

    沙箱每次会话都是干净环境，`flyai` 经常不存在——之前因此直接掉进主题库兜底，
    榜单/门票这些「只有飞猪才有」的数据就全丢了。这里先尝试装，装不上才降级。
    """
    global FLYAI_BIN
    if FLYAI_READY["ok"] is not None:
        return bool(FLYAI_READY["ok"])
    FLYAI_READY["tried"] = True

    def log(msg: str) -> None:
        if verbose:
            print(msg, file=sys.stderr)

    path = shutil.which("flyai")
    if not path and os.environ.get("DETOUR_NO_INSTALL") != "1":
        npm = shutil.which("npm")
        if npm:
            log("[info] 没找到 flyai，尝试安装 @fly-ai/flyai-cli …")
            try:
                p = subprocess.run(
                    [npm, "install", "-g", "@fly-ai/flyai-cli",
                     "--registry=https://registry.npmmirror.com"],
                    capture_output=True, text=True, timeout=180)
                if p.returncode == 0:
                    FLYAI_READY["installed"] = True
                    log("[info] flyai 安装完成")
                else:
                    log(f"[warn] flyai 安装失败（exit {p.returncode}）："
                        f"{(p.stderr or p.stdout or '')[-200:]}")
            except (OSError, subprocess.TimeoutExpired) as exc:
                log(f"[warn] flyai 安装超时/异常：{exc}")
            path = shutil.which("flyai")
    if path:
        FLYAI_BIN = path
    else:
        FLYAI_READY["ok"] = False
        FLYAI_READY["note"] = "flyai CLI 不可用（未安装且安装失败）"
        log("[warn] flyai CLI 不可用：飞猪链路跳过，改用高德主题库/缓存兜底")
        return False

    # flyai 没有 --version / config 子命令，认可用性的办法是 `--help` 正常返回
    try:
        h = subprocess.run([FLYAI_BIN, "--help"], capture_output=True,
                           text=True, timeout=20)
        FLYAI_READY["ok"] = h.returncode == 0 and "Usage: flyai" in (h.stdout or "")
    except (OSError, subprocess.TimeoutExpired):
        FLYAI_READY["ok"] = False
    # 和 AMAP_KEY 一样：会话经常忘记注入 FLYAI_API_KEY，没 Key 就掉进「无榜单」。
    # 允许在包内 scripts/flyai_key.txt 放一把默认 Key（部署时放，别提交到公开仓库）。
    if not os.environ.get("FLYAI_API_KEY") and _FLYAI_KEY_DEFAULT:
        os.environ["FLYAI_API_KEY"] = _FLYAI_KEY_DEFAULT
        log("[info] 用包内默认 FLYAI_API_KEY")
    key = os.environ.get("FLYAI_API_KEY")
    FLYAI_READY["key"] = bool(key)
    if FLYAI_READY["ok"] and not key:
        log("[warn] flyai 已就绪，但环境里没有 FLYAI_API_KEY —— 调用可能被拒")
    FLYAI_READY["note"] = ("ok" if FLYAI_READY["ok"] else "flyai --help 失败") + \
        ("｜key ✅" if key else "｜key ❌")
    log(f"[info] flyai: {FLYAI_READY['note']}")
    return bool(FLYAI_READY["ok"])


_FLYAI_LAST: dict[str, float] = {"t": 0.0}


FLYAI_DEAD: dict[str, Any] = {"on": False, "why": ""}
# 飞猪的两道闸：额度（402 / Total usage limit / Trial limit）和行为风控（451 / risk control）。
# 并发打过去最容易被判「不正常」，所以所有 flyai 调用串行 + 抖动。
_FLYAI_LOCK = __import__("threading").Lock()
FLYAI_REASON = {"kind": "", "text": ""}
# 这次运行里哪些数据没拿到、为什么——写进 brief，让回答如实交代，而不是含糊其辞
DATA_ISSUES: list[dict[str, str]] = []


if os.environ.get("DETOUR_NO_FLYAI"):
    FLYAI_DEAD.update(on=True, why="按 DETOUR_NO_FLYAI 关闭飞猪调用")
    FLYAI_REASON["text"] = FLYAI_DEAD["why"]


def note_issue(kind: str, reason: str, impact: str) -> None:
    for it in DATA_ISSUES:
        if it.get("kind") == kind and it.get("reason") == reason:
            return
    DATA_ISSUES.append({"kind": kind, "reason": reason, "impact": impact})


def data_reason_lines() -> list[str]:
    """把「哪块数据没拿到 / 为什么 / 改用了什么」拼成可以直接照抄的人话。

    目标：回答里不许出现「查不到」这种没头没尾的说法，
    必须写清是额度用尽、被风控、还是这一带确实没有。
    """
    out: list[str] = []
    kind = (FLYAI_REASON.get("kind") or "")
    txt = (FLYAI_REASON.get("text") or "").strip()
    if kind == "quota":
        out.append("飞猪接口额度已用尽（HTTP 402，「Total usage limit reached」）")
    elif kind == "trial":
        out.append("飞猪接口试用额度已用尽（「Trial limit reached」）")
    elif kind == "risk":
        out.append("飞猪接口触发风控（HTTP 451，「Abnormal access behavior detected by risk control」）")
    elif FLYAI_DEAD.get("on") and txt:
        out.append(f"飞猪接口不可用（{txt}）")
    for it in DATA_ISSUES:
        out.append(f"{it.get('kind')}：{it.get('reason')} → {it.get('impact')}")
    return out


def _flyai_reason(text: str) -> str:
    """从错误文本里判断是「风控」还是「额度」。

    注意：只认完整短语，不认裸数字。飞猪返回的 JSON 里经纬度、id、价格都可能
    含 "451" / "402"，之前拿整段 JSON 去匹配会误判成风控/额度用尽
    （明明控制台还有 96 次额度，回答却说「额度用尽」就是这么来的）。
    """
    low = (text or "").lower()
    if "risk control" in low or "abnormal access" in low or "forbidden" in low:
        return "risk"
    if "trial limit" in low:
        return "trial"
    if "total usage limit" in low or "usage limit reached" in low or "quota exceeded" in low:
        return "quota"
    return ""


def run_flyai(args: list[str], use_cache: bool = True) -> dict[str, Any] | None:
    """调 flyai CLI 并解析 JSON；带本地缓存 + 429 退避重试。失败返回 None。"""
    if use_cache:
        hit = _cache_get(args)
        if hit is not None:
            STATS["cache_hits"] += 1
            return hit
    if FLYAI_DEAD["on"]:
        return None
    # 懒安装：只走酒店/周边（没走 fetch_pois）的路径以前从不触发 ensure_flyai，
    # 沙箱里 flyai 不存在时会一直报「命令不存在」。这里在第一次真正调用前补一次。
    if FLYAI_READY["ok"] is None:
        ensure_flyai(verbose=False)

    for attempt in range(2):
        # 串行 + 抖动：多线程同时打飞猪是 451 的头号诱因
        with _FLYAI_LOCK:
            _prev = _FLYAI_LAST.get("t", 0.0)
            _gap = time.time() - _prev
            _wait = FLYAI_SLEEP * (0.75 + 0.5 * __import__("random").random())
            if FLYAI_SLEEP > 0 and _gap < _wait:
                time.sleep(_wait - _gap)
            _FLYAI_LAST["t"] = time.time()
        if SLEEP_BETWEEN > 0 and attempt:
            time.sleep(SLEEP_BETWEEN * (1 + attempt * 2))  # 退避
        STATS["calls"] += 1
        _FLYAI_LAST["t"] = time.time()
        try:
            p = subprocess.run([FLYAI_BIN] + args, capture_output=True,
                               text=True, timeout=TIMEOUT)
        except FileNotFoundError:
            # 极端情况：PATH 变了/装完还找不到，强制重装一次再试
            if not attempt and os.environ.get("DETOUR_NO_INSTALL") != "1":
                FLYAI_READY["ok"] = None
                ensure_flyai(verbose=False)
                if shutil.which("flyai"):
                    globals()["FLYAI_BIN"] = shutil.which("flyai")
                continue
            print(f"[warn] flyai 命令不存在，已尝试安装仍失败：{args}", file=sys.stderr)
            return None
        except (OSError, subprocess.TimeoutExpired) as exc:
            print(f"[warn] flyai 调用失败 {args}: {exc}", file=sys.stderr)
            return None
        out = (p.stdout or "").strip()
        err = (p.stderr or "").strip()
        if "429" in err or "Rate limit" in err:
            STATS["retries"] += 1
            continue
        if not out:
            _k = _flyai_reason(err)
            if _k:
                # 风控/额度/试用上限都不是偶发：本次运行内后续调用一样会失败，直接熔断
                if not FLYAI_DEAD["on"]:
                    FLYAI_DEAD["on"] = True
                    _why = {"risk": "飞猪接口被风控（HTTP 451 / risk control）",
                            "trial": "飞猪这个接口的试用额度用尽（Trial limit reached）",
                            "quota": "飞猪调用总额度用尽（HTTP 402 / Total usage limit）"}[_k]
                    FLYAI_DEAD["why"] = _why
                    FLYAI_REASON["kind"], FLYAI_REASON["text"] = _k, _why
                    print(f"[warn] {_why}，本次运行不再重试，改用随包快照 / 缓存",
                          file=sys.stderr)
                return None
            print(f"[warn] flyai 空输出 {args}: {err[:200]}", file=sys.stderr)
            return None
        try:
            data = json.loads(out)
        except json.JSONDecodeError:
            print(f"[warn] flyai 非 JSON 输出 {args}: {out[:160]}", file=sys.stderr)
            return None
        # 只从结构化错误字段判断，绝不再用整段 JSON 去匹配（经纬度/id 里的 451、402 会造成误判）
        _err_txt = ""
        if isinstance(data, dict):
            _err = data.get("error") or data.get("errors") or {}
            _code = data.get("code") or (isinstance(_err, dict) and _err.get("code")) or ""
            _err_txt = f"{_code} {json.dumps(_err, ensure_ascii=False) if isinstance(_err, dict) else _err}".strip()
        _k = _flyai_reason(_err_txt) if _err_txt and not (isinstance(data, dict) and (data.get("data") or {}).get("itemList")) else ""
        if _k:
            if not FLYAI_DEAD["on"]:
                FLYAI_DEAD["on"] = True
                _why = {"risk": "飞猪接口被风控（HTTP 451 / risk control）",
                        "trial": "飞猪这个接口的试用额度用尽（Trial limit reached）",
                        "quota": "飞猪调用总额度用尽（HTTP 402 / Total usage limit）"}[_k]
                FLYAI_DEAD["why"] = _why
                FLYAI_REASON["kind"], FLYAI_REASON["text"] = _k, _why
                print(f"[warn] {_why}，本次运行不再重试，改用随包快照 / 缓存",
                      file=sys.stderr)
            return None
        if use_cache:
            _cache_put(args, data)
        return data

    print(f"[warn] flyai 限流重试仍失败：{args}", file=sys.stderr)
    return None


def _poi_cache_path(city: str, theme: str) -> str:
    return os.path.join(CACHE_DIR, "poi", "%s_%s.json" % (city, theme))


# 随包预热的飞猪 POI 快照（含 listRank）：飞猪被风控/断网时，榜单剔除照常生效
_SELF_DIR = os.path.dirname(os.path.abspath(__file__))
_POI_PACK_CANDS = [
    os.path.join(_SELF_DIR, "data", "poi"),
    os.path.join(os.path.dirname(_SELF_DIR), "data", "poi"),
    os.path.join(_SELF_DIR, "skill-package-engine", "data", "poi"),
]
POI_PACK_DIR = next((d for d in _POI_PACK_CANDS if os.path.isdir(d)), _POI_PACK_CANDS[0])


def _coarse_coord(lat: Any, lng: Any) -> bool:
    """只有两位小数的经纬度（如 30.25000,120.16000）多半是城市级占位，不是这个点的真位置。

    实测：杭州夜游的《西湖东坡》演出 返回 30.25/120.16，落在离剧场 ~700 m 的空地上，
    画到地图上就是一个「凭空出现的站点」。这种点宁可不用。
    """
    try:
        la, ln = float(lat), float(lng)
    except (TypeError, ValueError):
        return False
    for v in (la, ln):
        if abs(v * 100 - round(v * 100)) > 1e-6:
            return False
    return True


def _read_poi_pack(city: str, theme: str) -> list[dict[str, Any]] | None:
    """读随包快照：先同主题，再同城「自由」兜底。"""
    for path in (os.path.join(POI_PACK_DIR, f"{city}_{theme}.json"),
                 os.path.join(POI_PACK_DIR, f"{city}_自由.json")):
        try:
            with open(path, encoding="utf-8") as fh:
                data = json.load(fh)
        except Exception:
            continue
        if data:
            n_hot = sum(1 for it in data if it.get("listRank"))
            print(f"[info] 用随包快照 {os.path.basename(path)}："
                  f"{len(data)} 个点，其中 {n_hot} 个在榜（榜单剔除照常生效）",
                  file=sys.stderr)
            return data
    return None


def _read_poi_cache(city: str, theme: str) -> list[dict[str, Any]] | None:
    p = _poi_cache_path(city, theme)
    try:
        if os.path.exists(p) and time.time() - os.path.getmtime(p) < POI_TTL:
            with open(p, encoding="utf-8") as fh:
                data = json.load(fh)
            if data:
                return data
    except Exception:
        pass
    # 本地缓存过期或不存在 → 退到随包快照（它是「上次抓到的好数据」，不受 TTL 限制）
    return _read_poi_pack(city, theme)


def _write_poi_cache(city: str, theme: str, pois: list[dict[str, Any]]) -> None:
    try:
        p = _poi_cache_path(city, theme)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "w", encoding="utf-8") as fh:
            json.dump(pois, fh, ensure_ascii=False)
    except Exception:
        pass


def fetch_pois(city: str, theme: str) -> list[dict[str, Any]]:
    """按主题拉候选 POI，按 id 去重。

    失败兜底（2026-11 加）：飞猪 POI 接口会触风控返回 HTTP 451 / risk control，
    这时**不能**静默返回空列表（排行榜会退化成「什么都没排除」），必须：
      1. 先落 7 天本地缓存（.cache/poi/<城市>_<主题>.json），命中就直接用；
      2. 全部查询都失败时，读任意主题的同城缓存；
      3. 都没有才交给调用方用高德主题库兜底，并打印醒目告警。
    """
    cfg = THEMES.get(theme, THEMES["自由"])

    # 性能优先：本地 7 天缓存或随包快照命中就直接用，不再打飞猪。
    # 一次 fetch_pois = 8–14 次 CLI 调用（约 40 s），是引擎耗时的大头。
    # 要强制刷新：DETOUR_REFRESH_POI=1
    if not os.environ.get("DETOUR_REFRESH_POI"):
        _cached = _read_poi_cache(city, theme)
        if _cached:
            STATS["poi_src"] = "cache"
            return _cached

    seen: dict[str, dict[str, Any]] = {}
    ok_calls = 0
    fail_calls = 0
    flyai_ok = ensure_flyai()

    for cat in cfg["categories"]:
        if FLYAI_DEAD["on"]:
            break
        d = run_flyai(["search-poi", "--city-name", city, "--category", cat])
        got = ((d or {}).get("data") or {}).get("itemList") or []
        if d is None or (got == [] and (d or {}).get("status") not in (0, None)):
            fail_calls += 1
        else:
            ok_calls += 1
        for it in got:
            _merge(seen, it, f"cat:{cat}")

    for kw in cfg["keywords"]:
        if FLYAI_DEAD["on"]:
            break
        d = run_flyai(["search-poi", "--city-name", city, "--keyword", kw])
        got = ((d or {}).get("data") or {}).get("itemList") or []
        if d is None or (got == [] and (d or {}).get("status") not in (0, None)):
            fail_calls += 1
        else:
            ok_calls += 1
        for it in got:
            _merge(seen, it, f"kw:{kw}")

    pois = list(seen.values())
    STATS["flyai_ok"] = flyai_ok
    STATS["flyai_calls_ok"] = ok_calls
    STATS["flyai_calls_fail"] = fail_calls
    if ok_calls == 0 and fail_calls:
        FLYAI_DEAD["on"] = True
        FLYAI_DEAD["why"] = FLYAI_DEAD["why"] or "POI 查询全部失败"
    if ok_calls == 0:
        why = ("flyai 不可用" if not flyai_ok
               else ("接口无返回，可能被风控" if fail_calls else "没有可用查询"))
        print(f"[warn] 飞猪 POI 本次全部失败（{why}）：候选只来自高德主题库/缓存",
              file=sys.stderr)
        note_issue("poi", FLYAI_REASON.get("text") or why,
                   "榜单剔除改用随包快照，热门点仍尽量排除")

    if pois:
        _write_poi_cache(city, theme, pois)
        return pois

    cached = _read_poi_cache(city, theme)
    if cached:
        print(f"[warn] 飞猪 POI 本次全部失败（{fail_calls} 次调用，可能触发风控 451），"
              f"改用 7 天缓存：{city}·{theme} {len(cached)} 个点", file=sys.stderr)
        return cached

    # 折价：同城任意主题的缓存
    d0 = os.path.join(CACHE_DIR, "poi")
    if os.path.isdir(d0):
        for fn in sorted(os.listdir(d0)):
            if fn.startswith(city + "_") and fn.endswith(".json"):
                try:
                    with open(os.path.join(d0, fn), encoding="utf-8") as fh:
                        data = json.load(fh)
                    if data:
                        print(f"[warn] 飞猪 POI 全部失败且无同主题缓存，改用同城缓存 {fn} "
                              f"{len(data)} 个点（榜单可能不是当前主题）", file=sys.stderr)
                        return data
                except Exception:
                    continue

    print(f"[warn] 飞猪 POI 全部失败（{fail_calls} 次调用）且无缓存；"
          f"本次候选池将只含高德主题库的点，榜单排除功能不可用", file=sys.stderr)
    return []


def _merge(seen: dict[str, dict[str, Any]], it: dict[str, Any], via: str) -> None:
    pid = str(it.get("id") or it.get("name"))
    if not pid:
        return
    lat, lng = _f(it.get("latitude")), _f(it.get("longitude"))
    if lat is None or lng is None:
        return  # 没有坐标就无法串联，直接丢弃
    if pid in seen:
        seen[pid].setdefault("via", []).append(via)
        return
    rec = dict(it)
    rec["lat"], rec["lng"] = lat, lng
    rec["via"] = [via]
    seen[pid] = rec


def _f(v: Any) -> float | None:
    try:
        f = float(v)
    except (TypeError, ValueError):
        return None
    return f if f != 0 else None


def tail_score(it: dict[str, Any]) -> tuple[int, list[str]]:
    """小众分：越高越说明它不在大众流量池里。返回 (分数, 理由)。"""
    score, why = 0, []
    if not it.get("listRank"):
        score += 2
        why.append("未登平台热榜")
    else:
        score -= 1
        why.append(f"热榜收录（{it['listRank']}）")
    if not it.get("poiLevel"):
        score += 1
        why.append("无景区等级")
    if it.get("category") in TAIL_CATEGORIES:
        score += 1
        why.append(f"{it.get('category')}属长尾类目")
    name = it.get("name") or ""
    if any(t in name for t in MASS_TOKENS):
        score -= 2
        why.append("亲子流量款")
    return score, why


def haversine(a: tuple[float, float], b: tuple[float, float]) -> float:
    """两点球面距离（米）。"""
    r = 6371000.0
    p1, p2 = math.radians(a[0]), math.radians(b[0])
    dp = p2 - p1
    dl = math.radians(b[1] - a[1])
    h = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(h))


AMAP_GEOCODE = "https://restapi.amap.com/v3/geocode/geo"
# 离线兜底：每座城市几个最常见的出发点（飞猪搜不到、又没有 Key 时用）
LANDMARKS: dict[str, dict[str, tuple[float, float]]] = {
    # 小城/古镇：同名地名在高德会串到别的省（「乌镇」曾解析成陕西榆林佳县），
    # 这些内置坐标优先命中，保证出发点落在本地。
    "婺源": {"婺源县城": (29.2480, 117.8610), "篁岭": (29.3510, 117.9370),
             "李坑": (29.2390, 117.9050), "江湾": (29.3710, 117.8310)},
    "凤凰": {"凤凰古城": (27.9480, 109.5990), "沱江": (27.9450, 109.5980)},
    "平遥": {"平遥古城": (37.2020, 112.1760), "明清街": (37.2030, 112.1740)},
    "阳朔": {"西街": (24.7780, 110.4960), "漓江": (24.7820, 110.4940)},
    "乌镇": {"乌镇西栅": (30.7450, 120.4870), "乌镇东栅": (30.7430, 120.4960)},
    "西塘": {"西塘古镇": (30.9470, 120.8880)},
    "周庄": {"周庄古镇": (31.1140, 120.8450)},
    "同里": {"同里古镇": (31.1570, 120.7160)},
    "南浔": {"南浔古镇": (30.8740, 120.4210)},
    "宏村": {"宏村": (30.0030, 117.9880), "月沼": (30.0040, 117.9870)},
    "黄姚": {"黄姚古镇": (24.2530, 111.1980)},
    "长汀": {"长汀古城": (25.8420, 116.3570)},
    "阆中": {"阆中古城": (31.5580, 105.9650)},
    "镇远": {"镇远古镇": (27.0490, 108.4250)},
    "荔波": {"荔波县城": (25.4120, 107.8840), "小七孔": (25.2600, 107.7000)},
    "龙胜": {"龙脊梯田": (25.7970, 110.0110), "龙胜县城": (25.8000, 110.0090)},
    "兴坪": {"兴坪古镇": (24.9330, 110.4970)},"沙溪": {"沙溪古镇": (26.3170, 99.8510)},
    "和顺": {"和顺古镇": (25.0170, 98.4630)},
    "青木川": {"青木川古镇": (32.8300, 105.5880)},
    "杭州": {"武林广场": (30.27415, 120.16480), "西湖": (30.24600, 120.14800),
             "龙翔桥": (30.25000, 120.16800), "城站": (30.24100, 120.18100),
             "运河广场": (30.32000, 120.14200)},
    "上海": {"人民广场": (31.24009, 121.47740), "外滩": (31.23970, 121.49030),
             "新天地": (31.22030, 121.47580), "静安寺": (31.22380, 121.44520),
             "五角场": (31.30360, 121.51470)},
    "北京": {"天安门": (39.90870, 116.39750), "南锣鼓巷": (39.93660, 116.40300),
             "三里屯": (39.93700, 116.45500), "什刹海": (39.94000, 116.38600),
             "前门": (39.89900, 116.39800)},
    "成都": {"春熙路": (30.65790, 104.07860), "宽窄巷子": (30.66500, 104.05800),
             "锦里": (30.64500, 104.04800), "东郊记忆": (30.67200, 104.12500)},
    "西安": {"钟楼": (34.25960, 108.94700), "大唐不夜城": (34.22000, 108.96000),
             "回民街": (34.26500, 108.94000), "小雁塔": (34.25300, 108.95400)},
    "南京": {"新街口": (32.04100, 118.78300), "夫子庙": (32.02300, 118.79000),
             "老门东": (32.01400, 118.78900), "玄武湖": (32.07000, 118.79500)},
    "苏州": {"观前街": (31.31200, 120.61900), "平江路": (31.32000, 120.62800),
             "山塘街": (31.32000, 120.59300), "金鸡湖": (31.31800, 120.70000)},
    "广州": {"北京路": (23.12500, 113.26800), "沙面": (23.10800, 113.24400),
             "永庆坊": (23.12000, 113.24900), "天河城": (23.13300, 113.32300)},
    "深圳": {"华强北": (22.54500, 114.08800), "海上世界": (22.48700, 113.91300),
             "东门老街": (22.54800, 114.11800), "福田CBD": (22.53800, 114.05700)},
    "厦门": {"中山路": (24.45700, 118.08200), "鼓浪屿": (24.44700, 118.06700),
             "沙坡尾": (24.44200, 118.07600), "曾厝垵": (24.42900, 118.10600)},
    "重庆": {"解放碑": (29.55800, 106.57700), "洪崖洞": (29.56300, 106.58100),
             "磁器口": (29.58500, 106.44900), "观音桥": (29.57500, 106.53200)},
    "武汉": {"江汉路": (30.58400, 114.28300), "户部巷": (30.54900, 114.30500),
             "楚河汉街": (30.55600, 114.34000), "光谷广场": (30.50600, 114.39700)},
    "长沙": {"五一广场": (28.19600, 112.97700), "坡子街": (28.19000, 112.97300),
             "橘子洲": (28.17800, 112.96200), "岳麓山": (28.18700, 112.93700)},
    "青岛": {"栈桥": (36.06100, 120.32000), "八大关": (36.05500, 120.34800),
             "台东步行街": (36.07900, 120.36000), "五四广场": (36.06300, 120.38400)},
    "天津": {"意式风情区": (39.13700, 117.20300), "五大道": (39.11500, 117.19600),
             "古文化街": (39.14600, 117.20200), "滨江道": (39.12500, 117.19900)},
    "昆明": {"南屏街": (25.04000, 102.71000), "翠湖": (25.05200, 102.70200),
             "官渡古镇": (24.96500, 102.75200)},
    "桂林": {"正阳步行街": (25.27600, 110.29700), "东西巷": (25.28000, 110.29500),
             "两江四湖": (25.27800, 110.29300)},
    "哈尔滨": {"中央大街": (45.77100, 126.61800), "索菲亚教堂": (45.76900, 126.62300),
               "防洪纪念塔": (45.78000, 126.61700)},
    "大连": {"星海广场": (38.87800, 121.58500), "青泥洼桥": (38.91500, 121.63400),
             "渔人码头": (38.86600, 121.66000)},
    "三亚": {"第一市场": (18.23900, 109.51200), "大东海": (18.22900, 109.51700),
             "亚特兰蒂斯": (18.23200, 109.66300)},
}

# 常用出发点补点（2026-11 从高德 place/text 拉取，GCJ-02）；键与上面同样按城市分组。
LANDMARKS_EXTRA: dict[str, dict[str, tuple[float, float]]] = {
    "杭州": {"断桥残雪": (30.25815, 120.15135), "河坊街": (30.24010, 120.16863), "灵隐寺": (30.24083, 120.10141), "小河直街": (30.30830, 120.13534), "拱宸桥": (30.31810, 120.13984), "北山街": (30.26001, 120.15458)},
    "上海": {"田子坊": (31.20820, 121.46866), "武康路": (31.20925, 121.44063), "豫园": (31.22771, 121.49250)},
    "北京": {"故宫博物院": (39.91784, 116.39703), "国子监": (39.94678, 116.41329), "798艺术区": (39.98506, 116.49478)},
    "成都": {"太古里": (30.65336, 104.08381), "玉林路": (30.62694, 104.06228), "望平街": (30.65287, 104.08977)},
    "西安": {"永宁门": (34.24819, 108.94695), "大雁塔": (34.21823, 108.96418), "洒金桥": (34.26637, 108.93268)},
    "南京": {"南京1912街区": (32.04478, 118.79578), "甘熙宅第": (32.02592, 118.78176)},
    "苏州": {"双塔市集": (31.30684, 120.63540), "拙政园": (31.32419, 120.62921)},
    "广州": {"陈家祠": (23.12573, 113.24644), "珠江新城": (23.11937, 113.32120), "二沙岛": (23.10998, 113.30552)},
    "厦门": {"沙坡尾": (24.43799, 118.08785), "环岛路": (24.44743, 118.16987)},
    "重庆": {"鹅岭二厂": (29.55110, 106.54018), "南山一棵树": (29.54532, 106.60250)},
    "武汉": {"昙华林": (30.55194, 114.30879), "黎黄陂路": (30.58773, 114.29935)},
    "长沙": {"潮宗街": (28.20249, 112.97432)},
    "青岛": {"大学路": (36.06336, 120.33457), "小麦岛": (36.05425, 120.43104)},
    "昆明": {"昆明老街": (25.04072, 102.70973), "翠湖公园": (25.04842, 102.70362)},
    "桂林": {"榕杉湖": (25.27590, 110.29048)},
}
for _c, _d in LANDMARKS_EXTRA.items():
    LANDMARKS.setdefault(_c, {}).update(_d)

# 常见别名 → 同一坐标（用户口语里「断桥」「西湖断桥」都指断桥，不该落到湖心）
LANDMARK_ALIASES: dict[str, dict[str, str]] = {
    "杭州": {"断桥": "断桥残雪", "西湖断桥": "断桥残雪", "湖滨": "北山街"},
    "上海": {"南京路": "南京东路", "新天地广场": "新天地"},
    "北京": {"后海": "什刹海", "南锣鼓巷北口": "南锣鼓巷"},
    "西安": {"回民街": "洒金桥"},
}
for _c, _m in LANDMARK_ALIASES.items():
    _tb = LANDMARKS.setdefault(_c, {})
    for _a, _t in _m.items():
        if _t in _tb and _a not in _tb:
            _tb[_a] = _tb[_t]


GENERIC_SUFFIX = re.compile(r"(省|自治区|市|区|县|镇|街道|路|街|道|巷|弄|号|栋|楼|层|附近|周边)+$")


def _geo_relevant(query: str, name: str) -> bool:
    """地名解析别被「模糊匹配」带跑：核心词对不上就丢。

    反例：查「某某不存在的路9999号」，飞猪会返回「不存在艺术中心 进博市集」。
    """
    # 只给到行政区一级的地名（「余杭区」）不要硬套到一个具体 POI 上
    if re.fullmatch(r"[\u4e00-\u9fa5]{2,8}?(省|市|区|县|镇)", re.sub(r"\s+", "", query)):
        return False
    q = re.sub(r"[\s（）()【】]+", "", query)
    q = GENERIC_SUFFIX.sub("", q)
    q = re.sub(r"\d+$", "", q)
    n = re.sub(r"[\s（）()【】]+", "", name)
    if not q:
        return False
    if q in n or n in q:
        return True
    # 共享的二字片段要占多数，否则「某某不存在的路」会匹配到「不存在艺术中心」
    grams = [q[i:i + 2] for i in range(len(q) - 1)]
    if not grams:
        return len(q) == 1 and q in n
    hit = sum(1 for g in grams if g in n)
    return hit / len(grams) >= 0.6


def amap_geocode(query: str, city: str | None, key: str) -> tuple[float, float, str] | None:
    """高德地理编码：飞猪搜地名搜不到时的第二层（门址/广场级都准）。"""
    if not key:
        return None
    d = _amap_get(AMAP_GEOCODE, {"address": query, "city": city or "", "key": key}, key)
    for g in ((d or {}).get("geocodes") or []):
        loc = g.get("location") or ""
        lvl = str(g.get("level") or "")
        if lvl in ("省", "市", "区县"):
            continue  # 只落到行政区一级，不算解析成功（宁可不给，也不要拿区政府门口当出发点）
        if "," in loc:
            lng, lat = loc.split(",")[:2]
            try:
                return float(lat), float(lng), g.get("formatted_address") or query
            except ValueError:
                continue
    return None


def _landmark_hit(table: dict[str, tuple[float, float]], query: str):
    """在内置地标表里找最合适的那个名字：先精确，再取最长包含匹配。

    为什么不能「命中第一个就返回」：表里同时有「西湖」和「西湖断桥」，
    用户说「西湖断桥」时先撞上「西湖」就会把出发点放到湖心（差 1.5 km）。
    """
    if not table or not query:
        return None
    if query in table:
        lat, lng = table[query]
        return lat, lng, query
    best = None
    for name, (lat, lng) in table.items():
        if name and (name in query or query in name):
            if best is None or len(name) > len(best[2]):
                best = (lat, lng, name)
    return best


def geocode(query: str, city: str) -> tuple[float, float, str] | None:
    """用 skill 自己当 geocoder：搜地名，取第一条 POI 的坐标。"""
    # 第零层：内置表优先。「同里」这种小地名，高德会解析成「甘肃省平凉市泾川县同里」，
    # 飞猪也可能命中同名小店；只要内置表里有，就别让外部服务猜。
    hit0 = _landmark_hit(LANDMARKS.get(city) or {}, query)
    if hit0:
        print(f"[info] 地名「{query}」命中内置地标表：{hit0[2]}", file=sys.stderr)
        return hit0

    d = run_flyai(["search-poi", "--city-name", city, "--keyword", query])
    for it in ((d or {}).get("data") or {}).get("itemList") or []:
        lat, lng = _f(it.get("latitude")), _f(it.get("longitude"))
        nm = str(it.get("name") or "")
        if lat and lng and _geo_relevant(query, nm):
            return lat, lng, nm or query

    # 第二层：高德地理编码（「人民广场」这种通用地名，飞猪 POI 库经常搜不到）
    hit = amap_geocode(query, city, AMAP_KEY)
    if hit:
        print(f"[info] 地名「{query}」用高德地理编码解析：{hit[2]}", file=sys.stderr)
        return hit

    # 第三层：内置同城地标表（无网/无 Key 也能用）
    hit3 = _landmark_hit(LANDMARKS.get(city) or {}, query)
    if hit3:
        print(f"[info] 地名「{query}」命中内置地标表：{hit3[2]}", file=sys.stderr)
        return hit3
    return None


def build_clusters(pois: list[dict[str, Any]], radius: float) -> list[dict[str, Any]]:
    """密度优先聚类：先找「半径内邻居最多」的种子，再吞掉半径内的点。

    为什么不用「分数最高的点当种子」：高分点常常是孤立的（一个老街区的
    单栋老建筑），拿它当种子只能吸到 1-2 个点，出来的路线要跨街区走路。
    密度优先保证「簇 = 一条能走完的街」，这是本产品的核心约束。
    """
    if not pois:
        return []
    pts = [(p["lat"], p["lng"]) for p in pois]
    nbr: list[list[int]] = []
    for i, a in enumerate(pts):
        nbr.append([j for j, b in enumerate(pts) if j != i and haversine(a, b) <= radius])

    # 种子排序：邻居多优先，同密度比分数
    order = sorted(range(len(pois)), key=lambda i: (-len(nbr[i]), -pois[i]["score"]))
    used: set[int] = set()
    clusters: list[dict[str, Any]] = []

    for seed in order:
        if seed in used:
            continue
        group = [seed] + [j for j in nbr[seed] if j not in used]
        used.update(group)
        members = [pois[i] for i in group]
        members.sort(key=lambda p: -p["score"])
        span = max((haversine((a["lat"], a["lng"]), (b["lat"], b["lng"]))
                    for a in members for b in members), default=0.0)
        clusters.append(
            {
                "centroid": [sum(m["lat"] for m in members) / len(members),
                             sum(m["lng"] for m in members) / len(members)],
                "score": sum(m["score"] for m in members),
                "span_m": round(span),
                "single": len(members) < 2,
                "members": members,
            }
        )

    clusters.sort(key=lambda c: (-len(c["members"]), -c["score"]))
    return clusters


def hook_of(it: dict[str, Any]) -> str:
    """从 description 里挖一句「能立刻做的事」的原料。"""
    desc = re.sub(r"\s+", " ", str(it.get("description") or "")).strip()
    if not desc:
        return ""
    # 去重（源数据里常见 A;A 形式）
    parts = [p.strip() for p in desc.split(";") if p.strip()]
    uniq = []
    for p in parts:
        if p not in uniq:
            uniq.append(p)
    text = uniq[0] if uniq else desc
    # 截到第一个句号，控制在 90 字内
    m = re.match(r"(.{10,90}?[。！？])", text)
    return m.group(1) if m else text[:90]


DEDUPE_M = 60.0


def dedupe(pois: list[dict[str, Any]], tol: float = DEDUPE_M) -> list[dict[str, Any]]:
    """合并同一地点的多条记录。

    平台库里一个地方常有多条 POI：「杭州运河游船」和「武林门码头」坐标只差
    2.4 米，是同一个码头的两条记录。不合并的话，一个 2 个地点的簇会被数成
    3 个，路线站数虚高，讲解也会把同一个地点说两遍。

    保留策略：**带榜单信息（listRank）的优先**，其次素材最厚（description 最长）的那条。
    随包快照不存 description（为了体积），如果只按描述长度选，主题点库那条会顶掉
    快照里带 rank 的记录，榜点剔除就会静默失效（杭州 hot 12→0 就是这个原因）。
    """
    kept: list[dict[str, Any]] = []

    def _keep_rank(x: dict[str, Any]) -> tuple[int, int]:
        return (1 if x.get("listRank") else 0, len(x.get("description") or ""))

    for p in sorted(pois, key=_keep_rank, reverse=True):
        if any(haversine((p["lat"], p["lng"]), (q["lat"], q["lng"])) <= tol for q in kept):
            continue
        kept.append(p)
    return kept


HOT_CATS = {"历史古迹", "博物馆", "城市观光", "地标建筑", "自然风光", "园林花园"}


def crowd_risk(it: dict[str, Any]) -> str:
    """客流风险的粗判——只有榜单和类目两个信号，不是实时人流。"""
    if it.get("listRank"):
        return "高（上榜，推测）"
    if (it.get("category") or "") in HOT_CATS:
        return "中（类目常见，推测）"
    return "低（推测）"


def _ticket_of(it: dict[str, Any]) -> dict[str, Any] | None:
    """把飞猪的 ticketInfo 压成一行能直接说给用户听的。"""
    t = it.get("ticketInfo") or {}
    price = str(t.get("price") or "").strip()
    name = str(t.get("ticketName") or "").strip()
    if price:
        return {"price": price, "name": name}
    if str(it.get("freePoiStatus") or "").upper() == "FREE":
        return {"price": "免费", "name": ""}
    return None


def slim(it: dict[str, Any], anchor: tuple[float, float] | None) -> dict[str, Any]:
    out = {
        "name": it.get("name"),
        "category": it.get("category"),
        "address": it.get("address"),
        "lat": round(it["lat"], 5),
        "lng": round(it["lng"], 5),
        "tail_score": it["score"],
        "tail_why": it["why"],
        "rank": it.get("listRank"),
        "hook": hook_of(it),
        "jumpUrl": it.get("jumpUrl"),
        "free": it.get("freePoiStatus"),
        "ticket": _ticket_of(it),
        "crowd": crowd_risk(it),
    }
    if anchor:
        out["walk_from_anchor_m"] = int(haversine(anchor, (it["lat"], it["lng"])))
    return out


def _nearby_note() -> str:
    """周边吃/看三路数据源的状态说明，供 brief 与回答如实说明用。"""
    dead = []
    if STATS.get("amap_quota_dead"):
        dead.append("高德搜索接口今日额度用尽（10044）")
    if FLYAI_DEAD.get("on"):
        _w = str(FLYAI_DEAD.get("why") or "额度/风控")
        dead.append(_w if _w.startswith("飞猪") else "飞猪" + _w)
    if dead:
        return ("周边吃/看数据源不可用：" + "；".join(dead) +
                "。这些位置的餐饮/文化点本次可能为空，回答时如实说明，"
                "不要把「没有检索到」写成「这一带没有」。")
    return ""


NEARBY_SEEN: list[dict[str, Any]] = []


NEARBY_SRC_TAG = {"cache": "随包/本地缓存", "amap": "高德实时", "flyai": "飞猪实时",
                  "mcp": "高德MCP实时", "enrich-cache": "本地缓存", "none": "无"}

# 云端沙箱常常连不上 restapi.amap.com（只有 MCP 通道可用）：由 agent 用
# `maps_around_search` 取回周边，经 `--nearby-json` 交给引擎，优先级最高。
MCP_NEARBY: list[dict[str, Any]] = []


def _mcp_near(name: str) -> dict[str, Any] | None:
    """按站名找 agent 预先取回的 MCP 周边数据（允许包含关系匹配）。"""
    if not name:
        return None
    for it in MCP_NEARBY:
        nm = str(it.get("name") or "")
        if not nm:
            continue
        if nm == name or nm in name or name in nm:
            return it
    return None


def _nearby_source() -> dict[str, Any]:
    """统计本轮「周边吃/看」的数据来源，给模型一句能照抄的话。"""
    cnt: dict[str, int] = {}
    empty = 0
    _seen: set[str] = set()
    for sp in NEARBY_SEEN:
        _nm = str(sp.get("name") or "")
        if _nm:
            if _nm in _seen:
                continue
            _seen.add(_nm)
        for f in ("food_src", "culture_src"):
            tag = sp.get(f) or "none"
            cnt[tag] = cnt.get(tag, 0) + 1
        if not sp.get("food") and not sp.get("culture"):
            empty += 1
    parts = []
    for k, v in sorted(cnt.items(), key=lambda kv: -kv[1]):
        if k == "none":
            continue
        parts.append("%s ×%d" % (NEARBY_SRC_TAG.get(k, k), v))
    if not parts:
        text = "周边吃/看没有任何数据源可用（高德额度、飞猪额度、城市池都没有命中）。"
    else:
        text = "周边吃/看来源：" + "，".join(parts) + "。"
        if cnt.get("none"):
            text += "另有 %d 条槽位确实没数据（不是「这一带没有」，是数据源没覆盖）。" % cnt["none"]
    return {"counts": cnt, "empty_stops": empty, "text": text}


def to_briefing(city: str, theme: str, hours: float, anchor_name: str | None,
                clusters: list[dict[str, Any]], used_queries: int,
                hot: list[dict[str, Any]] | None = None,
                anchor_failed: str | None = None,
                deduped: int = 0,
                plans: list[dict[str, Any]] | None = None,
                ticket_summary: str | None = None,
                theme_fallback: dict[str, Any] | None = None,
                sparse: dict[str, Any] | None = None) -> str:
    lines = [
        f"# 候选简报｜{city}·{theme}·{hours:g}h" + (f"（出发点：{anchor_name}）" if anchor_name else ""),
        f"检索次数：{used_queries}｜候选簇：{len(clusters)}"
        + (f"｜已排除榜单点：{len(hot)}" if hot else "")
        + (f"｜同址重复已合并：{deduped}" if deduped else ""),
        "",
    ]
    if anchor_failed:
        lines += [
            f"⚠️ 出发点「{anchor_failed}」没有解析出坐标（POI 库里搜不到这个地名），"
            f"本次**没有做距离过滤，也没有按距离排序**——下面的簇可能离用户几十公里。",
            "按铁律，此时不要直接给路线：先向用户确认一个更具体的地标"
            "（商圈 / 景区 / 地铁站 / 知名建筑名），再重跑。",
            "",
        ]
    if theme_fallback:
        lines += [
            f"⚠️ 主题替换：请求的是「{theme_fallback['from']}」，本城只拿到 "
            f"{theme_fallback['from_points']} 个点，已自动改用「{theme_fallback['to']}」"
            f"（{theme_fallback['to_points']} 个点）。回答时**第一句就说这件事**。",
            "",
        ]
    # 门票口径放最前：之前埋在中间，模型经常跳过
    if ticket_summary:
        lines += [f"**门票口径（必须照这个说）**：{ticket_summary}", ""]
    _reasons = data_reason_lines()
    if _reasons:
        lines += [
            "**为什么这次有数据没拿到（回答时必须原话交代，不许只写「查不到」）**：",
            *[f"- {r}" for r in _reasons],
            "写法要求：先说「哪块没拿到 + 具体原因（额度用尽 / 触发风控 / 这一带确实没有）」"
            "，紧接着说「所以这次改用了什么」（随包快照 / 高德），"
            "再说这对用户的影响（比如榜单可能不是最新、酒店没有价格）。",
            "",
        ]
    if plans:
        lines.append("## 现成方案 Top3（每条都已带地图，直接照抄 map_line，不要再跑引擎）")
        for pl in plans:
            lines.append(
                f"- 方案{chr(65 + pl['idx'])}｜{pl['title']}｜{pl['stops_n']} 站"
                f"｜跨度 {pl['span_m']} m｜约 {pl.get('walk_m') or pl['est_walk_m']} m"
                f" / {pl.get('walk_min') or pl['est_min']} 分钟"
                f"｜{' → '.join(pl['stops'][:4])}"
            )
            if pl.get("map_line"):
                lines.append(f"  {pl['map_line']}")
            if pl.get("two_stop"):
                lines.append(f"  ⚠️ {pl.get('two_stop_note')}——回答时说明「这一片只够两站」，别硬编第三站")
                _sg = pl.get("two_stop_suggest") or {}
                if _sg.get("name"):
                    lines.append(f"  ↳ 可以顺带提一句：{_sg['note']}（{_sg['name']}）")
            if pl.get("access_note"):
                lines.append(f"  🚕 到达方式（不算进步行线）：{pl['access_note']}")
            if pl.get("over_walk"):
                lines.append(f"  ⚠️ 走不完：{pl.get('walk_note')}")
        lines.append("")
    if sparse:
        lines += [f"⚠️ 稀疏：{sparse.get('msg')}", ""]

    for i, c in enumerate(clusters[:4], 1):
        cdist = ""
        if anchor_name and c.get("anchor_m"):
            cdist = f"｜距出发点 {c['anchor_m']} m"
        span = f"｜跨度 {c['span_m']} m" if c.get("span_m") else ""
        lines.append(f"## 簇{i}：{c['title']}（{len(c['members'])} 个点{span}{cdist}）")
        for m in c["members"][:6]:
            walk = f"  ·  {m['walk_from_anchor_m']}m" if m.get("walk_from_anchor_m") else ""
            lines.append(
                f"- {m['name']}｜{m['category']}｜小众分{m['tail_score']}"
                f"｜门票{(m.get('ticket') or {}).get('price') or '无数据'}"
                f"｜客流{m.get('crowd','未知')}{walk}"
                f"｜{','.join(m['tail_why'][:2])}\n  地址：{m['address']}\n  素材：{m['hook']}"
            )
        lines.append("")
    if hot:
        lines.append("## 已排除的榜单点（listRank 非空，按规矩不进路线）")
        for h in hot[:8]:
            walk = f"  ·  {h['walk_from_anchor_m']}m" if h.get("walk_from_anchor_m") else ""
            lines.append(f"- {h['name']}｜{h['category']}｜榜单位次 {h['rank']}{walk}")
        lines.append("")
    return "\n".join(lines)


ADDR_PREFIX = re.compile(
    r"^(?:[\u4e00-\u9fa5]{2,8}?(?:省|自治区))?"
    r"(?:[\u4e00-\u9fa5]{2,8}?(?:市|自治州))?"
    r"(?:[\u4e00-\u9fa5]{2,8}?(?:区|县|旗))?"
    r"(?P<tail>.*)$"
)


def _addr_tail(addr: str) -> str:
    """剥掉「浙江省杭州市上城区」这类前缀，留下街道与门牌。"""
    m = ADDR_PREFIX.match(addr or "")
    return (m.group("tail") if m else addr) or ""


def cluster_title(members: list[dict[str, Any]]) -> str:
    """给簇起个名：优先抽「街道 + 路名」，抽不到就用点名。"""
    streets: list[str] = []
    roads: list[str] = []
    for m in members:
        tail = _addr_tail(str(m.get("address") or ""))
        for seg in re.findall(r"([\u4e00-\u9fa5]{2,4})(?:街道|镇|乡)", tail):
            if seg not in streets:
                streets.append(seg)
        # 先把「XX街道」整段抠掉，避免把「西湖街道」误识别成「西湖街」
        tail_wo = re.sub(r"[\u4e00-\u9fa5]{2,4}(?:街道|镇|乡)", "", tail)
        for seg in re.findall(r"([\u4e00-\u9fa5]{2,6}?(?:路|街|巷|弄|大道))", tail_wo):
            if seg not in roads:
                roads.append(seg)
    parts = [f"{streets[0]}街道"] if streets else []
    parts += roads[:1]
    if parts:
        return " · ".join(parts)
    names = [str(m.get("name") or "") for m in members[:2]]
    return " / ".join(names) or "未命名簇"



# ---------- 真实街道路径 + 地图（高德优先/OSM 兜底，不画直线） ----------

MAP_TMPL = r"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>绕路 Detour · 步行路线图</title>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
<style>
:root{--ink:#14181f;--muted:#6b7580;--line:#e3e6ea;--accent:#e8553d}
*{box-sizing:border-box}html,body{margin:0;height:100%}
body{display:grid;grid-template-columns:360px 1fr;height:100vh;overflow:hidden;background:#fbfbfa;
 font-family:-apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",sans-serif;color:var(--ink)}
aside{overflow-y:auto;background:#fff;border-right:1px solid var(--line);padding:22px 20px 36px}
.brand{font-size:11px;letter-spacing:.2em;color:var(--muted)}.brand b{color:var(--accent)}
h1{font-size:20px;line-height:1.4;margin:12px 0 4px}
.meta{display:flex;gap:16px;margin:14px 0 16px;padding:12px 0;border-top:1px solid var(--line);border-bottom:1px solid var(--line)}
.meta div{font-size:11.5px;color:var(--muted)}.meta b{display:block;font-size:15px;color:var(--ink);margin-top:2px}
ol{list-style:none;margin:0;padding:0}
ol li{position:relative;padding:0 0 16px 34px}
ol li:before{content:attr(data-n);position:absolute;left:0;top:1px;width:22px;height:22px;border-radius:50%;
 background:var(--ink);color:#fff;font-size:11.5px;font-weight:600;display:flex;align-items:center;justify-content:center}
ol li:not(:last-child):after{content:"";position:absolute;left:10.5px;top:27px;bottom:0;width:1px;background:var(--line)}
.name{font-weight:650;font-size:14px;margin-bottom:3px}
.tag{display:inline-block;font-size:11px;color:var(--muted);border:1px solid var(--line);border-radius:999px;padding:0 7px;margin:0 5px 3px 0}
.tag.free{color:#1f7a44;border-color:#cfe7d9;background:#f2faf5}
.walk{font-size:12px;color:var(--muted);margin-top:3px}
.do{font-size:12.5px;line-height:1.6;color:#3a424b;margin-top:4px}
.hint{font-size:11.5px;color:var(--muted);line-height:1.7;margin-top:18px;padding-top:14px;border-top:1px solid var(--line)}
#map{height:100%}
.pin{border-radius:50%;background:var(--ink);color:#fff;font-size:12px;font-weight:600;display:flex;align-items:center;justify-content:center;border:2px solid #fff;box-shadow:0 1px 4px rgba(0,0,0,.3)}
.pin.start{background:#fff;color:var(--ink);border-color:var(--ink);font-size:10px}
.pin.hot{background:#c9ced4;color:#fff;font-size:10px;box-shadow:none}
.stn{background:#fff;border:1px solid var(--line);border-radius:5px;padding:1px 6px;font-size:11.5px;font-weight:600;box-shadow:0 1px 4px rgba(0,0,0,.1);white-space:nowrap}
.stn:before{display:none}
.legend{position:absolute;left:12px;bottom:12px;z-index:500;width:190px;background:rgba(255,255,255,.96);border:1px solid var(--line);border-radius:8px;padding:9px 11px;font-size:11.5px;line-height:2;box-shadow:0 2px 10px rgba(0,0,0,.06)}
.legend div{white-space:nowrap}
.legend i{display:inline-flex;width:15px;height:15px;border-radius:50%;background:var(--ink);color:#fff;font-style:normal;font-size:10px;align-items:center;justify-content:center;margin-right:6px;vertical-align:-3px}
.legend i.h{background:#c9ced4}.legend i.s{background:#fff;border:2px solid var(--ink);color:var(--ink)}
.legend span.line{display:inline-block;width:16px;height:0;border-top:3px solid #e8553d;margin-right:6px;vertical-align:3px}
</style></head><body>
<aside>
  <div class="brand">🚶 <b>绕路 DETOUR</b> · <span id="cityline"></span></div>
  <h1 id="title"></h1>
  <div class="meta" id="meta"></div>
  <ol id="stops"></ol>
  <div id="hotels"></div>
  <div class="hint" id="hint"></div>
</aside>
<div id="map"></div>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
const D = __DATA__;
const map = L.map('map',{zoomControl:true}).setView([D.stops[0]?D.stops[0].lat:30.27, D.stops[0]?D.stops[0].lng:120.16], 15);
L.tileLayer('https://webrd0{s}.is.autonavi.com/appmaptile?lang=zh_cn&size=1&scale=1&style=8&x={x}&y={y}&z={z}',
  {attribution:'© 高德地图', maxZoom:19, subdomains:'1234'}).addTo(map);

function pin(html, cls){ return L.divIcon({html:'<div class="pin '+cls+'">'+html+'</div>',className:'',iconSize:[24,24],iconAnchor:[12,12]}); }

const all = [];
D.segs.forEach(s=>{
  L.polyline(s.path,{color:s.color,weight:5,opacity:.85,lineCap:'round',lineJoin:'round'}).addTo(map);
  L.polyline(s.path,{color:'#fff',weight:1.5,opacity:.5,dashArray:'6 6'}).addTo(map);
  s.path.forEach(p=>all.push(p));
  const mid = s.path[Math.floor(s.path.length/2)];
  L.marker(mid,{icon:L.divIcon({html:'<div style="transform:translate(-50%,-50%);background:#fff;border:1px solid #e3e6ea;border-radius:999px;padding:1px 7px;font-size:10.5px;color:#6b7580;box-shadow:0 1px 3px rgba(0,0,0,.1);white-space:nowrap">'+s.m+' m · '+s.min+' 分钟</div>',className:'',iconSize:[0,0]})}).addTo(map);
});
D.stops.forEach(s=>{
  const m = L.marker([s.lat,s.lng],{icon:pin(String(s.n),'')}).addTo(map);
  m.bindTooltip(s.name,{permanent:true,direction:'right',offset:[12,0],className:'stn'});
  m.bindPopup('<b>'+s.name+'</b>'+(s.cat?'<small>'+s.cat+'</small>':'')+
    (s.addr?'<br/>'+s.addr:'')+(s.hook?'<br/><em style="color:#6b7580">'+s.hook+'</em>':'')+
    (s.rank?'<br/><b style="color:#e8553d">榜单：'+s.rank+'</b>':''));
  all.push([s.lat,s.lng]);
});
if(D.origin&&D.origin.lat){
  L.marker([D.origin.lat,D.origin.lng],{icon:pin('起','start')}).addTo(map).bindPopup('<b>'+(D.origin.name||'出发点')+'</b>');
  all.push([D.origin.lat,D.origin.lng]);
}
D.hot.forEach(h=>{ L.marker([h.lat,h.lng],{icon:pin('✕','hot'),opacity:.9}).addTo(map)
  .bindPopup('<b>'+h.name+'</b><small>'+(h.rank||'')+' · 未进路线</small>'); });

const Legend = L.Control.extend({onAdd(){const d=L.DomUtil.create('div','legend');
  d.innerHTML='<div><i>1</i>路线站点</div><div><span class="line"></span>真实步行路径</div><div><i class="s">起</i>出发点</div><div><i class="h">✕</i>榜单点·未进路线</div>';return d;}});
new Legend({position:'bottomleft'}).addTo(map);

// 视野：先 invalidateSize 再 fitBounds，否则容器还没尺寸时会缩到世界地图
function fitNow(){
  if(!all.length) return;
  try{ map.invalidateSize(); window.__map = map;
  map.fitBounds(L.latLngBounds(all).pad(0.12), {maxZoom:17}); }catch(e){}
}
fitNow(); setTimeout(fitNow,120); setTimeout(fitNow,600);

// —— 左侧面板 ——
document.getElementById('cityline').textContent = D.city || '';
document.getElementById('title').textContent = D.theme ? D.theme + ' · 步行路线' : '步行路线';
document.getElementById('meta').innerHTML =
  '<div>步行<b>'+(D.total_m/1000).toFixed(1)+' km</b></div>'+
  '<div>路上<b>'+D.total_min+' 分钟</b></div>'+
  '<div>绕行系数<b>'+D.excess+'</b></div>'+
  '<div>站点<b>'+D.stops.length+'</b></div>';
document.getElementById('stops').innerHTML = D.stops.map(function(s){
  var tags = (s.cat?'<span class="tag">'+s.cat+'</span>':'')+
             (s.free==='FREE'?'<span class="tag free">免费</span>':'')+
             (s.score!=null?'<span class="tag">小众分 '+s.score+'</span>':'')+
             (s.rank?'<span class="tag" style="color:#e8553d;border-color:#f4c9c0">榜单点</span>':'');
  var leg = D.segs[s.n-1];
  return '<li data-n="'+s.n+'"><div class="name">'+s.name+'</div>'+tags+
    (leg?'<div class="walk">下一段 步行 '+leg.m+' m · '+leg.min+' 分钟（沿街道）</div>':'')+
    (s.addr?'<div class="walk">'+s.addr+'</div>':'')+
    (s.hook?'<div class="do">'+s.hook+'</div>':'')+'</li>';
}).join('');
if((D.hotels||[]).length){
  var hd = '<div class="hhead">🏨 终点附近住处（'+(D.hotels[0].date||'')+' 入住）</div>' +
    D.hotels.map(function(h){
      return '<a href="'+(h.url||'#')+'" target="_blank" style="display:flex;gap:8px;align-items:baseline;'+
        'padding:7px 0;border-top:1px solid #eef1f4;text-decoration:none;color:#14181f;font-size:12.5px;line-height:1.5">'+
        '<b style="color:#2f6fed;font-weight:700;flex:0 0 54px">'+(h.price||'查价')+'</b>'+
        '<span style="flex:1">'+(h.name||'')+'</span>'+
        '<em style="color:#9aa3ad;font-style:normal;font-size:11px;white-space:nowrap">'+(h.star||'')+
        (h.dist_m?' · '+h.dist_m+' m':'')+'</em></a>';
    }).join('');
  document.getElementById('hotels').innerHTML = hd;
}
document.getElementById('hint').innerHTML =
  '路径优先高德步行路网（与底图同源），无高德时用 OSRM；取不到路网的段留空，绝不画直线。'+
  '灰 ✕ 是各榜单里排名靠前、这次没进路线的点——点开能看到它排第几。';
</script></body></html>
"""


OSRM_HOST = os.environ.get("DETOUR_OSRM_HOST", "https://routing.openstreetmap.de")
OSRM_URL = (OSRM_HOST + "/routed-{prof}/route/v1/{mv}/"
            "{coords}?geometries=geojson&overview=full&steps=false")
PROFILES = {"walk": ("foot", "driving"), "car": ("car", "driving"), "bike": ("bike", "bike")}
ROUTE_DIR = os.path.join(CACHE_DIR, "routes")
# 随包路网缓存：把本机跑过的路线/吸附结果打进技能包，云端冷启动也能直接命中，
# 不依赖 OSRM 是否可达（离线/被墙时同一批城市仍出图）。
_SELF_DIR = os.path.dirname(os.path.abspath(__file__))
_ROUTE_PACK_CANDS = [
    os.path.join(_SELF_DIR, "data", "routes"),
    os.path.join(os.path.dirname(_SELF_DIR), "data", "routes"),
    os.path.join(_SELF_DIR, "skill-package-engine", "data", "routes"),
]
ROUTE_PACK_DIR = next((d for d in _ROUTE_PACK_CANDS if os.path.isdir(d)), None)


NO_PACK = os.environ.get("DETOUR_NO_PACK") == "1"   # 演练「没路网」时置 1


def _read_route_pack(name: str) -> Any:
    """先找本机 .cache/routes，再找随包 data/routes；DETOUR_NO_PACK=1 时当作没有随包。"""
    if NO_PACK:
        return None
    if not ROUTE_PACK_DIR:
        return None
    fp = os.path.join(ROUTE_PACK_DIR, name)
    try:
        if os.path.exists(fp):
            return json.load(open(fp, encoding="utf-8"))
    except Exception:
        pass
    return None

# 没给 --map-base / MAP_BASE 时，默认指本机跑着的静态服务（用户本机 python3 -m http.server 8787）
DEFAULT_MAP_BASE = os.environ.get("MAP_BASE", "https://suo353.github.io/detour/map.html")
ROUTE_STATS = {"calls": 0, "cache_hits": 0, "failed": 0, "avoid_attempts": 0, "amap_legs": 0}
# 进程内 memo：同一次运行里同一个点会被反复吸附（每条腿都要吸附首尾），
# 云端一次网络往返几百毫秒，这里省掉的是实打实的等待。
_NEAREST_MEMO: dict[tuple, dict[str, Any] | None] = {}
_LEG_MEMO: dict[tuple, dict[str, Any] | None] = {}

HOT_AVOID_M = 140.0   # 路径离榜单点小于这个数，就算「从人流高地上穿过去」
SNAP_MIN_M = 8.0      # POI 离马路超过这个距离才做吸附，避免无谓抖动

SNAP_DIR = os.path.join(CACHE_DIR, "snap")
_SNAP_PACK_CANDS = [
    os.path.join(_SELF_DIR, "data", "snap"),
    os.path.join(os.path.dirname(_SELF_DIR), "data", "snap"),
    os.path.join(_SELF_DIR, "skill-package-engine", "data", "snap"),
]
SNAP_PACK_DIR = next((d for d in _SNAP_PACK_CANDS if os.path.isdir(d)), None)


_ADCODE_DIR = os.path.join(CACHE_DIR, "adcode")


def _city_adcodes(city: str) -> set:
    """城市行政区内所有区县 adcode（含下辖）。拿不到就返回空集合，过滤自动跳过。"""
    fp = os.path.join(_ADCODE_DIR, "%s.json" % city)
    try:
        if os.path.exists(fp):
            return set(json.load(open(fp, encoding="utf-8")))
    except Exception:
        pass
    key = os.environ.get("AMAP_KEY") or ""
    if not key:
        return set()
    url = ("https://restapi.amap.com/v3/config/district?keywords=%s&subdistrict=1&extensions=base&key=%s"
           % (urllib.parse.quote(city), key))
    try:
        with urllib.request.urlopen(url, timeout=OSRM_TIMEOUT) as r:
            d = json.loads(r.read().decode("utf-8"))
        out = []
        for dist in ((d or {}).get("districts") or []):
            if dist.get("adcode"):
                out.append(str(dist["adcode"]))
            for sub in (dist.get("districts") or []):
                if sub.get("adcode"):
                    out.append(str(sub["adcode"]))
        if out:
            os.makedirs(_ADCODE_DIR, exist_ok=True)
            json.dump(out, open(fp, "w", encoding="utf-8"))
        return set(out)
    except Exception:
        return set()


def _district_ok(pt, adcodes) -> bool:
    """点在行政区外就丢（兴坪那次就是召回到邻县/市区的点）。没有 adcode 的一律放行。"""
    if not adcodes:
        return True
    ad = str(pt.get("adcode") or "")
    if not ad:
        return True
    return ad in adcodes


def _snap_key(pt, mode):
    """1 km 网格键：同一格里的点吸附距离差不了几十米，够用来判断「走不走得到」。"""
    w = gcj2wgs(pt[0], pt[1])
    return "snap_%s_%.2f_%.2f" % (mode, w[0], w[1])


def _snap_cached(pt, mode):
    k = _snap_key(pt, mode)
    fp = os.path.join(SNAP_DIR, k + ".json")
    try:
        if os.path.exists(fp):
            return float(json.load(open(fp, encoding="utf-8"))["dist"])
    except Exception:
        pass
    if SNAP_PACK_DIR:
        pp = os.path.join(SNAP_PACK_DIR, k + ".json")
        try:
            if os.path.exists(pp):
                return float(json.load(open(pp, encoding="utf-8"))["dist"])
        except Exception:
            pass
    return None


def _snap_store(pt, mode, dist):
    try:
        os.makedirs(SNAP_DIR, exist_ok=True)
        json.dump({"dist": dist}, open(os.path.join(SNAP_DIR, _snap_key(pt, mode) + ".json"),
                                       "w", encoding="utf-8"))
    except Exception:
        pass


SNAP_MAX_M = 150.0
SNAP_MOVE_MAX_M = 900.0  # 超过这个距离就不算「贴边」，直接判不可达     # 站点离最近可步行道路超过这个距离，视为「走不到」（水里/楼里/无路网）


def _snap_m(pt: tuple[float, float], mode: str = "walk") -> float:
    """POI 到最近可步行道路的距离（米）；取不到就当作不可达。

    先查 1 km 网格缓存（`data/snap` 随包 + 本地 `.cache/snap`），
    小城首跑不必每站都等一次 OSRM。
    """
    c = _snap_cached(pt, mode)
    if c is not None:
        ROUTE_STATS["cache_hits"] = ROUTE_STATS.get("cache_hits", 0) + 1
        return c
    n = _osrm_nearest(pt, mode)
    if not n or n.get("dist") is None:
        return 9999.0
    try:
        d = float(n["dist"])
    except Exception:      # noqa: BLE001
        return 9999.0
    _snap_store(pt, mode, d)
    return d

TRY_SHORTCUT = os.environ.get("DETOUR_TRY_SHORTCUT") == "1"  # 默认关：中点法容易画出「走进去又退出来」
DETOUR_MAX = 1.22     # 为了避开人流，最多允许绕到直线的 1.45 倍
DETOUR_OFFSET_M = 220.0


# ---- 坐标系：OSM/OSRM 是 WGS-84，高德瓦片与飞猪 POI 是 GCJ-02 ----
_GCJ_A = 6378245.0
_GCJ_EE = 0.00669342162296594323


def _gcj_dlat(x: float, y: float) -> float:
    r = (-100.0 + 2.0 * x + 3.0 * y + 0.2 * y * y + 0.1 * x * y
         + 0.2 * math.sqrt(abs(x)))
    r += (20.0 * math.sin(6.0 * x * math.pi) + 20.0 * math.sin(2.0 * x * math.pi)) * 2.0 / 3.0
    r += (20.0 * math.sin(y * math.pi) + 40.0 * math.sin(y / 3.0 * math.pi)) * 2.0 / 3.0
    r += (160.0 * math.sin(y / 12.0 * math.pi) + 320 * math.sin(y * math.pi / 30.0)) * 2.0 / 3.0
    return r


def _gcj_dlng(x: float, y: float) -> float:
    r = (300.0 + x + 2.0 * y + 0.1 * x * x + 0.1 * x * y
         + 0.1 * math.sqrt(abs(x)))
    r += (20.0 * math.sin(6.0 * x * math.pi) + 20.0 * math.sin(2.0 * x * math.pi)) * 2.0 / 3.0
    r += (20.0 * math.sin(x * math.pi) + 40.0 * math.sin(x / 3.0 * math.pi)) * 2.0 / 3.0
    r += (150.0 * math.sin(x / 12.0 * math.pi) + 300.0 * math.sin(x / 30.0 * math.pi)) * 2.0 / 3.0
    return r


def wgs2gcj(lat: float, lng: float) -> tuple[float, float]:
    """WGS-84 → GCJ-02（火星坐标）。

    不转的后果：杭州一带两者差约 519 米——红线会整体错开到隔壁街区，
    看起来就是「跟街道完全对不上」，而站点标记（飞猪给的，本来就是 GCJ）却是准的。
    """
    dlat = _gcj_dlat(lng - 105.0, lat - 35.0)
    dlng = _gcj_dlng(lng - 105.0, lat - 35.0)
    rad = lat / 180.0 * math.pi
    magic = math.sin(rad)
    magic = 1 - _GCJ_EE * magic * magic
    sq = math.sqrt(magic)
    dlat = (dlat * 180.0) / ((_GCJ_A * (1 - _GCJ_EE)) / (magic * sq) * math.pi)
    dlng = (dlng * 180.0) / (_GCJ_A / sq * math.cos(rad) * math.pi)
    return lat + dlat, lng + dlng


def gcj2wgs(lat: float, lng: float) -> tuple[float, float]:
    """GCJ-02 → WGS-84（迭代两次就够用，误差 <1 m）。"""
    wlat, wlng = lat, lng
    for _ in range(2):
        glat, glng = wgs2gcj(wlat, wlng)
        wlat += lat - glat
        wlng += lng - glng
    return wlat, wlng



def _cut_overshoot(pts: List[Tuple[float, float]], min_bulge_m: float = 55.0) -> List[Tuple[float, float]]:
    """去掉「先走远再折回来」的鼓包。

    典型场景：目标点（如 保俶路 2 号的酒吧）落在院子/楼里，OSRM 把人行道吸附到
    楼北侧，于是路线先往北走到路口、再折回南边进门——地图上就是一段凭空多出来的三角。
    这里检测「离终点距离的局部极大值」，把鼓包那一段切掉，直接连到终点。
    """
    if len(pts) < 6:
        return pts
    end = pts[-1]
    for _ in range(3):                       # 最多处理 3 个鼓包
        d = [haversine(p, end) for p in pts]
        cut = None
        for i in range(2, len(pts) - 2):
            if (d[i] > min_bulge_m and d[i] >= d[i - 1] + 8 and d[i] >= d[i + 1] + 8):
                k = i - 1
                while k > 0 and d[k] < d[i]:
                    k -= 1
                if k < i - 1:
                    cut = (k, i)
                    break
        if not cut:
            break
        k, i = cut
        pts = pts[:k + 1] + pts[i + 1:]
    return pts


def _trim_tail_loop(pts: List[Tuple[float, float]], tol_m: float = 18.0,
                    max_loop_m: float = 220.0) -> List[Tuple[float, float]]:
    """把「走进院子/死胡同再原路退出来」的尾巴截掉，只留一条直线到门口。

    步行路网里，POI 若落在院子、小区、码头内部，OSRM 会先绕进去再出来，
    画在地图上就是一段凭空多出来的三角形/回折——用户第一眼就当成 bug。
    这里只处理**最后一段**：若终点附近有一条自己折回来的尾巴，就把中间的点删掉。
    """
    n = len(pts)
    if n < 6:
        return pts
    end = pts[-1]
    loop_len = 0.0
    for i in range(n - 2, max(2, n - 25) - 1, -1):
        loop_len += haversine(pts[i], pts[i + 1])
        if loop_len > max_loop_m:
            break
        if haversine(pts[i], end) <= tol_m and (n - 1 - i) >= 4:
            return pts[:i + 1] + [end]
    return pts


def _strip_spikes(pts: list[tuple[float, float]], back_m: float = 18.0,
                  depth: int = 4) -> list[tuple[float, float]]:
    """去掉「走出去又原路退回来」的小尖刺（OSRM 吸附产生），画在地图上很难看。"""
    if len(pts) < 4:
        return pts
    out: list[tuple[float, float]] = []
    i = 0
    n = len(pts)
    while i < n:
        drop = 0
        for k in range(2, depth + 1):
            j = i + k
            if j >= n:
                break
            if haversine(pts[i], pts[j]) < back_m:
                drop = k
                break
        if drop:
            out.append(pts[i])
            i += drop + 1
        else:
            out.append(pts[i])
            i += 1
    return out if len(out) >= 2 else pts


def _osrm(coords: list[tuple[float, float]], mode: str = "walk",
          steps: bool = False) -> dict[str, Any] | None:
    """coords = [(lat,lng), ...]，按顺序串起来请求一次路网。steps=True 时额外取街道名。"""
    prof, mv = PROFILES.get(mode, PROFILES["walk"])
    key = ("s_" if steps else "") + mode + "_" + "_".join("%.5f_%.5f" % gcj2wgs(a, b) for a, b in coords)
    fp = os.path.join(ROUTE_DIR, key + ".json")
    try:
        if os.path.exists(fp) and time.time() - os.path.getmtime(fp) < CACHE_TTL * 7:
            ROUTE_STATS["cache_hits"] += 1
            return json.load(open(fp, encoding="utf-8"))
    except Exception:
        pass
    _packed = _read_route_pack(key + ".json")
    if _packed is not None:
        ROUTE_STATS["cache_hits"] += 1
        return _packed
    wgs_in = [gcj2wgs(p[0], p[1]) for p in coords]      # OSRM 只认 WGS-84
    url = OSRM_URL.format(prof=prof, mv=mv,
                          coords=";".join("%.6f,%.6f" % (q[1], q[0]) for q in wgs_in))
    if steps:
        url += "&steps=true"
    d = None
    for _attempt in (1, 2):
        try:
            with urllib.request.urlopen(url, timeout=OSRM_TIMEOUT) as r:
                d = json.loads(r.read().decode("utf-8"))
            break
        except Exception as e:  # noqa: BLE001
            if _attempt == 2:
                print(f"[warn] 路网请求失败（{e}），该段改走兜底", file=sys.stderr)
                ROUTE_STATS["failed"] += 1
                return None
            time.sleep(0.8)
    ROUTE_STATS["calls"] += 1
    try:
        route = (d.get("routes") or [None])[0]
        if not route:
            ROUTE_STATS["failed"] += 1
            return None
        wgs = [(p[1], p[0]) for p in route["geometry"]["coordinates"]]
        geom = _trim_tail_loop(_strip_spikes([wgs2gcj(la, ln) for la, ln in wgs]))
        out = {"distance": route["distance"], "duration": route["duration"],
               "geometry": geom}
        if steps:
            names: list[str] = []
            for st in ((route.get("legs") or [{}])[0].get("steps") or []):
                nm = (st.get("name") or "").strip()
                if nm and nm not in names:
                    names.append(nm)
            out["streets"] = names[:6]
        os.makedirs(ROUTE_DIR, exist_ok=True)
        json.dump(out, open(fp, "w", encoding="utf-8"))
        return out
    except Exception as e:
        ROUTE_STATS["failed"] += 1
        print(f"[warn] 路网请求失败（{e}），该段退回直线", file=sys.stderr)
        return None


def _osrm_nearest(pt: tuple[float, float], mode: str = "walk") -> dict[str, Any] | None:
    """把 POI 吸附到最近的路网上：返回 {lat, lng, dist, name}。

    这一步是「红线必须落在真实道路上」的关键：
    POI 坐标来自飞猪/高德，门店点在建筑内部，离马路几十米很常见；
    OSRM 会把端点吸附到路网，吸附后的点才是能走到的位置。
    """
    prof, mv = PROFILES.get(mode, PROFILES["walk"])
    _mk = (mode, round(pt[0], 5), round(pt[1], 5))
    if _mk in _NEAREST_MEMO:
        return _NEAREST_MEMO[_mk]
    _res = _osrm_nearest_uncached(pt, mode)
    _NEAREST_MEMO[_mk] = _res
    return _res


def _osrm_nearest_uncached(pt: tuple[float, float], mode: str = "walk") -> dict[str, Any] | None:
    prof, mv = PROFILES.get(mode, PROFILES["walk"])
    w = gcj2wgs(pt[0], pt[1])
    key = "near_%s_%.5f_%.5f" % (mode, w[0], w[1])
    fp = os.path.join(ROUTE_DIR, key + ".json")
    try:
        if os.path.exists(fp) and time.time() - os.path.getmtime(fp) < CACHE_TTL * 30:
            return json.load(open(fp, encoding="utf-8"))
    except Exception:
        pass
    _packed = _read_route_pack(key + ".json")
    if _packed is not None:
        return _packed
    url = (OSRM_HOST + "/routed-%s/nearest/v1/%s/%.6f,%.6f?number=1"
           % (prof, mv, w[1], w[0]))
    try:
        with urllib.request.urlopen(url, timeout=OSRM_TIMEOUT) as r:
            d = json.loads(r.read().decode("utf-8"))
        wp = ((d or {}).get("waypoints") or [None])[0]
        if not wp:
            return None
        lat, lng = wgs2gcj(wp["location"][1], wp["location"][0])
        out = {"lat": lat, "lng": lng, "dist": round(float(wp.get("distance") or 0), 1),
               "name": (wp.get("name") or "").strip()}
        os.makedirs(ROUTE_DIR, exist_ok=True)
        json.dump(out, open(fp, "w", encoding="utf-8"), ensure_ascii=False)
        return out
    except Exception:
        return None


def _min_dist_to_hot(path: list[tuple[float, float]],
                     hot: list[tuple[float, float]]) -> float:
    """路径采样点到最近榜单点的距离（米）。没有榜单点就返回一大数。"""
    if not hot or not path:
        return 1e9
    step = max(1, len(path) // 40)
    best = 1e9
    for p in path[::step]:
        for h in hot:
            d = haversine(p, h)
            if d < best:
                best = d
    return best


def _waypoint(a: tuple[float, float], b: tuple[float, float],
              frac: float, sign: int, offset_m: float) -> tuple[float, float]:
    """在 a→b 连线上 frac 处向侧面推 offset 米，做一个绕行途经点。"""
    lat = a[0] + (b[0] - a[0]) * frac
    lng = a[1] + (b[1] - a[1]) * frac
    dy = b[0] - a[0]
    dx = b[1] - a[1]
    norm = (dx * dx + dy * dy) ** 0.5 or 1e-9
    off_lat = (-dx / norm) * sign * offset_m / 111320.0
    off_lng = (dy / norm) * sign * offset_m / (111320.0 * math.cos(math.radians(lat)))
    return (lat + off_lat, lng + off_lng)


def _has_backtrack(pts: list[tuple[float, float]], tol_m: float = 12.0) -> bool:
    """路径里出现「走进去再原路走出来」的毛刺：非相邻两点靠得异常近。"""
    n = len(pts)
    if n < 6:
        return False
    step = max(1, n // 60)
    idx = list(range(0, n, step))
    for a in range(len(idx)):
        for b in range(a + 3, len(idx)):
            i, j = idx[a], idx[b]
            if haversine(pts[i], pts[j]) < tol_m and abs(j - i) > 3:
                return True
    return False

LEG_DIR = os.path.join(CACHE_DIR, "legs")
LEG_TTL_DAYS = float(os.environ.get("DETOUR_LEG_TTL_DAYS") or 30)


def _leg_key(a: tuple[float, float], b: tuple[float, float], mode: str) -> str:
    """两点路段缓存键：坐标取 4 位小数（≈11 m），端点顺序无关。"""
    p1 = "%.4f_%.4f" % (a[0], a[1])
    p2 = "%.4f_%.4f" % (b[0], b[1])
    lo, hi = sorted([p1, p2])
    return "leg_%s_%s_%s" % (mode, lo, hi)


def _leg_cached(a, b, mode):
    fp = os.path.join(LEG_DIR, _leg_key(a, b, mode) + ".json")
    try:
        if not os.path.exists(fp):
            return None
        if time.time() - os.path.getmtime(fp) > LEG_TTL_DAYS * 86400:
            return None
        d = json.load(open(fp, encoding="utf-8"))
        if not d.get("geometry"):
            return None
        d["cached"] = True
        return d
    except Exception:
        return None


def _leg_store(a, b, mode, res):
    if not res or not res.get("geometry"):
        return
    try:
        os.makedirs(LEG_DIR, exist_ok=True)
        json.dump(res, open(os.path.join(LEG_DIR, _leg_key(a, b, mode) + ".json"),
                            "w", encoding="utf-8"), ensure_ascii=False)
    except Exception:
        pass


def route_leg(a: tuple[float, float], b: tuple[float, float], mode: str = "walk",
              hot: list[tuple[float, float]] | None = None,
              avoid: bool = True) -> dict[str, Any] | None:
    """带进程内 memo + 30 天磁盘缓存的 route_leg。

    磁盘缓存（`.cache/legs/`）是省配额的关键：同一批演示路线重复跑时，
    步行段不再打 OSRM / 高德，直接命中缓存。坐标按 4 位小数（≈11 m）归档。
    """
    if mode in ("walk", "bike"):
        _c = _leg_cached(a, b, mode)
        if _c:
            ROUTE_STATS["leg_cache_hits"] = ROUTE_STATS.get("leg_cache_hits", 0) + 1
            return _c
    if not hot and not avoid:
        _k = (mode, round(a[0], 5), round(a[1], 5), round(b[0], 5), round(b[1], 5))
        if _k in _LEG_MEMO:
            return _LEG_MEMO[_k]
        _r = _route_leg_raw(a, b, mode, hot, avoid)
        _LEG_MEMO[_k] = _r
        if mode in ("walk", "bike"):
            _leg_store(a, b, mode, _r)
        return _r
    _r2 = _route_leg_raw(a, b, mode, hot, avoid)
    if mode in ("walk", "bike"):
        _leg_store(a, b, mode, _r2)
    return _r2


def _route_leg_raw(a: tuple[float, float], b: tuple[float, float], mode: str = "walk",
                   hot: list[tuple[float, float]] | None = None,
                   avoid: bool = True) -> dict[str, Any] | None:
    """两点之间的真实路径。

    步行优先高德（与页面底图同源），高德不可用才回落 OSRM；两条都是真实路网。
    关键约束：**取不到路网就返回 None，绝不返回 [a,b] 直线**。调用方负责把
    这一段留空/提示，而不是画一条穿楼过河的假线。
    """
    if hot:
        # 起终点自己周边的榜单点不算「穿过人流高地」——那是你落脚的地方，绕不开
        hot = [h for h in hot
               if haversine(a, h) > 250 and haversine(b, h) > 250] or None
    oa, ob = a, b
    na = nb = None
    base: dict[str, Any] | None = None
    # 高德步行与 Amap 底图同一套路网；有 Key 时优先它，避免 OSRM/OSM 线画在
    # 高德瓦片上出现「地图里没有这条路」。可用 DETOUR_ROUTE_PROVIDER=osrm 强制回退。
    use_amap = (mode == "walk" and bool(AMAP_KEY) and AMAP_PRIMARY)
    tried_amap = False
    if use_amap:
        tried_amap = True
        aw = amap_walking(oa, ob, AMAP_KEY)
        if aw:
            base = {"distance": float(aw["distance"]), "duration": float(aw["duration"]),
                    "geometry": aw["geometry"], "streets": aw.get("streets") or [],
                    "source": "amap"}
            ROUTE_STATS["amap_legs"] = ROUTE_STATS.get("amap_legs", 0) + 1
    if base is None:
        # OSRM/兜底路径：先把两端 POI 吸附到最近路网。门店点常在建筑内部，
        # 离马路几十米，直接拿它当端点会让红线从楼里穿出来。
        na, nb = _osrm_nearest(oa, mode), _osrm_nearest(ob, mode)
        if na and na["dist"] > SNAP_MIN_M:
            a = (na["lat"], na["lng"])
        if nb and nb["dist"] > SNAP_MIN_M:
            b = (nb["lat"], nb["lng"])
        for _nm, _n in ((oa, na), (ob, nb)):
            if _n and _n["dist"] > 200:
                print(f"[warn] {_nm} 离最近路网 {_n['dist']:.0f} m，坐标可能不准"
                      f"（已按 {_n.get('name') or '最近道路'} 吸附）", file=sys.stderr)
        base = _osrm([a, b], mode, steps=(mode in ("walk", "bike")))
        if base is None and mode == "walk" and AMAP_KEY and not tried_amap:
            # OSRM 取不到（人行路网缺口 / 服务抖动）→ 换高德步行，仍然是真实路网
            aw = amap_walking(a, b, AMAP_KEY)
            if aw:
                base = {"distance": float(aw["distance"]), "duration": float(aw["duration"]),
                        "geometry": aw["geometry"], "streets": aw.get("streets") or [],
                        "source": "amap"}
                tried_amap = True
                ROUTE_STATS["amap_legs"] = ROUTE_STATS.get("amap_legs", 0) + 1
                print("[info] 该段 OSRM 无结果，改用高德步行路网", file=sys.stderr)
    if base is None:
        ROUTE_STATS["leg_fail"] = ROUTE_STATS.get("leg_fail", 0) + 1
        return None
    base.setdefault("source", "osrm")
    ROUTE_STATS["leg_ok"] = ROUTE_STATS.get("leg_ok", 0) + 1
    base["avoided"] = False
    base["snap_a_m"] = int(na["dist"]) if na else 0
    base["snap_b_m"] = int(nb["dist"]) if nb else 0
    base["access"] = ([[round(oa[0], 6), round(oa[1], 6)],
                       [round(a[0], 6), round(a[1], 6)]] if a != oa else None)
    base["access_b"] = ([[round(b[0], 6), round(b[1], 6)],
                         [round(ob[0], 6), round(ob[1], 6)]] if b != ob else None)
    base["via"] = None
    base["hot_min_m"] = int(_min_dist_to_hot(base["geometry"], hot or []))
    straight_m = haversine(a, b)

    # 高德结果不再用 OSRM 做「中点/绕行」优化：混入 OSM 线会重新造成底图错位。
    # 高德路网本身已经贴合高德底图，宁可少绕一次，也不画一条地图上没有的线。
    if base.get("source") == "amap":
        return base

    # 直连明显绕远（多半是人行路网被河/快速路隔断）→ 再试一条「从中点穿过去」的合法路线，
    # 谁短用谁。OSRM 给的是它认为最短的，但吸附点有时落在远侧，多试一刀常能省一截。
    if TRY_SHORTCUT and base["distance"] > straight_m * 1.3 and base["distance"] - straight_m > 120:
        mid = ((a[0] + b[0]) / 2.0, (a[1] + b[1]) / 2.0)
        alt = _osrm([a, mid, b], mode, steps=(mode in ("walk", "bike")))
        if (alt and not _has_backtrack(alt["geometry"], tol_m=25.0)
                and alt["distance"] < base["distance"] * 0.95):
            alt["avoided"] = False
            alt["via"] = [round(mid[0], 5), round(mid[1], 5)]
            alt["hot_min_m"] = int(_min_dist_to_hot(alt["geometry"], hot or []))
            alt["straight_m"] = straight_m
            alt["source"] = "osrm"
            base = alt

    if not avoid or not hot or base["hot_min_m"] >= HOT_AVOID_M:
        return base

    best = base
    for frac in (0.5, 0.33, 0.67):
        for sign in (-1, 1):
          for off in (DETOUR_OFFSET_M, 140.0, 320.0):
            w = _waypoint(a, b, frac, sign, off)
            ROUTE_STATS["avoid_attempts"] += 1
            r = _osrm([a, w, b], mode)
            if not r or r["distance"] > base["distance"] * DETOUR_MAX:
                continue
            if _has_backtrack(r["geometry"]):          # 钻进巷子再原路退出来，画出来是毛刺
                continue
            d = _min_dist_to_hot(r["geometry"], hot)
            if d > best.get("hot_min_m", 0) + 15:
                r["avoided"] = True
                r["via"] = [round(w[0], 5), round(w[1], 5)]
                r["hot_min_m"] = int(d)
                r["source"] = "osrm"
                best = r
    return best

# 技能包自带一把「默认高德 Key」：云端会话常常忘了注入环境变量，
# 没 Key 就连周边吃/看、酒店兜底都拿不到，用户看到的就是「什么都没有」。
# 优先级：环境变量 > 包内 scripts/amap_key.txt（部署时放，别提交到公开仓库）。
_AMAP_KEY_DEFAULT = ""
for _cand in (os.path.join(os.path.dirname(os.path.abspath(__file__)), "amap_key.txt"),
              os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                           "amap_key.txt")):
    try:
        if os.path.exists(_cand):
            _AMAP_KEY_DEFAULT = open(_cand, encoding="utf-8").read().strip()
            if _AMAP_KEY_DEFAULT:
                break
    except Exception:
        pass
# 包内默认飞猪 Key（同 amap_key.txt 的做法）
_FLYAI_KEY_DEFAULT = ""
for _cand2 in (os.path.join(os.path.dirname(os.path.abspath(__file__)), "flyai_key.txt"),
               os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                            "flyai_key.txt")):
    try:
        if os.path.exists(_cand2):
            _FLYAI_KEY_DEFAULT = open(_cand2, encoding="utf-8").read().strip()
            if _FLYAI_KEY_DEFAULT:
                break
    except Exception:
        pass

AMAP_KEY = (os.environ.get("AMAP_KEY") or os.environ.get("AMAP_WEB_KEY")
            or os.environ.get("AMAP_KEY_WEB") or _AMAP_KEY_DEFAULT)
# 有高德 Key 时默认用高德步行：与 Amap 底图同源，避免 OSM 线画在高德路上错位。
# 设 DETOUR_ROUTE_PROVIDER=osrm 可强制走 OSRM（调试/离线对照用）。
# 路径来源：默认 **OSRM 优先**（免费、不烧高德配额），取不到再回落高德步行。
# 想切回「高德优先」：DETOUR_ROUTE_PROVIDER=amap
AMAP_PRIMARY = (os.environ.get("DETOUR_ROUTE_PROVIDER", "osrm").strip().lower() == "amap")
AMAP_TRANSIT = "https://restapi.amap.com/v3/direction/transit/integrated"
AMAP_DRIVING = "https://restapi.amap.com/v3/direction/driving"


AMAP_TIMEOUT = float(os.environ.get("DETOUR_AMAP_TIMEOUT") or 8.0)
# 高德个人版 QPS=3：并发线程一起打会 CUQPS_HAS_EXCEEDED_THE_LIMIT，统一排队
AMAP_MIN_INTERVAL = float(os.environ.get("DETOUR_AMAP_INTERVAL") or 0.34)
OSRM_TIMEOUT = float(os.environ.get("DETOUR_OSRM_TIMEOUT") or 8.0)


def _amap_get(url: str, params: dict[str, str], key: str) -> dict[str, Any] | None:
    """请求高德 Web 服务接口，失败返回 None（不抛异常，调用方自己降级）。"""
    # 搜索类配额一旦判死，就别再一站一站地去撞墙了（每站两次也是钱 / 也是时间）
    if STATS.get("amap_quota_dead") and "/place/" in url:
        return None
    q = dict(params)
    q["key"] = key
    qs = urllib.parse.urlencode(q)
    _amap_pace(AMAP_MIN_INTERVAL)      # 所有高德请求统一排队，避免 CUQPS 超限
    try:
        with urllib.request.urlopen(url + "?" + qs, timeout=AMAP_TIMEOUT) as r:
            d = json.loads(r.read().decode("utf-8"))
    except Exception as e:
        print(f"[warn] 高德请求失败：{e}", file=sys.stderr)
        return None
    if str(d.get("status")) != "1":
        if str(d.get("infocode")) == "10021":        # QPS 超限：等一拍再试
            time.sleep(1.2)
            try:
                with urllib.request.urlopen(url + "?" + qs, timeout=AMAP_TIMEOUT) as r:
                    d = json.loads(r.read().decode("utf-8"))
            except Exception:
                return None
            if str(d.get("status")) == "1":
                return d
        _info = str(d.get("info") or "")
        if any(h in _info for h in AMAP_QUOTA_HINT):
            # 当日配额用尽：后面每次搜索类调用都会同样失败，直接转飞猪兜底
            if not STATS.get("amap_quota_dead"):
                print(f"[warn] 高德搜索类接口配额用尽（{_info}），"
                      f"每站「吃什么 / 看什么」改用城市池 / 飞猪兜底", file=sys.stderr)
            STATS["amap_quota_dead"] = True
            return None
        print(f"[warn] 高德返回错误：{d.get('info')}（infocode={d.get('infocode')}）", file=sys.stderr)
        return None
    return d


def _polyline(pl: str) -> list[tuple[float, float]]:
    out = []
    for pair in (pl or "").split(";"):
        if "," in pair:
            try:
                lng_s, lat_s = pair.split(",")[:2]
                out.append((float(lat_s), float(lng_s)))
            except ValueError:
                continue
    return out


def amap_transit(a: tuple[float, float], b: tuple[float, float], city: str,
                 key: str) -> dict[str, Any] | None:
    """公交换乘（含地铁）：返回 {distance, duration, path, lines, walk_m, taxi_cost}。"""
    fp = os.path.join(ROUTE_DIR, "amap_transit_%.5f_%.5f_%.5f_%.5f.json" % (a[0], a[1], b[0], b[1]))
    try:
        if os.path.exists(fp) and time.time() - os.path.getmtime(fp) < CACHE_TTL:
            return json.load(open(fp, encoding="utf-8"))
    except Exception:
        pass
    d = _amap_get(AMAP_TRANSIT, {
        "origin": "%.6f,%.6f" % (a[1], a[0]),
        "destination": "%.6f,%.6f" % (b[1], b[0]),
        "city": city, "cityd": city,
        "strategy": "1", "nightflag": "0", "extensions": "all",
    }, key)
    if not d:
        return None
    route = (d.get("route") or {})
    transits = route.get("transits") or []
    if not transits:
        print("[warn] 高德没算出公交方案（可能距离太近，建议步行）", file=sys.stderr)
        return None
    t = transits[0]
    path: list[tuple[float, float]] = []
    lines, walk_m, bus_m = [], 0.0, 0.0
    for seg in t.get("segments") or []:
        walk = seg.get("walking") or {}
        walk_m += float(walk.get("distance") or 0)
        for st in walk.get("steps") or []:
            path += _polyline(st.get("polyline", ""))
        bus = seg.get("bus") or {}
        bls = bus.get("buslines") or []
        if bls:
            bl = bls[0]                      # 高德会给多条备选线路，取第一条就是它推荐的那班
            bus_m += float(bl.get("distance") or 0)
            via = bl.get("via_num")
            stops = int(via) if via not in (None, "") else len(bl.get("stops") or [])
            name = (bl.get("name") or "").split("(")[0].strip()
            dep = bl.get("departure_stop") or {}
            arr = bl.get("arrival_stop") or {}
            dep_loc = dep.get("location") or ""
            arr_loc = arr.get("location") or ""
            lines.append({
                "line": name,
                "from": dep.get("name") or "",
                "to": arr.get("name") or "",
                "stops": stops,
                "duration_min": round(float(bl.get("duration") or 0) / 60),
                "board": [float(x) for x in dep_loc.split(",")] if "," in dep_loc else None,
                "alight": [float(x) for x in arr_loc.split(",")] if "," in arr_loc else None,
            })
            path += _polyline(bl.get("polyline", ""))
        rail = seg.get("railway") or {}
        if rail.get("name"):
            lines.append({"line": rail.get("name"),
                          "from": (rail.get("departure_stop") or {}).get("name") or "",
                          "to": (rail.get("arrival_stop") or {}).get("name") or "",
                          "stops": 0,
                          "duration_min": round(float(rail.get("time") or 0) / 60)})
    out = {
        "distance": float(t.get("distance") or route.get("distance") or 0),
        "duration": float(t.get("duration") or 0),
        "path": path,
        "lines": lines,
        "access_m": int(walk_m),
        "bus_m": int(bus_m),
        "cost": float(t.get("cost") or 0) or None,
        "taxi_cost": float(t.get("taxi_cost") or 0) or None,
    }
    # 上车取第一条线路的出发站，下车取最后一条线路的到达站（换乘时也能画到终点站）
    for ln in lines:
        if ln.get("board"):
            out["board"] = ln["board"]
            break
    for ln in reversed(lines):
        if ln.get("alight"):
            out["alight"] = ln["alight"]
            break
    if lines:
        out["line_names"] = "→".join([l["line"] for l in lines if l.get("line")])
        out["stops_total"] = sum(int(l.get("stops") or 0) for l in lines)
    if not out["taxi_cost"]:
        km = out["distance"] / 1000.0
        out["taxi_est"] = int(round(13 + max(0.0, km - 3.0) * 2.5))
        out["taxi_note"] = "按起步 13 元/3 km、之后 2.5 元/km 估算，非实时报价"
    else:
        out["taxi_est"] = int(out["taxi_cost"])
        out["taxi_note"] = "高德返回的出租车费"
    try:
        os.makedirs(ROUTE_DIR, exist_ok=True)
        json.dump(out, open(fp, "w", encoding="utf-8"))
    except Exception:
        pass
    return out


AMAP_WALKING = "https://restapi.amap.com/v3/direction/walking"


def amap_walking(a: tuple[float, float], b: tuple[float, float],
                 key: str) -> dict[str, Any] | None:
    """高德步行路径：OSRM 取不到时的第二数据源（结果同样是真实路网）。"""
    d = _amap_get(AMAP_WALKING, {
        "origin": "%.6f,%.6f" % (a[1], a[0]),
        "destination": "%.6f,%.6f" % (b[1], b[0]),
    }, key)
    if not d:
        return None
    routes = (d.get("route") or {}).get("paths") or []
    if not routes:
        return None
    p0 = routes[0]
    path: list[tuple[float, float]] = []
    for st in p0.get("steps") or []:
        path += _polyline(st.get("polyline", ""))
    if len(path) < 2:
        return None
    names: list[str] = []
    for st in p0.get("steps") or []:
        nm = (st.get("road") or "").strip()
        if nm and nm not in names:
            names.append(nm)
    return {"distance": float(p0.get("distance") or 0),
            "duration": float(p0.get("duration") or 0),
            "geometry": path, "streets": names[:6], "source": "amap"}


def amap_driving(a: tuple[float, float], b: tuple[float, float], key: str) -> dict[str, Any] | None:
    """驾车/打车：给距离、时长和打车费（taxi_cost）。"""
    d = _amap_get(AMAP_DRIVING, {
        "origin": "%.6f,%.6f" % (a[1], a[0]),
        "destination": "%.6f,%.6f" % (b[1], b[0]),
        "extensions": "all", "strategy": "0",
    }, key)
    if not d:
        return None
    routes = (d.get("route") or {}).get("paths") or []
    if not routes:
        return None
    p0 = routes[0]
    path: list[tuple[float, float]] = []
    for st in p0.get("steps") or []:
        path += _polyline(st.get("polyline", ""))
    km = float(p0.get("distance") or 0) / 1000.0
    return {"distance": float(p0.get("distance") or 0),
            "duration": float(p0.get("duration") or 0),
            "path": path,
            "taxi_est": int(round(13 + max(0.0, km - 3.0) * 2.5)),
            "taxi_note": "按起步 13 元/3 km、之后 2.5 元/km 估算，非实时报价"}



# —— 主题点库：飞猪 POI 是「旅游供给」，ACG / 老洋房这类消费点基本不在里面，
# 用类目兜底会凑出美术馆和夜市。这里按主题词直接问高德要，建成本地清单（30 天）。
# 主题没候选时的邻近主题（按优先级）
# 主题点库覆盖的城市（随包发布）；其它城市运行时按需现建
THEME_CITIES: list[str] = [
    "杭州", "上海", "北京", "成都", "西安", "南京", "苏州", "广州", "深圳", "厦门",
    "重庆", "武汉", "长沙", "青岛", "天津", "昆明", "桂林", "哈尔滨", "大连", "三亚",
]

THEME_FALLBACK: dict[str, list[str]] = {
    "夜游": ["建筑", "自由", "美食"],
    "动漫": ["自由", "建筑"],
    "非遗": ["建筑", "自由"],
    "建筑": ["自由", "非遗"],
    "美食": ["自由", "夜游"],
    "自由": [],
}

THEME_AMAP_KEYWORDS: dict[str, list[str]] = {
    "动漫": ["漫展", "手办", "谷子", "二次元", "电玩城", "动漫城"],
    "建筑": ["老洋房", "教堂", "历史建筑", "文物保护单位", "民国建筑", "老码头",
             "骑楼", "老街区", "旧址", "古镇", "祠堂", "牌坊", "塔", "故居", "会馆"],
    "非遗": ["非遗", "手作", "作坊", "老字号", "传习所",
             "工坊", "技艺", "民俗馆", "剪纸", "泥塑", "糖画"],
    "夜游": ["夜市", "夜景", "游船", "灯光秀", "酒吧街", "观景台", "夜宵"],
    "美食": ["老字号", "菜市场", "小吃街", "food"],
}
THEME_AMAP_KEYWORDS.pop("美食")   # 美食走 enrich 的 place/around 更准，不在这里重复
THEME_DIR = os.path.join(CACHE_DIR, "themes")
# 随技能包一起发布的预建清单：云端会话首次用到某城市时不用现抓（省一次 Key 调用）
_HERE = os.path.dirname(os.path.abspath(__file__))
# 技能包里是 scripts/explore.py + data/themes/；仓库里是 explore.py + skill-package-engine/data/themes/
_PACK_CANDS = [
    os.path.join(_HERE, "data", "themes"),
    os.path.join(os.path.dirname(_HERE), "data", "themes"),
    os.path.join(_HERE, "skill-package-engine", "data", "themes"),
]
THEME_PACK_DIR = next((d for d in _PACK_CANDS if os.path.isdir(d)), _PACK_CANDS[0])
THEME_TTL = 30 * 24 * 3600
THIN_POINTS = 40          # 主题点库少于这个数就算「薄」，用飞猪补一遍

# 只是路名/街道名，不是「一个地方」——高德 place/text 常把整条路当 POI 返回
THEME_ROAD_SUFFIX = ("路", "街", "巷", "大道", "胡同", "弄")
THEME_PLACE_SUFFIX = ("店", "馆", "宫", "寺", "堂", "园", "楼", "塔", "桥", "码头",
                      "广场", "大厦", "中心", "旧址", "故居", "会馆", "书院", "博物馆")


def _is_road_name(name: str) -> bool:
    n = (name or "").strip()
    if not n or len(n) > 12:
        return False
    if any(x in n for x in THEME_PLACE_SUFFIX):
        return False
    return n.endswith(THEME_ROAD_SUFFIX) or n.endswith(THEME_ROAD_SUFFIX + ("东", "西", "南", "北"))


THEME_BAD_NAME = ("公司", "服务中心", "营业厅", "售楼", "中介", "培训", "幼儿园",
                  "小学", "中学", "大学", "医院", "诊所", "银行", "酒店", "宾馆",
                  "公寓", "小区", "花园", "基地", "工厂", "会所", "SPA", "spa",
                  "头疗", "熏蒸", "足浴", "棋牌", "麻将", "雀庄", "日麻", "茶楼", "足道", "推拿",
                  # 陵园/墓园一类：不是「走一条街」该出现的点（非遗点库里曾混进「阵亡将士墓」）
                  "陵园", "公墓", "墓园", "墓", "陵寝", "烈士", "殡仪", "火葬场", "纪念碑")
# 水上项目：点在江面上，步行线会穿河。整条线是「走」的，这类点直接不进候选池
THEME_WATER_NAME = ("游船", "游轮", "游艇", "轮渡", "渡口", "观光船", "浦江游览",
                    "游览快线", "游船码头", "水上巴士", "摆渡", "缆车", "码头", "船厂",
                    "观光巴士", "敞篷巴士", "观光车", "双层巴士",
                    # 名字里直接是水域/水上景区的点：坐标常在湖面/江面，步行线会下水
                    "荷花区", "荷区", "湖区", "湖心", "湖中", "水岸", "河岸", "江畔",
                    "海滩", "沙滩", "海湾", "岛上", "半岛", "湿地")


def _is_water_name(name: str | None) -> bool:
    """点/出发点名字是否明显是水上项目或水域景区。"""
    return bool(name) and any(w in str(name) for w in THEME_WATER_NAME)


ANCHOR_LAND_MAX_M = 120.0


def _land_entry(pt: tuple[float, float], name: str):
    """把水上锚点换成最近的陆上路口；桥面/距离过远则拒绝。

    码头/游船 POI 的坐标常落在水面上。直接拿它当起点，地图上的线就会从
    江面/湖面起笔。这里只接受 120 m 内、且不是桥面的最近路网点；否则请用户
    换一个陆上入口，而不是硬凑一条「水上步行线」。
    """
    near = _osrm_nearest(pt, "walk")
    if not near:
        return None, name, None
    road = str(near.get("name") or "")
    if road and near["dist"] <= ANCHOR_LAND_MAX_M and "桥" not in road:
        return (near["lat"], near["lng"]), name + "（最近路口）", near
    return None, name, near


def _route_point(stop: dict[str, Any]) -> tuple[float, float] | None:
    """取一个站点的「可步行坐标」：水上点自动落到最近陆上路口。

    站点 marker 仍用原 POI 坐标（sn），但路线从陆上入口起算；不会把线画进
    湖/江。找不到 120 m 内非桥面的路网就返回 None，让这一段留空。
    """
    pt = (float(stop["lat"]), float(stop["lng"]))
    if not _is_water_name(stop.get("name")):
        return pt
    land, _, _ = _land_entry(pt, str(stop.get("name") or ""))
    return land


def _sanitize_water_stops(stops: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """去掉/搬走路线里的水上点，返回可步行的站点列表。

    - 码头/游船/水域景区：能落到 120m 内有名字的陆上道路就搬过去；
    - 落不到（最近的是无名栈桥/桥面/太远）就直接删掉，并在 stderr 说明。
    这样手动 --order 里塞了「武林门码头」也不会让红线从水里起笔。
    """
    out: list[dict[str, Any]] = []
    for st in stops:
        nm = str(st.get("name") or "")
        if not _is_water_name(nm):
            out.append(st)
            continue
        land, _, near = _land_entry((float(st["lat"]), float(st["lng"])), nm)
        if land and near and str(near.get("name") or ""):
            moved = dict(st)
            moved["lat"], moved["lng"] = land
            out.append(moved)
            print(f"[info] 站点「{nm}」是水上点，路线改到最近陆上道路"
                  f"「{near.get('name')}」（{float(near.get('dist') or 0):.0f} m）", file=sys.stderr)
        else:
            print(f"[warn] 站点「{nm}」在水上/找不到陆上入口，已从步行路线剔除", file=sys.stderr)
    return out
# 只要这些大类：风景名胜(11) 科教文化(14) 购物(06) 体育休闲(08) 影剧院(13) 政府(16)
THEME_DROP_CATEGORIES: dict[str, set[str]] = {
    "动漫": {"市集", "历史古迹", "地标建筑", "自然风光", "山湖田园"},
    "非遗": {"市集"},
    # 夜游要的是「晚上能去」，白天景点/公园一律不要
    "夜游": {"自然风光", "山湖田园", "公园", "植物园"},
}
THEME_TYPE_PREFIX: dict[str, tuple[str, ...]] = {
    "动漫": ("06", "08", "11", "14", "13"),
    "建筑": ("11", "14", "16"),
    "非遗": ("11", "14", "06"),
    # 购物(06) 体育休闲(08) 餐饮(05) 影剧院(13) 风景(11) 文化(14)
    "夜游": ("13", "11", "14", "06", "08", "05"),
}


def _theme_fp(city: str, theme: str) -> str:
    os.makedirs(THEME_DIR, exist_ok=True)
    return os.path.join(THEME_DIR, f"{theme}_{city}.json")


def _pack_alias(city: str, theme: str, anchor_names: list[str] | None = None) -> list[dict[str, Any]]:
    """小城/古镇兜底：`--city 苏州 --anchor 同里古镇` 这类调用，点库其实只有 `建筑_同里.json`。

    依次用 anchor 里出现的地名去试 `<theme>_<名字>.json`，命中就返回（并记日志）。
    只返回**不为空**的点库，避免把空文件当真。
    """
    names: list[str] = []
    for nm in (anchor_names or []):
        nm = (nm or "").strip()
        if not nm:
            continue
        names.append(nm)
        # 「同里古镇」「乌镇西栅」这类后缀，再试一次去掉后缀的
        for suf in ("古镇", "古城", "西栅", "东栅", "景区", "老街", "县城"):
            if nm.endswith(suf) and len(nm) > len(suf):
                names.append(nm[: -len(suf)])
    for nm in names:
        fp = os.path.join(THEME_PACK_DIR, f"{theme}_{nm}.json")
        if not os.path.exists(fp):
            continue
        try:
            items = json.load(open(fp, encoding="utf-8"))
        except Exception:
            continue
        if items:
            print(f"[info] 主题点库：按出发点「{nm}」取到 {len(items)} 个点（{city} 无该主题点库）",
                  file=sys.stderr)
            return items
    return []


def build_theme_list(city: str, theme: str, key: str, force: bool = False) -> list[dict[str, Any]]:
    """按主题词建一座城市的点库（高德 place/text），30 天有效。"""
    kws = THEME_AMAP_KEYWORDS.get(theme) or []
    fp = _theme_fp(city, theme)
    if not force and os.path.exists(fp) and time.time() - os.path.getmtime(fp) < THEME_TTL:
        try:
            return json.load(open(fp, encoding="utf-8"))
        except Exception:
            pass
    packed = os.path.join(THEME_PACK_DIR, f"{theme}_{city}.json")
    if not force and os.path.exists(packed):
        try:
            items = json.load(open(packed, encoding="utf-8"))
            json.dump(items, open(fp, "w", encoding="utf-8"), ensure_ascii=False)
            print(f"[info] 主题点库：{city}·{theme} 用随包预建数据 {len(items)} 个点", file=sys.stderr)
            return items
        except Exception:
            pass
    if not kws:
        return []


    def _from_flyai() -> list[dict[str, Any]]:
        """没有高德 Key 时的现抓：用飞猪 POI 按主题类目/关键词兜一份点库。

        飞猪本身不需要 AMAP_KEY，这样「包内 20 城之外」的城市也能现建。
        """
        out: list[dict[str, Any]] = []
        try:
            ps = fetch_pois(city, theme)
        except Exception:  # noqa: BLE001
            ps = []
        for q in ps:
            name = (q.get("name") or "").strip()
            lat, lng = q.get("lat"), q.get("lng")
            if not name or lat is None or lng is None:
                continue
            if (_is_road_name(name) or any(b in name for b in THEME_BAD_NAME)
                    or any(w in name for w in THEME_WATER_NAME)):
                continue
            out.append({"name": name, "lat": float(lat), "lng": float(lng),
                        "type": q.get("category") or "", "addr": q.get("address") or "",
                        "kw": "flyai"})
        return out

    if not key:
        if not os.environ.get("DETOUR_NO_FLYAI_THEME"):
            items = _from_flyai()
            if items:
                json.dump(items, open(fp, "w", encoding="utf-8"), ensure_ascii=False)
                print(f"[info] 主题点库：{city}·{theme} 无高德 Key，用飞猪现建 {len(items)} 个点",
                      file=sys.stderr)
                return items
        print(f"[warn] 主题点库：{city}·{theme} 未覆盖，且没有 AMAP_KEY / 飞猪也不可用",
              file=sys.stderr)
        return []

    seen: dict[str, dict[str, Any]] = {}
    for kw in kws:
        for page in ("1", "2"):
            d = _amap_get(AMAP_TEXT, {"keywords": kw, "city": city, "citylimit": "true",
                                      "offset": "25", "page": page, "extensions": "base"}, key)
            if not d or not (d.get("pois") or []):
                break
            for q in (d.get("pois") or []):
                name = (q.get("name") or "").strip()
                loc = q.get("location") or ""
                if not name or "," not in loc or name in seen:
                    continue
                if (_is_road_name(name) or any(b in name for b in THEME_BAD_NAME)
                    or any(w in name for w in THEME_WATER_NAME)):
                    continue
                code = str(q.get("typecode") or "")
                allow = THEME_TYPE_PREFIX.get(theme)
                if allow and not code.startswith(allow):
                    continue
                lng, lat = loc.split(",")[:2]
                try:
                    lat_f, lng_f = float(lat), float(lng)
                except ValueError:
                    continue
                seen[name] = {
                    "name": name,
                    "lat": lat_f, "lng": lng_f,
                    "type": (q.get("type") or "").split(";")[-1],
                    "addr": q.get("address") if isinstance(q.get("address"), str) else "",
                    "kw": kw,
                }
            time.sleep(0.25)
    items = list(seen.values())
    # 主题偏薄（<40 个点）时用飞猪同主题候选补一遍：老城区/小城市很常见
    if len(items) < THIN_POINTS:
        names = {it["name"] for it in items}
        extra = [x for x in _from_flyai() if x["name"] not in names]
        if extra:
            items += extra
            print(f"[info] 主题点库：{city}·{theme} 偏薄，用飞猪补 {len(extra)} 个点",
                  file=sys.stderr)
    json.dump(items, open(fp, "w", encoding="utf-8"), ensure_ascii=False)
    print(f"[info] 主题点库：{city}·{theme} 收录 {len(items)} 个点", file=sys.stderr)
    return items


def theme_pois(city: str, theme: str, key: str, anchor_name: str | None = None) -> list[dict[str, Any]]:
    """把主题点库转成和飞猪 POI 同构的字典，好让后面的打分/聚类直接吃。"""
    out = []
    items = build_theme_list(city, theme, key)
    if len(items) < 12 and anchor_name:
        # 「--city 苏州 --anchor 同里古镇」这种：city 的点库里没有古镇的点，
        # 但随包里存着一份 `建筑_同里.json`，用出发点名再试一次。
        alt = _pack_alias(city, theme, [anchor_name])
        if len(alt) > len(items):
            items = alt
    for it in items:
        out.append({
            "name": it["name"],
            "category": it.get("type") or theme,
            "address": it.get("addr") or "",
            "latitude": it["lat"], "longitude": it["lng"],
            "lat": it["lat"], "lng": it["lng"],
            "description": f"{it.get('type','')}（高德主题库 · 关键词「{it.get('kw','')}」）",
            "listRank": None, "poiLevel": None, "freePoiStatus": "UNKNOWN",
            "jumpUrl": None, "mainPic": None, "ticketInfo": None,
            "src": "amap-theme",
        })
    return out


AMAP_AROUND = "https://restapi.amap.com/v3/place/around"
AMAP_TEXT = "https://restapi.amap.com/v3/place/text"


# ---------------------------------------------------------------- 城市文化清单
CULTURE_DIR = os.path.join(CACHE_DIR, "culture")
CULTURE_TTL = 30 * 24 * 3600

# 只收真正「文化」的类目：博物馆/展览馆/美术馆/文化宫/档案馆 + 风景名胜里的故居园林
CULTURE_TYPE_PREFIX = ("1401", "1402", "1403", "1405", "1406", "1407", "1408",
                       "1101", "1102", "1103", "1104")
CULTURE_KEYWORDS = ("非遗", "故居", "纪念馆", "文物保护单位", "博物馆", "古建",
                    "历史建筑", "祠堂", "书院", "名人故居")

# 名字里带这些词的，一律当成「商业/休闲」，不是文化点
CULTURE_BAD_NAME = ("SPA", "spa", "头疗", "养生", "推拿", "足浴", "汗蒸", "按摩", "美容",
                    "酒店", "宾馆", "民宿", "餐厅", "饭店", "小吃", "咖啡", "奶茶", "茶馆",
                    "康养", "超市", "便利店", "药房", "药店", "医院", "诊所", "银行", "售楼")
# 这些类目属于消费/医疗，直接丢
CULTURE_BAD_TYPE = ("学校", "休闲场所", "医疗保健服务场所", "购物相关场所", "餐饮服务",
                    "住宿服务", "公司企业", "金融保险服务机构", "汽车", "加油站")

# 名字里出现这些词，说明更像「文化点」而不是商场
CULTURE_NAME_HINT = ("故居", "纪念馆", "博物馆", "美术馆", "书院", "祠堂", "遗址",
                     "文保", "非遗", "展馆", "展览馆", "文化馆", "档案", "寺", "塔",
                     "桥", "亭", "碑", "旧居", "公馆", "会馆", "戏台")


def _culture_fp(city: str) -> str:
    return os.path.join(CULTURE_DIR, "city_%s.json" % city)


def build_culture_list(city: str, key: str, force: bool = False) -> list[dict[str, Any]]:
    """把一座城市的「文化点」一次性收下来，存本地，30 天有效。"""
    fp = _culture_fp(city)
    if not force and os.path.exists(fp) and time.time() - os.path.getmtime(fp) < CULTURE_TTL:
        try:
            return json.load(open(fp, encoding="utf-8"))
        except Exception:
            pass
    items: dict[str, dict[str, Any]] = {}
    for kw in CULTURE_KEYWORDS:
      for page in ("1", "2"):
        d = _amap_get(AMAP_TEXT, {"keywords": kw, "city": city, "citylimit": "true",
                                  "offset": "25", "page": page, "extensions": "base"}, key)
        if not d or not (d.get("pois") or []):
            break
        for q in (d.get("pois") or []):
            name = (q.get("name") or "").strip()
            loc = q.get("location") or ""
            if not name or "," not in loc:
                continue
            code = str(q.get("typecode") or "")
            typ = (q.get("type") or "").split(";")[-1]
            if any(b in name for b in CULTURE_BAD_NAME):
                continue
            if any(b in typ for b in CULTURE_BAD_TYPE):
                continue
            if not (code.startswith(CULTURE_TYPE_PREFIX) or any(h in name for h in CULTURE_NAME_HINT)):
                continue
            lng, lat = loc.split(",")[:2]
            try:
                lat_f, lng_f = float(lat), float(lng)
            except ValueError:
                continue
            items[name] = {"name": name, "type": typ, "tag": q.get("tag") or "",
                           "addr": q.get("address") or "", "lat": lat_f, "lng": lng_f,
                           "kw": kw, "typecode": code}
        time.sleep(0.35)
    out = list(items.values())
    if out:
        try:
            os.makedirs(CULTURE_DIR, exist_ok=True)
            json.dump(out, open(fp, "w", encoding="utf-8"), ensure_ascii=False)
        except Exception:
            pass
    print(f"[info] 城市文化清单：{city} 收录 {len(out)} 个点", file=sys.stderr)
    return out


def culture_near(city: str, lat: float, lng: float, key: str,
                 radius: int = 800, count: int = 3) -> list[dict[str, Any]]:
    """从城市清单里按距离取这一站附近的文化点。"""
    items = build_culture_list(city, key)
    near = []
    for it in items:
        d = haversine((lat, lng), (it["lat"], it["lng"]))
        if d <= radius:
            near.append({"name": it["name"], "type": it.get("type"), "dist": int(d),
                         "kw": it.get("kw"), "lat": it.get("lat"), "lng": it.get("lng"),
                         "open_time": it.get("open_time")})
    near.sort(key=lambda x: x["dist"])
    # 同一站同名的去重，最多 count 个
    seen, out = set(), []
    for n in near:
        if n["name"] not in seen:
            seen.add(n["name"])
            out.append(n)
        if len(out) >= count:
            break
    return out


_AMAP_PACE_LOCK = threading.Lock()
_AMAP_LAST = [0.0]


def _amap_pace(min_interval: float = 0.0) -> None:
    """并发跑 enrich 时也要守住高德的 QPS：全局最小间隔，线程安全。"""
    with _AMAP_PACE_LOCK:
        now = time.time()
        gap = now - _AMAP_LAST[0]
        if gap < min_interval:
            time.sleep(min_interval - gap)
            now = time.time()
        _AMAP_LAST[0] = now


def amap_around(lat: float, lng: float, keywords: str, key: str,
                radius: int = 400, count: int = 3) -> list[dict[str, Any]]:
    """高德周边搜索：拿「这一站周围能吃到什么 / 能看到什么文化」。"""
    fp = os.path.join(ROUTE_DIR, "around_%.5f_%.5f_%s.json" % (lat, lng, keywords))
    try:
        if os.path.exists(fp) and time.time() - os.path.getmtime(fp) < CACHE_TTL * 3:
            return json.load(open(fp, encoding="utf-8"))[:count]
    except Exception:
        pass
    d = _amap_get(AMAP_AROUND, {
        "location": "%.6f,%.6f" % (lng, lat),
        "keywords": keywords, "radius": str(radius),
        "offset": "10", "page": "1", "extensions": "all",
        "sortrule": "distance",
    }, key)
    out: list[dict[str, Any]] = []
    for q in ((d or {}).get("pois") or []):
        biz = q.get("biz_ext") or {}
        typ = (q.get("type") or "").split(";")[-1]
        try:
            dist = int(float(q.get("distance") or 0))
        except (TypeError, ValueError):
            dist = None
        _ot = biz.get("open_time") or ""
        out.append({"name": q.get("name"), "type": typ, "dist": dist,
                    "rating": biz.get("rating"), "cost": biz.get("cost"),
                    "open_time": _ot,
                    "tag": q.get("tag") or "", "addr": q.get("address") or "",
                    "lng": q.get("location", "").split(",")[0] if q.get("location") else None,
                    "lat": q.get("location", "").split(",")[1] if "," in (q.get("location") or "") else None})
    if out:
        pool_add(CITY_HINT[0] if CITY_HINT else "", "food" if keywords == "美食" else "culture", out)
    if out:                                  # 空结果不落盘，免得把失败缓存三天
        try:
            os.makedirs(ROUTE_DIR, exist_ok=True)
            json.dump(out, open(fp, "w", encoding="utf-8"), ensure_ascii=False)
        except Exception:
            pass
    return out[:count]


AMENITY_DIR = os.path.join(CACHE_DIR, "amenities")
# 随包预热的周边数据：沙箱冷启动、高德配额归零时也能给出真实数据
_AMENITY_PACK_CANDS = [
    os.path.join(_HERE, "data", "amenities"),
    os.path.join(os.path.dirname(_HERE), "data", "amenities"),
    os.path.join(_HERE, "skill-package-engine", "data", "amenities"),
]
AMENITY_PACK_DIR = next((d for d in _AMENITY_PACK_CANDS if os.path.isdir(d)),
                        _AMENITY_PACK_CANDS[0])


def _pool_fp(city: str, kind: str) -> str:
    os.makedirs(AMENITY_DIR, exist_ok=True)
    return os.path.join(AMENITY_DIR, f"{kind}_{city}.json")


_POOL_LOCK = threading.Lock()


def pool_add(city: str, kind: str, items: list[dict[str, Any]]) -> None:
    """把高德拿到的「周围有什么」沉淀成城市级池子（无坐标依赖，按名去重）。

    目的：高德当日配额用尽时，还能用这座城以前跑出来的真实数据顶上，
    而不是拿飞猪那种「全城排行榜」硬凑。
    """
    if not city or not items:
        return
    with _POOL_LOCK:
        _pool_add_locked(city, kind, items)


def _pool_add_locked(city: str, kind: str, items: list[dict[str, Any]]) -> None:
    fp = _pool_fp(city, kind)
    pool: dict[str, dict[str, Any]] = {}
    try:
        if os.path.exists(fp):
            for it in json.load(open(fp, encoding="utf-8")):
                if it.get("name"):
                    pool[it["name"]] = it
    except Exception:
        pass
    for it in items:
        nm = it.get("name")
        if not nm or it.get("lat") in (None, "", 0) or it.get("lng") in (None, "", 0):
            continue
        try:
            rec = {"name": nm, "type": it.get("type"), "rating": it.get("rating"),
                   "cost": it.get("cost"), "open_time": it.get("open_time"),
                   "lat": float(it["lat"]), "lng": float(it["lng"])}
        except (TypeError, ValueError):
            continue
        pool[nm] = rec
    try:
        json.dump(list(pool.values()), open(fp, "w", encoding="utf-8"), ensure_ascii=False)
    except Exception:
        pass


def pool_near(city: str, kind: str, lat: float, lng: float,
              radius: int = 800, count: int = 3) -> list[dict[str, Any]]:
    """从城市池子里按距离取最近的点。"""
    fp = _pool_fp(city, kind)
    items: list[dict[str, Any]] = []
    for path in (fp, os.path.join(AMENITY_PACK_DIR, f"{kind}_{city}.json")):
        try:
            items = json.load(open(path, encoding="utf-8"))
            if items:
                break
        except Exception:
            continue
    if not items:
        return []
    out = []
    for it in items:
        try:
            d = haversine((lat, lng), (float(it["lat"]), float(it["lng"])))
        except (KeyError, TypeError, ValueError):
            continue
        if d > radius:
            continue
        out.append({**it, "dist": int(d)})
    out.sort(key=lambda x: x["dist"])
    return out[:count]


AMAP_QUOTA_HINT = ("OVER_LIMIT", "10044", "10003", "DAILY")
CITY_HINT: list[str] = []   # 当前跑的是哪座城（给 pool 用，免得每处都传 city）


def amap_quota_dead() -> bool:
    """这一轮跑下来，高德「搜索类」接口是不是已经因配额拒绝服务。"""
    return bool(STATS.get("amap_quota_dead"))


def flyai_around(city: str, lat: float, lng: float, keywords: str | list[str],
                 radius: int = 1200, count: int = 3) -> list[dict[str, Any]]:
    """飞猪兜底：高德搜索类额度用尽时，用它拿「这一站周围有什么」。

    飞猪 `search-poi` 没有半径参数、按相关度而非距离排序，所以要：
      1. 同一站多丢几个关键词（「餐厅」「小吃」「老字号」），把召回面撑开；
      2. 自己按坐标算距离、按距离排序；
      3. 超出 radius 的一律丢掉——宁可这一行留空，也不拿全城网红店糊弄。
    """
    if not city or not flyai_ready():
        return []
    kws = [keywords] if isinstance(keywords, str) else list(keywords)
    tag = "_".join(kws)
    fp = os.path.join(ROUTE_DIR, "flyai_%.5f_%.5f_%s.json" % (lat, lng, tag))
    try:
        if os.path.exists(fp) and time.time() - os.path.getmtime(fp) < CACHE_TTL:
            return json.load(open(fp, encoding="utf-8"))[:count]
    except Exception:
        pass
    out: list[dict[str, Any]] = []
    for kw in kws:
        d = run_flyai(["search-poi", "--city-name", city, "--keyword", kw])
        for it in ((d or {}).get("data") or {}).get("itemList") or []:
            la, ln = _f(it.get("latitude")), _f(it.get("longitude"))
            nm = str(it.get("name") or "")
            if not (la and ln and nm):
                continue
            dist = haversine((lat, lng), (la, ln))
            if dist > radius:
                continue
            out.append({"name": nm, "type": str(it.get("category") or "").split(">")[-1] or None,
                        "dist": int(dist), "rating": it.get("score") or None,
                        "cost": it.get("price") or None, "open_time": it.get("openTime") or "",
                        "lng": ln, "lat": la})
    out.sort(key=lambda x: x["dist"])
    dedup, seen = [], set()
    for o in out:
        if o["name"] in seen:
            continue
        seen.add(o["name"])
        dedup.append(o)
    if dedup:
        try:
            os.makedirs(ROUTE_DIR, exist_ok=True)
            json.dump(dedup, open(fp, "w", encoding="utf-8"), ensure_ascii=False)
        except Exception:
            pass
    return dedup[:count]


def enrich_stops(stops: list[dict[str, Any]], key: str, city: str = "") -> None:
    """给每一站补「附近吃什么」「附近看什么文化」。拿不到就留空，绝不编。

    两条腿走路：高德周边搜索（准、带评分营业时间）+ 飞猪 search-poi（不吃高德配额）。
    高德因当日配额被拒（infocode 10044）时自动整轮切到飞猪，这一站也不会空着。
    """
    if not key and not city:
        return
    _ecache = os.path.join(CACHE_DIR, "enrich")
    os.makedirs(_ecache, exist_ok=True)
    _today = time.strftime("%Y%m%d")

    def _ekey(city: str, nm: str) -> str:
        # 固定 key（不带日期）：同一个「城市 + 站点」在所有日子里共用一份缓存，
        # 由下面的 TTL 管过期。以前文件名带 _today，等于只能当天命中，白查一遍。
        safe = "".join(ch if ch.isalnum() else "_" for ch in nm)[:40]
        return os.path.join(_ecache, "%s_%s.json" % (city or "x", safe))

    def _one(sp: dict[str, Any]) -> None:
        lat, lng = sp.get("lat"), sp.get("lng")
        if lat is None or lng is None:
            return
        use_amap = bool(key) and not amap_quota_dead()

        # 同一站在同一天只查一次：一次 --brief 会给三条方案各算一遍 enrich，
        # 不缓存的话高德「周边搜索」月配额 5000 撑不住。
        _hit_mcp = _mcp_near(str(sp.get("name") or ""))
        if _hit_mcp and (_hit_mcp.get("food") or _hit_mcp.get("culture")):
            if _hit_mcp.get("food"):
                sp["food"] = _hit_mcp["food"][:3]
                sp["food_src"] = "mcp"
            if _hit_mcp.get("culture"):
                sp["culture"] = _hit_mcp["culture"][:3]
                sp["culture_src"] = "mcp"
            sp["food_src"] = sp.get("food_src") or "none"
            sp["culture_src"] = sp.get("culture_src") or "none"
            NEARBY_SEEN.append(sp)
            return

        _fp = _ekey(city, str(sp.get("name") or ""))
        try:
            _ttl_days = float(os.environ.get("DETOUR_ENRICH_TTL_DAYS") or 30)
            if os.path.exists(_fp) and time.time() - os.path.getmtime(_fp) < _ttl_days * 86400:
                _hit = json.load(open(_fp, encoding="utf-8"))
                # 以前会把「空结果」也缓存 3 天：配额用尽那几天跑出来的空行，
                # 之后就算额度恢复也一直被当成「这一带没有」。空的不许走缓存。
                if _hit.get("food") or _hit.get("culture"):
                    sp["food"] = _hit.get("food") or []
                    sp["culture"] = _hit.get("culture") or []
                    sp["food_src"] = _hit.get("food_src") or "enrich-cache"
                    sp["culture_src"] = _hit.get("culture_src") or "enrich-cache"
                    NEARBY_SEEN.append(sp)   # 命中缓存也要计数，否则来源行会误报「没有任何数据源」
                    return
        except Exception:
            pass

        food: list[dict[str, Any]] = []
        food_src = "none"
        # 小城/古镇：池子里没有这座城时，350 m 太紧（古镇餐饮本来就散），放宽到 600 m
        _has_pool = bool(city) and os.path.exists(_pool_fp(city, "food"))
        _food_r = 350 if _has_pool else 600
        _cult_r = 800 if _has_pool else 1200
        # 先查城市池（随包预建，本地即取）：命中就不必再打高德，省配额也省 0.35 s/站
        if city:
            food = pool_near(city, "food", lat, lng, radius=1200, count=3)
            if not food:   # 池里有这座城的数据，只是这一站偏了一点：退而求「最近 3 个」
                food = pool_near(city, "food", lat, lng, radius=3000, count=3)
            if food:
                food_src = "cache"
        if not food and use_amap:
            _amap_pace()
            food = [f for f in amap_around(lat, lng, "美食", key, radius=_food_r, count=4)
                    if f.get("name")][:3]
            if food:
                food_src = "amap"
        if not food and city:
            food = [f for f in flyai_around(city, lat, lng,
                                            ["餐厅", "小吃", "老字号"],
                                            radius=1200, count=3)
                    if f.get("name")][:3]
            if food:
                food_src = "flyai"

        # 先用「城市文化清单」（一次建库、30 天复用、颗粒度更好），不够再用周边搜索兜底
        cult: list[dict[str, Any]] = []
        cult_src = "none"
        if city:
            cult = pool_near(city, "culture", lat, lng, radius=1500, count=3)
            if not cult:
                cult = pool_near(city, "culture", lat, lng, radius=3000, count=3)
            if cult:
                cult_src = "cache"
        if len(cult) < 2 and city and use_amap:
            _amap_pace()
            cult = culture_near(city, lat, lng, key, radius=_cult_r, count=3)
            if cult:
                cult_src = "amap"
        if len(cult) < 2 and use_amap:
            for kw in ("非遗", "故居", "纪念馆", "古井", "书院"):
                got = [c for c in amap_around(lat, lng, kw, key, radius=_cult_r, count=3)
                       if c.get("name") and (c.get("dist") is None or c["dist"] <= _cult_r)]
                if got:
                    cult += got
                    cult_src = "amap"
                if len({c["name"] for c in cult}) >= 3:
                    break
                _amap_pace()
        if len(cult) < 2 and city:
            for c in pool_near(city, "culture", lat, lng, radius=900, count=3):
                if c.get("name"):
                    cult.append(c)
        if len(cult) < 2 and city:
            for c in flyai_around(city, lat, lng,
                                  ["博物馆", "非遗", "故居", "纪念馆"],
                                  radius=1200, count=3):
                if c.get("name"):
                    cult.append(c)
        cat = sp.get("category") or ""
        if cat in ("博物馆", "人文古迹", "历史古迹", "纪念馆", "地标建筑", "宗教场所", "园林花园", "展览馆"):
            cult.insert(0, {"name": sp.get("name"), "type": cat, "dist": 0,
                            "lat": lat, "lng": lng})
        # 文化点也沉淀进城市池：高德配额再次告急时，这一行不至于空着
        pool_add(city, "culture", cult)
        seen, uniq = set(), []
        for c in cult:
            nm = c.get("name") or ""
            if nm and nm not in seen:
                seen.add(nm)
                uniq.append(c)
        sp["food_src"] = food_src if food else "none"
        NEARBY_SEEN.append(sp)
        sp["culture_src"] = cult_src if uniq else "none"
        sp["food"] = [{"name": f["name"], "type": f.get("type"), "dist": f.get("dist"),
                       "rating": f.get("rating"), "cost": f.get("cost"),
                       "open_time": f.get("open_time")} for f in food]
        sp["culture"] = [{"name": c["name"], "type": c.get("type"), "dist": c.get("dist"),
                          "open_time": c.get("open_time")}
                         for c in uniq[:3]]
        try:
            if sp["food"] or sp["culture"]:
                json.dump({"food": sp["food"], "culture": sp["culture"],
                           "food_src": sp["food_src"], "culture_src": sp["culture_src"]},
                          open(_fp, "w", encoding="utf-8"), ensure_ascii=False)
        except Exception:
            pass

    # 站点之间互不依赖，逐站串行会让总时长被网络往返放大（实测 44–70 s）。
    # 默认 4 路并发；高德那侧由 _amap_pace() 统一限速，不会被并发打爆。
    try:
        _workers = int(os.environ.get("DETOUR_ENRICH_WORKERS") or 4)
    except ValueError:
        _workers = 4
    _todo = [sp for sp in stops if sp.get("lat") is not None and sp.get("lng") is not None]
    if _workers <= 1 or len(_todo) <= 1:
        for sp in _todo:
            _one(sp)
    else:
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=min(_workers, len(_todo))) as _ex:
            list(_ex.map(_one, _todo))


def lookup_stop(name: str, pois_by_name: dict[str, dict[str, Any]]) -> dict[str, Any] | None:
    """也支持 `名称@纬度,经度` 直接给坐标（高德查到的点可能不在飞猪库里）。"""
    if "@" in name:
        nm, _, coord = name.partition("@")
        nm = nm.strip()
        lat = lng = None
        try:
            lat_s, lng_s = coord.split(",")[:2]
            lat, lng = float(lat_s), float(lng_s)
        except (ValueError, IndexError):
            pass
        # ★ 带坐标的名字也要回查原始 POI：否则 ticketInfo / category / hook 全丢，
        #   简报和地图上就只剩一个光秃秃的名字（--auto-order 走的正是这条分支）。
        base = pois_by_name.get(nm)
        if base is None:
            for k, v in pois_by_name.items():
                if nm and (nm in k or k in nm):
                    base = v
                    break
        if base is not None:
            rec = dict(base)
            if lat is not None:
                rec["lat"], rec["lng"] = lat, lng
            return rec
        if lat is not None:
            return {"name": nm or coord, "lat": lat, "lng": lng}
    if name in pois_by_name:
        return pois_by_name[name]
    for k, v in pois_by_name.items():
        if name in k or k in name:
            return v
    return None



def _leg_detail(mode: str, dist_m: float, minutes: float,
                leg: dict[str, Any], straight_m: float = 0.0,
                mark_detour: bool = False) -> str:
    """给一段路写一句话：步行沿哪些街道 / 地铁几号线几站 / 打车多少钱。"""
    km = dist_m / 1000.0
    if mode == "transit":
        lines = leg.get("lines") or []
        bits = []
        for ln in lines:
            nm = ln.get("line") or ""
            fr, to = ln.get("from") or "", ln.get("to") or ""
            st = ln.get("stops") or 0
            if nm:
                bits.append(f"{nm} {fr}→{to}" + (f" · {st} 站" if st else ""))
        head = " → ".join(bits) if bits else "公交/地铁"
        tail = []
        if leg.get("access_m"):
            tail.append(f"进出站步行 {int(leg['access_m'])} m")
        if leg.get("cost"):
            tail.append(f"票价 ¥{leg['cost']:g}")
        tail.append(f"全程 {minutes:.0f} 分钟")
        return head + "（" + " · ".join(tail) + "）"
    if mode == "car":
        est = leg.get("taxi_est")
        return (f"打车 {km:.1f} km · {minutes:.0f} 分钟" +
                (f" · 约 ¥{est}" if est else ""))
    streets = leg.get("streets") or []
    txt = f"步行 {int(dist_m)} m · {minutes:.0f} 分钟"
    if mark_detour:
        txt = "绕行一个街区 · " + txt
    if streets:
        txt += " · 沿 " + "、".join(streets[:3])
    return txt


def path_through(stops: list[dict[str, Any]], mode: str = "walk",
                 hot: list[list[float]] | None = None, avoid: bool = True,
                 city: str = "杭州", amap_key: str = "") -> dict[str, Any]:
    """给一串按顺序的点，逐段查真实路径（可选：绕开榜单点）。"""
    hot = hot or []
    legs, total_m, total_s = [], 0.0, 0.0
    avoided = 0
    for i in range(len(stops) - 1):
        a, b = stops[i], stops[i + 1]
        pa, pb = (a["lat"], a["lng"]), (b["lat"], b["lng"])
        if mode == "transit" and amap_key:
            tr = amap_transit(pa, pb, city, amap_key)
            leg = ({"distance": tr["distance"], "duration": tr["duration"],
                    "geometry": tr["path"], "avoided": False, "via": None,
                    "hot_min_m": int(_min_dist_to_hot(tr["path"], hot)),
                    "lines": tr["lines"], "access_m": tr["access_m"],
                    "cost": tr["cost"], "taxi_cost": tr["taxi_cost"],
                    "taxi_est": tr.get("taxi_est"), "taxi_note": tr.get("taxi_note")} if tr else None)
        elif mode == "car" and amap_key:
            dr = amap_driving(pa, pb, amap_key)
            leg = ({"distance": dr["distance"], "duration": dr["duration"],
                    "geometry": dr["path"], "avoided": False, "via": None,
                    "hot_min_m": int(_min_dist_to_hot(dr["path"], hot)),
                    "taxi_cost": dr.get("taxi_cost"), "taxi_est": dr.get("taxi_est"),
                    "taxi_note": dr.get("taxi_note"), "lines": []} if dr else None)
        else:
            leg = route_leg(pa, pb, mode, hot, avoid)
        straight = haversine(pa, pb)
        if leg:
            geom = leg["geometry"]
            dist, dur = leg["distance"], leg["duration"]
            avoided += 1 if leg.get("avoided") else 0
        else:
            geom, dist = [pa, pb], straight
            dur = straight / (75.0 if mode == "walk" else 300.0) * 60
            leg = {"hot_min_m": None, "via": None, "avoided": False}
        legs.append({"lines": (leg.get("lines") if leg else []),
                     "cost": (leg.get("cost") if leg else None),
                     "taxi_cost": (leg.get("taxi_cost") if leg else None),
                     "taxi_est": (leg.get("taxi_est") if leg else None),
                     "taxi_note": (leg.get("taxi_note") if leg else None),
                     "access_m": (leg.get("access_m") if leg else None),
                     "mode": mode,
                     "streets": (leg.get("streets") if leg else None),
                     "from": a.get("name"), "to": b.get("name"),
                     "straight_m": int(straight), "walk_m": int(dist),
                     "walk_min": round(dur / 60), "path": geom,
                     "hot_min_m": leg.get("hot_min_m"),
                     "detail": _leg_detail(mode, int(dist), dur / 60, leg or {}, straight,
                                           (int(dist) - int(straight) >= 200
                                            and dist >= straight * 1.5)),
                     "avoided": bool(leg.get("avoided")),
                     "via": leg.get("via"),
                     "snap_a_m": leg.get("snap_a_m"),
                     "snap_b_m": leg.get("snap_b_m"),
                     "access": leg.get("access"),
                     "access_b": leg.get("access_b"),
                     "geom_ok": bool(leg and leg.get("geometry"))})
        total_m += dist
        total_s += dur
    straight_all = sum(l["straight_m"] for l in legs)
    # 真实性体检：某一段的实际步行远超直线（>6 倍且 >1.2 km），多半是隔江/隔海/隔快速路，
    # 说明这两个点根本不该串在一条步行线上。plans 阶段会据此跳过这种簇。
    bad = [l for l in legs
           if l["walk_m"] > 1200 and l["walk_m"] > l["straight_m"] * 6]
    # 步行量上限：4 小时走 7 km 是「能走完但很累」，表格里必须说清楚，
    # plans 阶段也优先挑不超标的那几条簇。
    over_walk = bool(hours and total_m > hours * 1100)
    walk_note = None
    if over_walk:
        _fit = max(1, int(total_m / 1100 / max(hours, 0.5)))
        walk_note = (f"这条线要走 {_fmt_km(total_m)}，{hours:g} 小时里偏紧；"
                     f"想轻松点就砍到 {_fit} 站，或者换条更短的片区")
    return {"legs": legs, "total_m": int(total_m), "total_min": round(total_s / 60),
            "mode": mode, "avoided_legs": avoided,
            "bad_link": len(bad),
            "bad_link_legs": ["%s→%s" % (l["from"], l["to"]) for l in bad],
            "over_walk": over_walk, "walk_note": walk_note,
            "excess": round(total_m / max(1e-6, straight_all), 2)}



# ─────────────────────────────────────────────────────────────────────
# 决策层（v3.0）：不再「逐段并列备选」，而是**按需融合成一条完整路线**
#
# 规则（写死在这里，legs[i].reason 里会写明依据）：
#   1. 同一 800 m 步行区（直线 < 800 m）              → 步行
#   2. 跨步行区但直线 < 1.2 km                        → 步行
#   3. 跨步行区 1.2–6 km：查一次 transit，
#      省 ≥ 15 分钟才坐地铁，否则步行（reason 写省了几分钟）
#   4. 跨步行区 > 6 km 或用户选「最快」               → 地铁优先，地铁不可达才打车
#   5. 打车只在：赶时间 / 带行李 / 天气差 / 末班已过 / 终点离地铁 > 1.5 km
#   6. 景区内部永远不加打车（即使选了「最快」）
#   7. 每条 leg 必带：mode / duration / cost / taxi_est / reason /
#      transit_line / transit_stops
# ─────────────────────────────────────────────────────────────────────

def _fmt_km(m: float) -> str:
    return ("%.1f km" % (m / 1000.0)) if m >= 1000 else ("%d m" % int(m))


def _walk_reason(straight: float, w_m: float, w_min: float) -> str:
    """一句话说明这一段为什么这么走（全程步行版）。"""
    detour = w_m - straight
    if straight < 800:
        return "同一片步行区，步行要 %.0f 分钟" % w_min
    if detour >= 200 and w_m >= straight * 1.5:
        return "步行 %s（直线 %s，绕行一个街区）" % (_fmt_km(w_m), _fmt_km(straight))
    return "步行 %s · %.0f 分钟" % (_fmt_km(w_m), w_min)


def plan_route(stops: list[dict[str, Any]], city: str = "杭州", key: str = "",
               pref: str = "walk", flags: dict[str, bool] | None = None,
               hot: list[list[float]] | None = None, avoid: bool = True,
               forced_mode: str | None = None, hours: float = 0.0) -> dict[str, Any]:
    """把一串点连成**一条**完整路线。

    v4.0 起：**全程步行**。产品方向是「目的地探索」——在景区 / 文旅区 / 一条街里走，
    不需要地铁和打车；跨区的点本来就不该进同一条路线。
    """
    stops[:] = _sanitize_water_stops(stops)
    hot = hot or []
    # 可达性体检：离最近的可步行道路超过 SNAP_MAX_M 的站点（水里、楼里、
    # 没有路网的小区）不应该出现在步行线上——宁可这条方案不发，也不画一条
    # 用户站在那儿根本走不了的路。
    offnet: list[str] = []
    offnet_names: list[str] = []
    moved_names: list[str] = []
    for _st in stops:
        if _is_water_name(_st.get("name")):
            continue
        _pt = (float(_st["lat"]), float(_st["lng"]))
        # 先查 1 km 网格缓存（data/snap 随包），小城首跑不必逐站等 OSRM
        _c = _snap_cached(_pt, "walk")
        if _c is not None:
            ROUTE_STATS["cache_hits"] = ROUTE_STATS.get("cache_hits", 0) + 1
            if _c <= SNAP_MAX_M:
                continue
            if _c <= SNAP_MOVE_MAX_M:
                _n2 = _osrm_nearest(_pt, "walk")
                if _n2 and _n2.get("dist") is not None:
                    _st["lat"], _st["lng"] = float(_n2["lat"]), float(_n2["lng"])
                    offnet.append("%s（点位偏 %.0f m，已挪到 %s）"
                                  % (_st.get("name"), float(_n2["dist"]), (_n2.get("name") or "最近道路")))
                    moved_names.append(str(_st.get("name")))
                    continue
            offnet_names.append(str(_st.get("name")))
            offnet.append("%s（离最近可步行道路 %.0f m，无路可达）" % (_st.get("name"), _c))
            continue
        _n = _osrm_nearest(_pt)
        if not _n or _n.get("dist") is None:
            # 查不到路网（离线/该城 OSM 无数据）：这是「不知道」，不是「走不到」，
            # 不能据此判死；交给后面的路线计算决定能不能出图。
            continue
        _d = float(_n["dist"])
        _snap_store(_pt, "walk", _d)
        if _d <= SNAP_MAX_M:
            continue
        if _n and _d <= SNAP_MOVE_MAX_M:
            # 点位在院落/景区内部、或贴着水边：把**站点本身**挪到最近的可步行
            # 道路上，地图上的点与线就都落在真实街道上（不再出现「点在水里、
            # 线横穿建筑」）。挪动会在 return 里记一笔，回答时可以说清楚。
            _st["lat"], _st["lng"] = float(_n["lat"]), float(_n["lng"])
            _st["snapped"] = int(_d)
            offnet.append("%s（点位偏 %.0f m，已挪到 %s）"
                          % (_st.get("name"), _d, _n.get("name") or "最近道路"))
            continue
        offnet_names.append(str(_st.get("name")))
        offnet.append("%s（离最近可步行道路 %.0f m，无路可达）" % (_st.get("name"), _d))
    if offnet_names:
        print("[info] 站点完全走不到，整簇跳过：" + "；".join(offnet_names[:2]), file=sys.stderr)
    legs: list[dict[str, Any]] = []
    total_min = 0.0
    total_walk_m = 0.0

    prev_end: tuple[float, float] | None = None
    for i in range(len(stops) - 1):
        a, b = stops[i], stops[i + 1]
        pa, pb = (a["lat"], a["lng"]), (b["lat"], b["lng"])
        straight = haversine(pa, pb)
        # 站点本身如果是码头/游船/水域景区，先把「可步行点」落到陆上入口；
        # 地图 marker 还是原 POI 坐标，但线不从水里起笔。
        pa_route, pb_route = _route_point(a), _route_point(b)
        # 关键：下一段从上一段**路网上的终点**起步。POI 每次独立吸附会落到
        # 不同路口，旧代码为了补断口在两点间拉一条直线，正是「横穿楼/河」的来源。
        a_route = prev_end if prev_end else pa_route
        if a_route is None or pb_route is None:
            wl = None
        else:
            wl = route_leg(a_route, pb_route, "walk", hot, avoid)
        if wl and len(wl.get("geometry") or []) >= 2:
            w_m = float(wl["distance"])
            w_min = float(wl["duration"]) / 60.0
            walk_geom = wl["geometry"]
            streets = wl.get("streets") or []
            prev_end = (walk_geom[-1][0], walk_geom[-1][1])
        else:
            # 取不到真实路网：距离只作文字估算，地图不生成（绝不画 [pa,pb] 直线）
            w_m, w_min = straight, straight / 75.0
            walk_geom, streets = [], []
            prev_end = None

        if not walk_geom:
            reason = "路网未取到，距离为直线估算；地图不画假线"
        elif straight < 30 or w_m < 30:
            reason = "两站紧挨着，抬脚就到"
            w_min = 0.5
        else:
            reason = _walk_reason(straight, w_m, w_min)
        leg = {
            "from": a.get("name"), "to": b.get("name"),
            "straight_m": int(straight),
            "mode": "w",
            "duration": round(w_min),
            "walk_m": int(w_m),
            "walk_min": round(w_min),
            "cost": 0.0,
            "taxi_est": None,
            "reason": reason,
            "path": walk_geom,
            "streets": streets,
            "streets_txt": "→".join(streets[:3]),
            "detail": ("步行 %d m · %d 分钟" % (w_m, round(w_min)) +
                       (" · 沿 " + "→".join(streets[:3]) if streets else "")),
            # geom_ok=False：没有真实路网，**不画红线**，只保留文字估算。
            # src=amap/osrm：告诉地图/界面这段几何来自哪套路网。
            "geom_ok": bool(walk_geom),
            "src": (wl or {}).get("source"),
            "snap_a_m": (wl or {}).get("snap_a_m"),
            "snap_b_m": (wl or {}).get("snap_b_m"),
            "access": (wl or {}).get("access"),
            "access_b": (wl or {}).get("access_b"),
        }
        legs.append(leg)
        total_min += w_min
        total_walk_m += w_m

    straight_all = sum(l["straight_m"] for l in legs) or 1
    # 真实性体检①：某段实际步行远超直线（>6 倍且 >1.2 km），多半隔江/隔海/隔快速路
    bad = [l for l in legs
           if l["walk_m"] > 1200 and l["walk_m"] > l["straight_m"] * 6]
    # 真实性体检②：步行量上限——4 小时走 7 km 走得完但很累，必须说清楚
    over_walk = bool(hours and total_walk_m > hours * 1100)
    walk_note = None
    if over_walk:
        _fit = max(1, int(total_walk_m / 1100 / max(hours, 0.5)))
        walk_note = (f"这条线要走 {_fmt_km(total_walk_m)}，{hours:g} 小时里偏紧；"
                     f"想轻松点就砍到 {_fit} 站，或者换条更短的片区")
    _n_ok = sum(1 for l in legs if l.get("geom_ok"))
    _reasons: list[str] = []
    if offnet_names:
        _reasons.append("有站点离道路太远（多半在水里/楼里）")
    _partial = bool(legs) and _n_ok == 0
    if bad:
        _reasons.append("有的路段要绕很远（隔水/隔快速路）")
    return {
        "legs": legs,
        "valid": (not _reasons),
        "partial": _partial,
        "invalid_reason": "；".join(_reasons) or None,
        "offnet_stops": offnet,
        "moved_stops": [x for x in offnet if "已挪到" in x],
        "offnet_names": offnet_names,
        "total_m": int(total_walk_m),
        "total_min": round(total_min),
        "total_cost": 0.0,
        "transit_stops": 0,
        "n_transit": 0, "n_car": 0,
        "mode": "walk", "pref": "walk",
        "avoided_legs": sum(1 for l in legs if l.get("avoided")),
        "bad_link": len(bad),
        "bad_link_legs": ["%s→%s" % (l["from"], l["to"]) for l in bad],
        "over_walk": over_walk, "walk_note": walk_note,
        "excess": round(sum(l["walk_m"] for l in legs) / max(1e-6, straight_all), 2),
    }


def _transit_ends(tinfo: dict[str, Any], a: tuple[float, float],
                  b: tuple[float, float]) -> tuple[list[float], list[float]]:
    """取地铁段的上车/下车坐标：优先用高德返回的站点坐标，拿不到就用两端点。"""
    board = tinfo.get("board") or None
    alight = tinfo.get("alight") or None
    if board and alight:
        return list(board), list(alight)
    return [a[0], a[1]], [b[0], b[1]]


def amap_hotels(near: tuple[float, float], radius: int = 1200,
                count: int = 6) -> list[dict[str, Any]]:
    """飞猪酒店接口不可用时的兜底：用高德「住宿服务」类目拿名字/距离/星级。

    价格和可订状态高德没有——所以价格字段必须留空，由回答如实说明「价格去飞猪查」，
    不能拿一个假价格糊弄。
    """
    if not AMAP_KEY or not near:
        return []
    fp = os.path.join(ROUTE_DIR, "hotels_%.5f_%.5f.json" % (near[0], near[1]))
    try:
        if os.path.exists(fp) and time.time() - os.path.getmtime(fp) < CACHE_TTL * 7:
            return json.load(open(fp, encoding="utf-8"))[:count]
    except Exception:
        pass
    d = _amap_get(AMAP_AROUND, {
        "location": "%.6f,%.6f" % (near[1], near[0]),
        "types": "100000", "radius": str(radius),
        "offset": "20", "page": "1", "extensions": "all",
        "sortrule": "distance",
    }, AMAP_KEY)
    out: list[dict[str, Any]] = []
    for q in ((d or {}).get("pois") or []):
        try:
            la = float(q["location"].split(",")[1])
            ln = float(q["location"].split(",")[0])
        except Exception:
            continue
        biz = q.get("biz_ext") or {}
        out.append({
            "name": q.get("name"),
            "price": None,                    # 高德没有价格，如实留空
            "rate": biz.get("rating") or None,
            "star": None,
            "address": q.get("address") if isinstance(q.get("address"), str) else None,
            "brand": None,
            "lat": la, "lng": ln,
            "dist_m": int(haversine(near, (la, ln))),
            "bookUrl": None,
            "src": "amap",
        })
    out.sort(key=lambda h: h.get("dist_m", 10 ** 9))
    try:
        os.makedirs(ROUTE_DIR, exist_ok=True)
        json.dump(out, open(fp, "w", encoding="utf-8"), ensure_ascii=False)
    except Exception:
        pass
    return out[:count]


def fetch_hotels(city: str, poi_name: str, date: str, top: int = 3,
                 near: tuple[float, float] | None = None) -> list[dict[str, Any]]:
    """按「终点附近」查飞猪酒店：给价格 + 预订页链接。查不到就返回空列表。"""
    try:
        import datetime
        d = datetime.date.fromisoformat(date)
        out = run_flyai(["search-hotel", "--dest-name", city, "--poi-name", poi_name,
                         "--check-in-date", d.isoformat(),
                         "--check-out-date", (d + datetime.timedelta(days=1)).isoformat(),
                         "--sort", "distance_asc"], use_cache=True)
        items = ((out or {}).get("data") or {}).get("itemList") or []
        hotels = []
        for it in items:
            hotels.append({
                "name": it.get("name"),
                "price": it.get("price"),
                "rate": it.get("rate"),
                "star": it.get("star"),
                "address": it.get("address"),
                "brand": it.get("brandName"),
                "lat": float(it["latitude"]) if it.get("latitude") else None,
                "lng": float(it["longitude"]) if it.get("longitude") else None,
                "bookUrl": it.get("detailUrl"),
                "date": d.isoformat(),
            })
        if near:
            for h in hotels:
                if h["lat"] is not None:
                    h["dist_m"] = int(haversine(near, (h["lat"], h["lng"])))
            hotels.sort(key=lambda h: h.get("dist_m", 10 ** 9))
        if near and hotels:
            _near = hotels[0].get("dist_m")
            if _near is not None and _near > 800:
                print(f"[warn] 步行圈（800 m）内没有可订酒店，最近一家 {_near} m", file=sys.stderr)
        if hotels:
            for h in hotels:
                h.setdefault("src", "flyai")
            print(f"[info] 终点附近酒店 {len(hotels)} 家（{date} 入住）", file=sys.stderr)
            return hotels[:top]
        # 飞猪酒店接口被限流/风控时，退到高德拿名字+距离（无价格）
        _fb = amap_hotels(near) if near else []
        if _fb:
            print(f"[warn] 飞猪酒店接口不可用，改用高德「住宿服务」{len(_fb)} 家（无价格）",
                  file=sys.stderr)
            note_issue("hotel", FLYAI_REASON.get("text") or "飞猪酒店接口不可用",
                       "给出住处名字与距离，价格需在飞猪查看")
            return _fb[:top]
        print("[warn] 酒店查询失败：飞猪与高德都没拿到", file=sys.stderr)
        note_issue("hotel", FLYAI_REASON.get("text") or "飞猪与高德都没返回",
                   "本次没有住处推荐，只给路线")
        return []
    except Exception as e:
        print(f"[warn] 酒店查询失败：{e}", file=sys.stderr)
        return []


def fetch_hotels_by_plan(city: str, plans: list[dict[str, Any]], date: str,
                         top: int = 2, max_plans: int = 3) -> list[dict[str, Any]]:
    """每条方案各查终点附近的酒店（各 top 家）。

    之前只按第一条方案的终点查，用户还没选方案时，酒店跟另外两条线完全对不上，
    看起来像「答非所问」。现在每条线各给 top 家；端点相同的方案共用一次查询。
    一次 fetch_hotels = 1 次飞猪调用，默认最多 3 条方案（有缓存兜底）。
    """
    out: list[dict[str, Any]] = []
    seen_end: dict[str, list[dict[str, Any]]] = {}
    for pl in (plans or [])[:max_plans]:
        _ord = (pl.get("order") or "").split(";")
        _lt = [x for x in _ord if "@" in x]
        if not _lt:
            continue
        try:
            _nm, _ll = _lt[-1].split("@")[0], _lt[-1].split("@")[1].split(",")[:2]
            _lat, _lng = float(_ll[0]), float(_ll[1])
        except Exception:  # noqa: BLE001
            continue
        _key = f"{round(_lat, 4)},{round(_lng, 4)}"
        if _key in seen_end:
            items = seen_end[_key]
        else:
            items = fetch_hotels(city, _nm, date, top, (_lat, _lng))
            seen_end[_key] = items
        out.append({
            "idx": pl.get("idx"),
            "title": pl.get("title"),
            "end_name": _nm,
            "end_lat": _lat, "end_lng": _lng,
            "items": [{"name": h.get("name"), "price": h.get("price"),
                       "rate": h.get("rate"), "star": h.get("star"),
                       "dist_m": h.get("dist_m"), "src": h.get("src"),
                       "bookUrl": h.get("bookUrl")} for h in (items or [])][:top],
        })
    if out:
        _n = sum(len(x["items"]) for x in out)
        print(f"[info] 按方案查酒店：{len(out)} 条方案 / 共 {_n} 家（{date} 入住）", file=sys.stderr)
    return out


def _simplify(pts: list[tuple[float, float]], tol_m: float = 3.0) -> list[tuple[float, float]]:
    """Ramer–Douglas–Peucker 抽稀，按「米」给容差，保住街道拐点。

    早期版本用「取每 N 个点」，1.6 公里的路只剩 60 个点，段间直线最长 150 m，
    画出来就是斜穿街区的斜线——用户一眼看出「跟街道对不上」。RDP 只丢直线上的多余点。
    """
    if len(pts) <= 2:
        return list(pts)
    lats = [p[0] for p in pts]
    mean_lat = sum(lats) / len(lats)
    kx = 111320.0 * math.cos(math.radians(mean_lat))   # 每度经度的米数
    ky = 110540.0                                       # 每度纬度的米数
    xy = [(p[1] * kx, p[0] * ky) for p in pts]

    keep = [False] * len(pts)
    keep[0] = keep[-1] = True
    stack = [(0, len(pts) - 1)]
    while stack:
        i, j = stack.pop()
        if j <= i + 1:
            continue
        ax, ay = xy[i]
        bx, by = xy[j]
        dx, dy = bx - ax, by - ay
        norm = math.hypot(dx, dy)
        best, idx = -1.0, -1
        for k in range(i + 1, j):
            px, py = xy[k]
            if norm == 0:
                d = math.hypot(px - ax, py - ay)
            else:
                d = abs(dy * (px - ax) - dx * (py - ay)) / norm
            if d > best:
                best, idx = d, k
        if best > tol_m and idx > 0:
            keep[idx] = True
            stack.append((i, idx))
            stack.append((idx, j))
    return [p for p, k in zip(pts, keep) if k]


def _url_fit(pts: list[tuple[float, float]], build, limit: int = 3600):
    """从 3 m 容差开始抽稀，URL 仍太长就把容差翻倍，直到放得下。"""
    tol = 3.0
    for _ in range(6):
        thin = _simplify(pts, tol)
        url = build(thin)
        if url is not None and len(url) <= limit:
            return url
        tol *= 2
    return build(_simplify(pts, tol))


def static_map_url(stops: list[dict[str, Any]], walk: dict[str, Any], key: str,
                   size: str = "750*500", zoom: int = 14) -> str | None:
    """高德静态地图：一个可以直接点开看的图片 URL（沙箱里也能生成）。"""
    if not key or not stops:
        return None
    parts = ["https://restapi.amap.com/v3/staticmap?key=" + key,
             "&zoom=%d&size=%s&scale=2" % (zoom, size)]
    # 路径：全部段的点连起来（抽稀到约 60 个点）
    all_pts: list[tuple[float, float]] = []
    for lg in walk.get("legs") or []:
        all_pts += [(y, x) if False else (p[0], p[1]) for p in (lg.get("path") or [])]
    if len(all_pts) >= 2:
        def _mk(pts):
            line = ";".join("%.5f,%.5f" % (q[1], q[0]) for q in pts)
            return "&paths=6,0xE8553D,1,,:" + line
        tol = 3.0
        seg = None
        for _ in range(6):                      # 高德静态图 URL 上限约 3 KB
            cand = _simplify(all_pts, tol)
            seg = _mk(cand)
            if len("".join(parts)) + len(seg) < 2800:
                break
            tol *= 2
        if seg:
            parts.append(seg)
    # 站点：起点大红，其余数字点
    marks = []
    letters = "ABCDEFGHJK"
    for i, sp in enumerate(stops):
        if i == 0:
            marks.append("large,0xE8553D,起:%.5f,%.5f" % (sp["lng"], sp["lat"]))
        else:
            marks.append("large,0x2F6FED,%s:%.5f,%.5f" % (letters[(i - 1) % len(letters)], sp["lng"], sp["lat"]))
    parts.append("&markers=" + "|".join(marks))
    url = "".join(parts)
    return url if len(url) < 3800 else None


MAP_HTML_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "docs", "map.html")


def write_map_html(path: str, stops: list[dict[str, Any]], walk: dict[str, Any],
                   hot: list[dict[str, Any]], origin: dict[str, Any] | None,
                   hotels: list[dict[str, Any]] | None = None) -> None:
    """生成一张可交互地图：左栏文字（交通方式/街道/站点）+ 右栏地图（步行与地铁分色）。"""
    qs = _map_query(stops, walk, simplify=False)
    if not qs:
        return
    try:
        tpl = open(MAP_HTML_PATH, encoding="utf-8").read()
    except Exception:
        tpl = MAP_TMPL
    if "__QUERY__" in tpl:
        html = tpl.replace("__QUERY__", qs.replace('"', "%22"))
    else:
        html = tpl.replace("__DATA__", json.dumps({"q": qs}, ensure_ascii=False))
    os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
    open(path, "w", encoding="utf-8").write(html)
    print(f"[info] 地图已生成：{path}", file=sys.stderr)

def _pack_slot(stops: list[dict[str, Any]], field: str) -> str:
    """每一站必须占一个槽位：没有数据填「—」，地图页渲染成「本次没有检索到…」。"""
    slots = []
    for sp in stops:
        items = []
        for x in (sp.get(field) or [])[:2]:
            nm = str((x or {}).get("name", ""))[:24]
            if not nm:
                continue
            ot = str((x or {}).get("open_time") or "").strip()
            if ot and len(ot) <= 12:
                nm += "（%s）" % ot
            items.append(nm)
        slots.append("¦".join(items) if items else "—")
    return ";".join(slots)


def _map_query(stops: list[dict[str, Any]], walk: dict[str, Any] | None,
               simplify: bool = True, limit: int = 6000) -> str | None:
    """给地图页拼 query（p/n/k/lg/fd/cu/al/tp/m/min/wm/ts/cost/t），不带 base。

    ★ `k` 的格式是「段起,段止,mode」用 `;` 分隔（如 k=0,1,w;1,2,t;2,3,w）；
      旧链接里的 `s:e` / `s:e:w` 仍然能解析，缺 mode 时按 w 处理。
    ★ 区间下标必须基于最终写进 `p` 的那份点数组 —— 先算区间再整体抽稀会让下标错位，
      地图上就会出现「红线断开」「凭空多出一段」。
    """
    if not walk or not walk.get("legs") or not stops:
        return None
    from urllib.parse import quote
    legs = walk["legs"]
    # 只要有一段没取到真实路网，就不生成地图：宁可没有图，也不画一条假街。
    if any(not lg.get("geom_ok", True) for lg in legs):
        return None
    names = ";".join(sp.get("name", "") for sp in stops)
    details = "~".join((lg.get("streets_txt") or "") for lg in legs)
    # 理由（reason）不再写进 URL：链接会被智能体的工具输出截断（实测 >7k 就断），
    # 地图页按同一套规则用 al 里的数字重建句子，效果一样，能省 1.2k 字符。

    foods = _pack_slot(stops, "food")
    cults = _pack_slot(stops, "culture")

    def _uniq_adjacent(seq: list[list[float]]) -> list[list[float]]:
        """相邻点完全重合时只留一个：URL 里出现 p=1,2;1,2 这种重复点没有意义。"""
        out: list[list[float]] = []
        for pt in seq:
            if out and abs(out[-1][0] - pt[0]) < 1e-6 and abs(out[-1][1] - pt[1]) < 1e-6:
                continue
            out.append(pt)
        return out

    def build_with(leg_pts: list[list[tuple[float, float]]]) -> str | None:
        pts_all: list[list[float]] = []
        ranges: list[str] = []
        for pts, lg in zip(leg_pts, legs):
            code = {"walk": "w", "bike": "b", "car": "c", "transit": "t",
                    "w": "w", "b": "b", "c": "c", "t": "t"}.get(lg.get("mode"), "w")
            seg = [list(pt) for pt in (pts or [])]
            if not seg:
                continue
            if len(seg) == 1:
                # 这一段只有一个点（两站重合），补成两点，别让它退化成「无线段」
                seg = [seg[0], seg[0]]
            if pts_all:
                prev = pts_all[-1]
                # 只在两段端点几乎重合时去重；差得多就**留缺口**，绝不补一条
                # 跨楼/跨河的直线（旧代码正是把 prev 硬接到 seg[0]，地图上像横穿）。
                gap_m = haversine((prev[0], prev[1]), (seg[0][0], seg[0][1]))
                if gap_m <= 3.0:
                    if abs(prev[0] - seg[0][0]) > 1e-6 or abs(prev[1] - seg[0][1]) > 1e-6:
                        seg = [prev] + seg
                    start = len(pts_all) - 1
                    pts_all.extend(seg[1:])
                else:
                    start = len(pts_all)
                    pts_all.extend(seg)
            else:
                start = 0
                pts_all.extend(seg)
            ranges.append("%d,%d,%s" % (start, len(pts_all) - 1, code))
        pts_all = _uniq_adjacent(pts_all)
        if len(pts_all) < 2:
            return None
        coords = ";".join("%.5f,%.5f" % (pt[1], pt[0]) for pt in pts_all)
        qs = ("p=" + quote(coords, safe=";,") +
              "&n=" + quote(names, safe=";") +
              "&k=" + quote(";".join(ranges), safe=";,:") +
              "&lg=" + quote(details, safe="~→") +
              "&fd=" + quote(foods, safe=";¦") +
              "&cu=" + quote(cults, safe=";¦") +
              "&m=" + str(walk["total_m"]) + "&min=" + str(walk["total_min"]) +
              "&sn=" + quote(";".join("%.5f,%.5f" % (sp["lng"], sp["lat"]) for sp in stops),
                             safe=";,") +
              "&fb=" + "".join("1" if not lg.get("geom_ok", True) else "0" for lg in legs) +
              "&rs=" + "".join("a" if lg.get("src") == "amap" else "o" for lg in legs) +
              "&t=" + quote(stops[0]["name"] + " 出发的路线", safe=""))
        return qs

    raw = [[tuple(pt) for pt in (lg.get("path") or [])] for lg in legs]
    if not simplify:
        return build_with(raw)

    last: str | None = None
    for tol in (2.0, 3.0, 5.0, 8.0, 12.0, 18.0, 26.0, 36.0, 50.0):
        url = build_with([_simplify(pts, tol) for pts in raw])
        if not url:
            return None
        last = url
        if len(url) <= limit:
            return url
    return last


def build_map_url(base: str, stops: list[dict[str, Any]],
                  walk: dict[str, Any] | None) -> str | None:
    """拼出可缩放网页地图的地址（map.html?p=...&n=...&k=...&lg=...）。"""
    if not base:
        return None
    try:
        qs = _map_query(stops, walk)
        if not qs:
            return None
        return base + ("&" if "?" in base else "?") + qs
    except Exception:  # noqa: BLE001
        return None


def main() -> int:
    ap = argparse.ArgumentParser(description="绕路 Detour 长尾探索引擎")
    ap.add_argument("--city", required=True)
    ap.add_argument("--theme", default="自由", choices=list(THEMES))
    ap.add_argument("--hours", type=float, default=4.0)
    ap.add_argument("--anchor", default=None, help="出发点地名，如 武林广场；可为空")
    ap.add_argument("--via", default=None,
                    help="点名要去的点，逗号分隔（2–3 个），会强制进路线")
    ap.add_argument("--coords", default=None,
                    help="已知出发点经纬度，格式 经度,纬度（高德返回的顺序）；给了就跳过地名解析")
    ap.add_argument("--anchor-name", default=None, dest="anchor_name",
                    help="配合 --coords 显示的地名标签")
    ap.add_argument("--radius", type=float, default=800.0, help="聚类半径（米）")
    ap.add_argument("--near-km", type=float, default=8.0, dest="near_km",
                    help="只保留出发点该半径内的候选（km）")
    ap.add_argument("--max-clusters", type=int, default=4)
    ap.add_argument("--json-only", action="store_true")
    ap.add_argument("--brief", action="store_true",
                    help="只输出三方案简报（plans 在最前面，约 8 KB），首轮就该用这个")
    ap.add_argument("--no-plan-maps", dest="no_plan_maps", action="store_true",
                    help="不预生成 Top3 方案的地图（默认会预生成，模型可一次贴全三张）")
    ap.add_argument("--map-base", dest="map_base", default=None,
                    help="可缩放网页地图的地址（如 GitHub Pages 上的 map.html）；给了就拼出 map_url")
    ap.add_argument("--auto-order", dest="auto_order", action="store_true",
                    help="不给 --order 时，自动用最密集的那个簇按就近顺序生成路线与地图")
    ap.add_argument("--cluster-idx", dest="cluster_idx", type=int, default=0,
                    help="--auto-order 用第几个簇（0=最密集，1/2=其余簇）；配合多次调用给多个方案出图")
    ap.add_argument("--order", default=None,
                    help="按这个顺序排站；用 ; 分隔（名字里带 @纬度,经度 时必须用 ;）；配合 --map 画真实街道路径")
    ap.add_argument("--mode", default="walk", choices=["walk"],
                    help="v4.0 起只有步行：目的地探索就是在景区/文旅区里走，"
                         "跨区的点不该进同一条路线")
    ap.add_argument("--amap-key", default=None, dest="amap_key",
                    help="高德 Web 服务 Key（也可用环境变量 AMAP_KEY）；--mode transit 必需")
    ap.add_argument("--avoid-hot", dest="avoid_hot", action="store_true", default=False,
                    help="绕过榜单点所在路段（会让路线变长、可能钻小巷，默认关闭）")
    ap.add_argument("--build-themes-all", action="store_true",
                    help="把十座热门城市的主题点库（动漫/建筑/非遗）一次性建好")
    ap.add_argument("--build-themes", action="store_true",
                    help="只建这座城市的主题点库（动漫/建筑/非遗）然后退出")
    ap.add_argument("--build-culture-all", action="store_true",
                    help="把热门城市的「城市文化清单」一次性建好")
    ap.add_argument("--build-culture", action="store_true",
                    help="只建这座城市的「城市文化清单」然后退出")
    ap.add_argument("--nearby-json", dest="nearby_json", default=None,
                    help="agent 用 MCP maps_around_search 取回的周边数据 JSON（优先于池子/高德 REST）")
    ap.add_argument("--dump-stops", dest="dump_stops", action="store_true",
                    help="只输出候选方案各站的 name/lat/lng JSON，供 agent 逐站调 MCP 取周边")
    ap.add_argument("--no-enrich", dest="enrich", action="store_false", default=True,
                    help="不补周边美食/文化（默认会补，需高德 Key）")
    ap.add_argument("--hotel", action="store_true",
                    help="查终点附近的酒店（含价格与预订链接）")
    ap.add_argument("--hotel-date", default=None,
                    help="入住日期 YYYY-MM-DD，默认今天")
    ap.add_argument("--hotel-top", type=int, default=3, help="酒店返回几家，默认 3")
    ap.add_argument("--map", default=None, help="生成器：输出交互地图 html 的路径")
    ap.add_argument("--allow-hot", action="store_true", dest="allow_hot",
                    help="允许榜单点进候选池（默认只当备选，不进簇）")
    a = ap.parse_args()

    # --amap-key 之前只传给补点/地理编码，route_leg 仍读全局 AMAP_KEY；
    # 现在步行优先高德，必须把命令行 Key 同步进全局，否则会误走 OSRM。
    global AMAP_KEY
    if a.amap_key:
        AMAP_KEY = a.amap_key

    # agent 用 MCP `maps_around_search` 取回的周边（云端沙箱通常连不上高德 REST）
    if getattr(a, "nearby_json", None):
        try:
            _nj = json.load(open(a.nearby_json, encoding="utf-8"))
            _st = _nj.get("stops") if isinstance(_nj, dict) else _nj
            if isinstance(_st, list):
                MCP_NEARBY.extend([x for x in _st if isinstance(x, dict)])
            print(f"[info] MCP 周边：读入 {len(MCP_NEARBY)} 站", file=sys.stderr)
        except Exception as _e:
            print(f"[warn] --nearby-json 读不了：{_e}", file=sys.stderr)

    anchor = None
    anchor_name = None
    anchor_failed = None
    queries = 0
    if a.coords:
        # 高德等外部地理编码器给出的坐标直接拿来用：飞猪 POI 库对门牌号、
        # 园区名基本解析不出来，而 MCP 那边的地理编码是门址级的。
        try:
            lng_s, lat_s = a.coords.split(",")[:2]
            anchor = (float(lat_s), float(lng_s))
            anchor_name = a.anchor_name or a.anchor or f"{anchor[0]:.5f},{anchor[1]:.5f}"
            print(f"[info] 使用外部坐标 {anchor[1]},{anchor[0]}（{anchor_name}）", file=sys.stderr)
        except (ValueError, IndexError):
            print(f"[warn] --coords 格式不对：{a.coords}，应为 经度,纬度", file=sys.stderr)
            anchor = None
    elif a.anchor:
        queries += 1
        geo = geocode(a.anchor, a.city)
        if geo:
            anchor = (geo[0], geo[1])
            anchor_name = geo[2]
        else:
            anchor_failed = a.anchor
            print(f"[warn] 出发点「{a.anchor}」未能定位，已忽略距离约束", file=sys.stderr)

    # 出发点如果本身是码头/游船/水域景区，坐标会被放在水面上；
    # 先落到最近的陆上路口，落不了就明确拒绝，绝不从河里起笔。
    if anchor is not None and _is_water_name(anchor_name or ""):
        _orig_anchor = anchor_name or "水上出发点"
        _land, _land_name, _near = _land_entry(anchor, _orig_anchor)
        if _land:
            anchor = _land
            anchor_name = _land_name
            print(f"[info] 出发点「{_orig_anchor}」是水上项目/码头，已改到最近陆上路口"
                  f"（{(_near or {}).get('name') or '最近道路'}，"
                  f"{float((_near or {}).get('dist') or 0):.0f} m）", file=sys.stderr)
        else:
            # 保留锚点坐标只用于「就近筛选」；锚点不是路线站点，不会把线画进水里。
            print(f"[warn] 出发点「{_orig_anchor}」在水上/无法从陆路到达；"
                  f"仅用于就近筛选，路线不会从水面起笔。建议换陆上入口"
                  f"（如码头售票处/附近路口）", file=sys.stderr)

    tkey = a.amap_key or AMAP_KEY

    def _collect(theme: str) -> list[dict[str, Any]]:
        """拉某主题的全部候选：飞猪 POI + 高德主题词补点（有就补）。"""
        ps = fetch_pois(a.city, theme)
        # 主题点库不依赖高德 Key：随包清单 / 本地缓存 / 飞猪现建都能给点，
        # 只有「三样都没有」时才算没数据，见 build_theme_list()。
        if theme in THEME_AMAP_KEYWORDS:
            extra = theme_pois(a.city, theme, tkey, a.anchor_name or a.anchor)
            if extra:
                # 主题点库一旦建起来，就把飞猪那边明显跑题的类目剔掉（否则「动漫」里会混进夜市）
                drop = THEME_DROP_CATEGORIES.get(theme, set())
                if drop:
                    before = len(ps)
                    ps = [p for p in ps if (p.get("category") or "") not in drop]
                    if before != len(ps):
                        print(f"[info] 主题过滤：剔除 {before - len(ps)} 个跑题类目"
                              f"（{ '/'.join(sorted(drop)) }）", file=sys.stderr)
                ps = ps + extra
                print(f"[info] 主题补点：{theme} +{len(extra)} 个（主题点库）", file=sys.stderr)
        # 水上项目（游船/游轮/码头/轮渡）坐标在江面上，会把整条步行线拖进水里
        _n0 = len(ps)
        ps = [p for p in ps
              if not any(w in (p.get("name") or "") for w in THEME_WATER_NAME)]
        if _n0 != len(ps):
            print(f"[info] 剔除 {_n0 - len(ps)} 个水上项目点（游船/码头），步行线不经过水面",
                  file=sys.stderr)
        # 行政区过滤：兴坪、婺源这类小地名常把邻县/市区的点召回，
        # 点自带 adcode 时校验一下；没有 adcode 的来源（飞猪/随包）直接放行。
        adc = _city_adcodes(a.city)
        if adc:
            _n1 = len(ps)
            ps = [p for p in ps if _district_ok(p, adc)]
            if _n1 != len(ps):
                print(f"[info] 行政区过滤：{_n1 - len(ps)} 个点不在「{a.city}」辖区内，已剔除",
                      file=sys.stderr)
        return ps

    theme_used = a.theme
    pois = _collect(theme_used)
    queries += len(THEMES.get(a.theme, THEMES["自由"])["categories"]) + \
        len(THEMES.get(a.theme, THEMES["自由"])["keywords"])

    # 主题没有候选（飞猪被风控 + 高德也没有这类目）时，自动退到邻近主题，
    # 并把「换成了什么、为什么换」写进简报，别让模型临场瞎猜。
    theme_fallback = None
    if len(pois) < 3:
        for alt in THEME_FALLBACK.get(theme_used, []):
            if alt == theme_used:
                continue
            cand = _collect(alt)
            if len(cand) >= 3:
                theme_fallback = {
                    "from": theme_used, "to": alt,
                    "from_points": len(pois), "to_points": len(cand),
                    "msg": (f"「{theme_used}」这一主题在本城只拿到 {len(pois)} 个点，"
                            f"已自动改用「{alt}」（{len(cand)} 个点）。"
                            f"回答时先说明这一句，再按「{alt}」给方案，不要假装是「{theme_used}」。"),
                }
                print(f"[info] 主题「{theme_used}」只有 {len(pois)} 个点 → 自动改用「{alt}」"
                      f"（{len(cand)} 个点）", file=sys.stderr)
                theme_used, pois = alt, cand
                break
        else:
            print(f"[warn] 主题「{theme_used}」候选只有 {len(pois)} 个点，没有可替换的邻近主题",
                  file=sys.stderr)

    raw_total = len(pois)
    pois = dedupe(pois)
    deduped = raw_total - len(pois)
    if deduped:
        print(f"[info] {deduped} 条同址重复记录已合并（{DEDUPE_M:g} 米内视为同一地点）",
              file=sys.stderr)

    # --via：用户点名要去的点（2–3 个），强制进候选并排在簇的前面
    via_stops = []
    for nm in [x.strip() for x in (getattr(a, "via", "") or "").split(",") if x.strip()]:
        g = geocode(nm, a.city)
        if not g:
            print(f"[warn] --via「{nm}」没解析出坐标，跳过", file=sys.stderr)
            continue
        via_stops.append({"id": "via:" + nm, "name": nm, "category": "点名要去",
                          "lat": g[0], "lng": g[1], "address": g[2] or a.city,
                          "source": "via"})
    if via_stops:
        pois = via_stops + [p for p in pois if p.get("name") not in {v["name"] for v in via_stops}]
        print(f"[info] --via 点名 {len(via_stops)} 个点，已强制放进候选", file=sys.stderr)

    if anchor:
        # 出发点 near_km 外的点不进候选：一条 4 小时的步行路线不该横跨整座城。
        # 但海滨/山地城市（三亚、桂林）长尾点天然散，8km 常常只剩个位数；
        # 这时按 1.5 倍逐级放大搜索半径，而不是直接掉到「邻近主题」兜底。
        pre = list(pois)
        km = a.near_km
        while True:
            pois = [p for p in pre if haversine(anchor, (p["lat"], p["lng"])) <= km * 1000]
            dropped = len(pre) - len(pois)
            if dropped:
                print(f"[info] {dropped} 个点距出发点超过 {km:g}km，已剔除", file=sys.stderr)
            if len(pois) >= 14 or km >= 30:
                break
            wider = min(30.0, round(km * 1.5, 1))
            if wider <= km:
                break
            print(f"[info] 附近只剩 {len(pois)} 个点，搜索半径从 {km:g}km 放大到 {wider:g}km",
                  file=sys.stderr)
            km = wider
        a.near_km = km

    # 坐标只有两位小数的点：城市级占位，不能当站点（否则地图上凭空多一个点）
    _coarse = [p for p in pois if _coarse_coord(p.get("lat"), p.get("lng"))]
    if _coarse:
        _names = "、".join(str(p.get("name")) for p in _coarse[:3])
        print(f"[warn] {len(_coarse)} 个点坐标只有两位小数（{_names}…），"
              f"多半是城市级占位，已剔除出候选池", file=sys.stderr)
        pois = [p for p in pois if not _coarse_coord(p.get("lat"), p.get("lng"))]

    for p in pois:
        p["score"], p["why"] = tail_score(p)

    # 榜单点（listRank 非空）默认不进路线：单独拿出来，供「我排除了什么」一栏使用
    hot = [p for p in pois if p.get("listRank")]
    tail = [p for p in pois if not p.get("listRank")]
    if a.allow_hot:
        # 用户明确要热门点时，榜单点也进簇，但在简报里仍标着 rank
        tail = tail + hot
        print(f"[info] --allow-hot：{len(hot)} 个榜单点已放进候选池（排名仍会标出）",
              file=sys.stderr)
    hot_ctx = [slim(h, anchor) for h in sorted(hot, key=lambda p: -p["score"])]

    clusters = build_clusters(tail, a.radius)
    # 主题点库里的点（谷店/教堂）天然比景点稀疏：800 m 内常常只有 1 个，
    # 这时把半径放大再聚一次，否则出不了「一条街」。
    _maxc = max((len(c["members"]) for c in clusters), default=0)
    # 古镇/小城尺度只有几百米：先用更小半径试一次，别一上来就放大到 1 km 以上
    if _maxc < 3 and len(tail) >= 6:
        for r in (400.0, 600.0):
            tighter = build_clusters(tail, r)
            m0 = max((len(c["members"]) for c in tighter), default=0)
            if m0 > _maxc:
                print(f"[info] 点很密但聚不出簇，先按 {r:g} m 小半径重聚", file=sys.stderr)
                a.radius, clusters, _maxc = r, tighter, m0
            if _maxc >= 3:
                break
    if _maxc < 3:
        for r in (1200.0, 1600.0, 2000.0, 2500.0, 3200.0):
            bigger = build_clusters(tail, r)
            m2 = max((len(c["members"]) for c in bigger), default=0)
            if m2 > _maxc:
                print(f"[info] 簇太散，聚类半径临时放大到 {r:g} m", file=sys.stderr)
                a.radius, clusters, _maxc = r, bigger, m2
            if _maxc >= 3:
                break
    for c in clusters:
        c["title"] = cluster_title(c["members"])
        c["members"] = [slim(m, anchor) for m in c["members"]]
        cid = tuple(c["centroid"])
        near = [h for h in hot if haversine(cid, (h["lat"], h["lng"])) <= 300]
        c["nearby_hot"] = [slim(h, anchor) for h in sorted(near, key=lambda p: -p["score"])][:5]
        if anchor:
            c["anchor_m"] = int(haversine(anchor, tuple(c["centroid"])))
    if anchor:
        # 出发点近的簇优先（3km 内），其余按长尾质量
        clusters.sort(key=lambda c: (0 if c["anchor_m"] <= 3000 else 1, -len(c["members"]), c["anchor_m"]))
    # --cluster-idx 要在「截断之前」的全量簇列表上取，否则 idx 1/2 会被 max_clusters 裁掉
    all_clusters = list(clusters)
    # 现成方案 Top3：一次调用就把三个方案摆出来，别让模型为拿三个方案连跑四次引擎
    if anchor:
        # 排序要把「离出发点远近」算进去，否则 7 km 外的簇会被当成 A 案推给用户
        _ranked_all = sorted(all_clusters, key=lambda c: (0 if c.get("anchor_m", 99999) <= 3000 else 1,
                                                          -len(c["members"]), -c["score"]))
    else:
        _ranked_all = sorted(all_clusters, key=lambda c: (-len(c["members"]), -c["score"]))
    plans: list[dict[str, Any]] = []

    def _order_mem(mem: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """从出发点最近的那个起，之后每次挑离上一个最近的。"""
        mem = [m for m in mem if m.get("lat") is not None]
        mem.sort(key=lambda m: -m.get("score", 0))
        mem = mem[:4]
        if anchor and mem:
            cur, ordered, pool = anchor, [], mem[:]
            while pool:
                nxt = min(pool, key=lambda m: haversine(cur, (m["lat"], m["lng"])))
                ordered.append(nxt)
                pool.remove(nxt)
                cur = (nxt["lat"], nxt["lng"])
            mem = ordered
        return mem

    _byname_all = {p["name"]: p for p in pois}
    _plan_base = (a.map_base or os.environ.get("MAP_BASE") or DEFAULT_MAP_BASE)
    _hot_ll_all = [[h["lat"], h["lng"]] for h in hot]

    def _plan_try(c: dict[str, Any]) -> tuple[list[dict], dict | None]:
        """给簇排好序并算一次真实路线；跨江/跨海的簇返回 None。"""
        # 预算超了就别再算新簇了：云端路网往返慢的时候，
        # 一条簇可能要算 1–2 分钟，宁可少一条也不能让用户干等。
        if _budget > 0:
            try:
                if time.time() - _t_start > _budget * 1.3:
                    return [], None
            except Exception:  # noqa: BLE001
                pass
        mem = _order_mem([dict(m) for m in c["members"]])
        if a.no_plan_maps or len(mem) < 2:
            return mem, None
        try:
            _sj = []
            for m in mem:
                hit = lookup_stop("%s@%.5f,%.5f" % (m["name"], m["lat"], m["lng"]),
                                  _byname_all)
                if hit:
                    _sj.append(hit)
            if len(_sj) < 2:
                return mem, None
            if a.enrich:
                CITY_HINT[:] = [a.city]
                enrich_stops(_sj, tkey, a.city)
            _w = plan_route(_sj, a.city, tkey, "walk", {}, _hot_ll_all, a.avoid_hot, None, a.hours)
            if _w.get("offnet_names"):
                # 有站点根本走不到（水里/楼群里）：把这几站摘掉，用剩下的点重排一次。
                # 宁可少一站，也不要出现「用户站在那儿没法走」的路线。
                _drop = set(_w["offnet_names"])
                _sj2 = [x for x in _sj if str(x.get("name")) not in _drop]
                _mem2 = [m for m in mem if str(m.get("name")) not in _drop]
                if len(_sj2) >= 2:
                    _w2 = plan_route(_sj2, a.city, tkey, "walk", {}, _hot_ll_all,
                                     a.avoid_hot, None, a.hours)
                    if not _w2.get("invalid_reason"):
                        print(f"[info] 「{c['title']}」摘掉 {len(_sj) - len(_sj2)} 个走不到的站点后重排",
                              file=sys.stderr)
                        return _mem2, (_sj2, _w2)
            # 有路段取不到真实路网 → 把那段的下游站点摘掉再排，直到每段都有真实路径。
            # 这样既有完整可画的线，也不会拿直线凑数。
            _guard = 0
            while (len(_sj) > 2 and _guard < 3
                   and any(not lg.get("geom_ok") for lg in _w.get("legs", []))):
                _bad = next(lg for lg in _w["legs"] if not lg.get("geom_ok"))
                _drop2 = str(_bad.get("to"))
                _sj = [x for x in _sj if str(x.get("name")) != _drop2]
                _mem = [m for m in _mem if str(m.get("name")) != _drop2] if False else _mem
                _w = plan_route(_sj, a.city, tkey, "walk", {}, _hot_ll_all,
                                a.avoid_hot, None, a.hours)
                _guard += 1
                print(f"[info] 「{c['title']}」摘掉走不通的「{_drop2}」后重排", file=sys.stderr)
            if _w.get("invalid_reason"):
                print(f"[info] 跳过「{c['title']}」：{_w['invalid_reason']}", file=sys.stderr)
                return mem, None
            if _w.get("bad_link"):
                print(f"[info] 跳过「{c['title']}」：{_w['bad_link_legs'][0]} 要走 "
                      f"{_w['legs'][0]['walk_m']} m（直线 {_w['legs'][0]['straight_m']} m），"
                      f"隔着水/快速路，串不成一条步行线", file=sys.stderr)
                return mem, None
            if anchor and _sj:
                try:
                    _d0 = haversine(anchor, (_sj[0]["lat"], _sj[0]["lng"]))
                    if _d0 > 800:
                        _w["access_note"] = (
                            "这段步行线从「%s」开始；它离 %s 约 %.1f km，"
                            "建议打车或公交过去（这一段不算进步行线）"
                            % (_sj[0]["name"], a.anchor_name or "出发点", _d0 / 1000.0))
                except Exception:
                    pass
            if len(_sj) == 2:
                _w["two_stop"] = True
                _w["two_stop_note"] = "这一片只够连成两个点（一条街走完），别硬凑第三站"
                print(f"[info] 「{c['title']}」只够两站，按「两点一线」出方案", file=sys.stderr)
            return mem, (_sj, _w)
        except Exception as _e:  # noqa: BLE001
            print(f"[warn] 簇「{c['title']}」路线没算出来：{_e}", file=sys.stderr)
            return mem, None

    _used = 0
    _tried = 0
    _with_geom = 0
    _good: list[tuple[dict, list[dict], tuple | None]] = []
    _over: list[tuple[dict, list[dict], tuple | None]] = []
    # 并行算 Top 簇：每个簇 = 一次真实路径 + enrich（都是网络等待），
    # 串行要 30 s×N，4 线程并行基本压到 1 个簇的时间。
    from concurrent.futures import ThreadPoolExecutor

    def _batch(cands: list[dict[str, Any]]) -> list[tuple[list[dict], Any]]:
        try:
            with ThreadPoolExecutor(max_workers=4) as _ex:
                return list(_ex.map(_plan_try, cands))
        except Exception:  # noqa: BLE001
            return [_plan_try(c) for c in cands]

    # 时间预算：云端到路网的往返比本地慢一个数量级，与其让用户等 4 分钟，
    # 不如在预算内先出「够用的三条」。本地 20 秒跑完的用例完全不受影响。
    _budget = float(os.environ.get("DETOUR_PLAN_BUDGET") or 75)
    _t_start = time.time()

    def _over_budget(need: int) -> bool:
        if _budget <= 0:
            return False
        used = time.time() - _t_start
        if used > _budget * 2.5:      # 硬闸：再算也不会更好了，直接收
            return True
        return used > _budget and (len(_good) + len(_over)) >= need

    _cand = _ranked_all[:6]
    _results = _batch(_cand)
    for c, (mem, _res) in zip(_cand, _results):
        _tried += 1
        if _res and any(l.get("geom_ok") for l in _res[1].get("legs", [])):
            _with_geom += 1
        if _res is None and not a.no_plan_maps:
            continue
        if _res and _res[1].get("over_walk"):
            _over.append((c, mem, _res))
        else:
            _good.append((c, mem, _res))
        if len(_good) >= 3:
            break
        if len(_good) + len(_over) >= 6:
            break
        if _over_budget(1):
            print("[info] 时间预算用完，先用已算好的方案", file=sys.stderr)
            break

    # 凑不满 3 条时，把 6..14 名的簇也试一遍（小片区的点也值得给一条线）
    if (len(_good) + len(_over) < 3 and len(_ranked_all) > 6
            and not _over_budget(1)):
        _more = _ranked_all[6:14]
        _r2 = _batch(_more)
        for c, (mem, _res) in zip(_more, _r2):
            _tried += 1
            if _res and any(l.get("geom_ok") for l in _res[1].get("legs", [])):
                _with_geom += 1
            if _res is None and not a.no_plan_maps:
                continue
            if _res and _res[1].get("over_walk"):
                _over.append((c, mem, _res))
            else:
                _good.append((c, mem, _res))
            if len(_good) >= 3 or len(_good) + len(_over) >= 6:
                break

    # 优先「走得完」的簇；不够 3 条再拿超标的补，并在方案里标 over_walk
    _ordered = _good + _over
    for c, mem, _res in _ordered:
        if _used >= 3:
            break
        if _res is None and not a.no_plan_maps:
            continue                      # 跨江/跨海或算不出来：换下一个簇
        _stops_j, _wj = (_res if _res else ([], None))
        if _wj:
            _wj.setdefault("two_stop", len(_stops_j or []) == 2)
        walk_m = 0
        for i in range(len(mem) - 1):
            walk_m += haversine((mem[i]["lat"], mem[i]["lng"]),
                                (mem[i + 1]["lat"], mem[i + 1]["lng"]))
        walk_m = int(walk_m * 1.35)  # 直线 × 1.35 ≈ 实际步行
        pl: dict[str, Any] = {
            "idx": _used,
            "title": c["title"],
            "stops": [m["name"] for m in mem],
            "stops_n": len(mem),
            "span_m": c.get("span_m") or 0,
            "est_walk_m": walk_m,
            "est_min": int(round(walk_m / 75)) if walk_m else 0,
            "score": round(float(c.get("score") or 0), 1),
        }
        # 兜底：不管 _wj 怎么说，只要最终展示出来就是两站，就标出来
        if len(pl["stops"]) == 2 and not pl.get("two_stop"):
            pl["two_stop"] = True
            pl["two_stop_note"] = (_wj or {}).get("two_stop_note") or "这一片只够连成两个点（一条街走完），别硬凑第三站"
        if _wj:
            if _wj.get("two_stop"):
                pl["two_stop"] = True
                pl["two_stop_note"] = _wj.get("two_stop_note") or "这一片只够连成两个点"
            if _wj.get("access_note"):
                pl["access_note"] = _wj["access_note"]
        # 每条方案的真实路径 + 地图 URL 在 _plan_try 里已经算过一次，这里直接复用
        if _wj and _stops_j:
            _mu_j = build_map_url(_plan_base, _stops_j, _wj)
            pl["walk_m"] = _wj["total_m"]
            pl["walk_min"] = _wj["total_min"]
            pl["order"] = ";".join("%s@%.5f,%.5f" % (x["name"], x["lat"], x["lng"])
                                   for x in _stops_j)
            if _mu_j:
                pl["map_url"] = _mu_j
                pl["map_line"] = "🗺 路线图：" + _mu_j
            if _wj.get("over_walk"):
                pl["over_walk"] = True
                pl["walk_note"] = _wj.get("walk_note")
        plans.append(pl)
        _used += 1

    # 兜底：这一片实在只有一两个小簇时，从剩余长尾点里再拼 1–2 条「三站一线」。
    # 长尾点也不够时，退一步允许掺 1–2 个上过榜的点，但在方案里明确标出来
    # （宁可给出「有一条街上有个热门点」的可用路线，也别只给一条就走人）。
    if _used < 3 and not a.no_plan_maps:

        def _fill_from(_pool_src: list[dict[str, Any]], allow_hot_fill: bool) -> None:
            nonlocal _used
            _used_names = {n for pl in plans for n in pl["stops"]}
            _pool = [m for m in _pool_src if m["name"] not in _used_names]
            _tries = 0
            while _used < 3 and len(_pool) >= 3 and _tries < 4:
                _tries += 1
                if anchor:
                    _seed = min(_pool, key=lambda m: haversine(anchor, (m["lat"], m["lng"])))
                else:
                    _seed = _pool[0]
                _sl = (_seed["lat"], _seed["lng"])
                _trio = sorted(_pool, key=lambda m: haversine(_sl, (m["lat"], m["lng"])))[:4]
                _trio = [t for t in _trio if haversine(_sl, (t["lat"], t["lng"])) <= 1500]
                if len(_trio) < 3:
                    _pool = [m for m in _pool if m is not _seed]
                    continue
                if not allow_hot_fill and sum(1 for t in _trio if t.get("listRank")) > 1:
                    _pool = [m for m in _pool if m is not _seed]
                    continue
                _lats = [t["lat"] for t in _trio]
                _lngs = [t["lng"] for t in _trio]
                _pseudo = {
                    "title": cluster_title(_trio),
                    "members": _trio,
                    "centroid": (sum(_lats) / len(_lats), sum(_lngs) / len(_lngs)),
                    "span_m": int(max(haversine((a["lat"], a["lng"]), (b["lat"], b["lng"]))
                                      for a in _trio for b in _trio)),
                    "score": float(sum(t.get("score") or 0 for t in _trio)) / len(_trio),
                }
                _mem2, _res2 = _plan_try(_pseudo)
                _drop = _mem2[0]["name"] if _mem2 else _seed["name"]
                _pool = [m for m in _pool if m["name"] != _drop]
                if not _res2:
                    continue
                _sj2, _w2 = _res2
                _mu2 = build_map_url(_plan_base, _sj2, _w2)
                if not _mu2:
                    continue
                _ranked_in = [x["name"] for x in _sj2 if x.get("rank")]
                plans.append({
                    "idx": _used,
                    "title": _pseudo["title"],
                    "stops": [m["name"] for m in _mem2],
                    "stops_n": len(_mem2),
                    "span_m": _pseudo["span_m"],
                    "est_walk_m": _w2["total_m"],
                    "est_min": _w2["total_min"],
                    "score": round(_pseudo["score"], 1),
                    "walk_m": _w2["total_m"],
                    "walk_min": _w2["total_min"],
                    "order": ";".join("%s@%.5f,%.5f" % (x["name"], x["lat"], x["lng"]) for x in _sj2),
                    "map_url": _mu2,
                    "map_line": "🗺 路线图：" + _mu2,
                    "supplement": True,
                    "hot_stops": _ranked_in,
                })
                if len(_mem2) == 2:
                    plans[-1]["two_stop"] = True
                    plans[-1]["two_stop_note"] = "这一片只够连成两个点（一条街走完），别硬凑第三站"
                _used += 1
                print(f"[info] 片区太散，补第 {_used} 条方案「{_pseudo['title']}」"
                      f"（{len(_mem2)} 站{'，含榜单点 ' + '、'.join(_ranked_in) if _ranked_in else ''}）",
                      file=sys.stderr)

        _fill_from(tail, False)
        if _used < 3 and hot:
            _fill_from(hot, True)

    clusters = clusters[: a.max_clusters]
    walk = None
    payload_hotels: list[dict[str, Any]] = []
    if a.auto_order and not a.order and clusters:
        ranked = sorted(all_clusters, key=lambda c: (-len(c["members"]), -c["score"]))
        idx = max(0, min(a.cluster_idx, len(ranked) - 1))
        best = ranked[idx]
        if idx != 0:
            print(f"[info] --cluster-idx {idx} → 选第 {idx + 1} 密集的簇「{best['title']}」"
                  f"（共 {len(ranked)} 个簇可选）", file=sys.stderr)
        # 稀疏兜底：这个簇凑不满 3 个点时，先换第二密集的簇试试，
        # 都不行就让简报把「只能凑 N 站 / 建议缩短时长 / 换片区」说清楚。
        def _pts(c):
            return [m for m in c["members"] if m.get("lat") is not None]

        if len(_pts(best)) < 3:
            for j, c in enumerate(ranked):
                if j == idx or len(_pts(c)) < 3:
                    continue
                print(f"[info] 簇「{best['title']}」只有 {len(_pts(best))} 个点，"
                      f"改用它更密的簇「{c['title']}」（{len(_pts(c))} 个点）", file=sys.stderr)
                best = c
                idx = j
                break
            else:
                print(f"[warn] 这一片最多只有 {len(_pts(best))} 个点，撑不满 {a.hours:g} 小时",
                      file=sys.stderr)
        mem = [m for m in best["members"] if m.get("lat") is not None]
        mem.sort(key=lambda m: -m.get("score", 0))
        mem = mem[:4]
        # 就近排序：从出发点最近的那个起，之后每次挑离上一个最近的
        if anchor and mem:
            cur = anchor
            ordered = []
            pool = mem[:]
            while pool:
                nxt = min(pool, key=lambda m: haversine(cur, (m["lat"], m["lng"])))
                ordered.append(nxt)
                pool.remove(nxt)
                cur = (nxt["lat"], nxt["lng"])
            mem = ordered
        a.order = ";".join("%s@%.5f,%.5f" % (m["name"], m["lat"], m["lng"]) for m in mem)
        print(f"[info] --auto-order 用簇「{best['title']}」的 {len(mem)} 个点自动定序", file=sys.stderr)

    # 这些名字在「只跑聚类、不出路线」时也必须存在（否则末尾的 enrich 会 NameError）
    stops: list[dict[str, Any]] = []
    walk: dict[str, Any] | None = None
    payload_hotels: list[dict[str, Any]] = []

    if a.order or a.map:
        byname = {p["name"]: p for p in (pois)}
        raw = (a.order or "").replace("；", ";")
        sep = ";" if (";" in raw or ("@" in raw and "," in raw)) else ","
        order = [x.strip() for x in raw.split(sep) if x.strip()]
        stops = []
        for nm in order:
            hit = lookup_stop(nm, byname)
            if not hit:
                print(f"[warn] --order 里的「{nm}」在候选池里找不到，已跳过", file=sys.stderr)
                continue
            stops.append(hit)
        hot_ll = [[h["lat"], h["lng"]] for h in hot]
        if len(stops) >= 2:
            key = a.amap_key or AMAP_KEY
            walk = plan_route(stops, a.city, key, "walk", {}, hot_ll, a.avoid_hot, None, a.hours)
            print(f"[info] 步行路线 {walk['total_m']} 米 / {walk['total_min']} 分钟"
                  f"（{len(walk['legs'])} 段，全程步行）", file=sys.stderr)
            for i, lg in enumerate(walk["legs"]):
                print(f"[leg {i}] {lg['mode']} {lg['duration']} 分钟 · {lg['reason']}",
                      file=sys.stderr)
            if a.enrich and stops:
                CITY_HINT[:] = [a.city]
                enrich_stops(stops, a.amap_key or AMAP_KEY, a.city)
            if a.map:
                origin = ({"name": anchor_name, "lat": anchor[0], "lng": anchor[1]}
                          if anchor else None)
                if a.hotel:
                    import datetime as _dt0
                    _d0 = a.hotel_date or _dt0.date.today().isoformat()
                    payload_hotels = fetch_hotels(a.city, stops[-1].get("name") or "",
                                                  _d0, a.hotel_top,
                                                  (stops[-1]["lat"], stops[-1]["lng"]))
                write_map_html(a.map, stops, walk, hot, origin, payload_hotels)

        else:
            print("[warn] --order 里能匹配到的点不足 2 个，没有生成路径", file=sys.stderr)

        if a.hotel and stops and not payload_hotels:
            import datetime as _dt
            d = a.hotel_date or _dt.date.today().isoformat()
            payload_hotels = fetch_hotels(a.city, stops[-1].get("name") or "", d, a.hotel_top,
                                          (stops[-1]["lat"], stops[-1]["lng"]))
        else:
            payload_hotels = []

    if a.build_themes_all:
        k = a.amap_key or AMAP_KEY
        cities = THEME_CITIES
        summary = {}
        for c in cities:
            summary[c] = {t: len(build_theme_list(c, t, k, force=True)) for t in THEME_AMAP_KEYWORDS}
            time.sleep(0.4)
        json.dump(summary, sys.stdout, ensure_ascii=False, indent=1)
        return 0

    if a.build_themes:
        k = a.amap_key or AMAP_KEY
        summary = {t: len(build_theme_list(a.city, t, k, force=True)) for t in THEME_AMAP_KEYWORDS}
        json.dump(summary, sys.stdout, ensure_ascii=False, indent=1)
        return 0

    if a.build_culture_all:
        hot = ["杭州", "上海", "北京", "成都", "西安", "南京", "苏州", "广州", "深圳", "厦门"]
        summary = {}
        for c in hot:
            items = build_culture_list(c, a.amap_key or AMAP_KEY, force=True)
            summary[c] = len(items)
            time.sleep(0.5)
        json.dump(summary, sys.stdout, ensure_ascii=False, indent=1)
        return 0

    if a.build_culture:
        items = build_culture_list(a.city, a.amap_key or AMAP_KEY, force=True)
        json.dump({"city": a.city, "count": len(items), "items": items},
                  sys.stdout, ensure_ascii=False, indent=1)
        return 0

    if getattr(a, "dump_stops", False):
        _out = {"city": a.city, "theme": a.theme, "anchor": anchor_name,
                "stops": [{"name": s0.get("name"), "lat": s0.get("lat"), "lng": s0.get("lng")}
                          for s0 in (stops or [])]}
        json.dump(_out, sys.stdout, ensure_ascii=False, indent=1)
        return 0

    if stops and a.enrich:
        CITY_HINT[:] = [a.city]
        enrich_stops(stops, a.amap_key or AMAP_KEY, a.city)

    _mu = build_map_url((a.map_base or os.environ.get("MAP_BASE") or DEFAULT_MAP_BASE),
                        stops, walk)
    if (a.order or a.map) and not _mu and len(stops) >= 2:
        print("[warn] 这次没能拼出 map_url（检查 MAP_BASE / --map-base）", file=sys.stderr)

    sparse_note = None
    if (a.order or a.map) and len(stops) < 3:
        _sug = max(1.0, round(len(stops) * 0.75 * 2) / 2.0)
        _alt = None
        try:
            _ranked = sorted(clusters, key=lambda c: (-len(c["members"]), -c["score"]))
            for c in _ranked:
                if c["title"] != (clusters[0]["title"] if clusters else ""):
                    _alt = c["title"]
                    break
        except Exception:
            pass
        sparse_note = {
            "stops": len(stops),
            "suggest_hours": _sug,
            "alt_cluster": _alt,
            "msg": (f"这一片只凑出 {len(stops)} 个点，撑不满 {a.hours:g} 小时。"
                    f"要么把时长改成 {_sug:g} 小时，要么换到「{_alt}」那一片——"
                    f"两个选项都告诉用户，让他自己挑。") if _alt else
                   (f"这一片只凑出 {len(stops)} 个点，撑不满 {a.hours:g} 小时；"
                    f"建议把时长改成 {_sug:g} 小时。"),
        }

    # 门票口径：给模型一行现成的说法，避免它把 stops[].ticket 当成「没有这个字段」
    _stop_dicts = [{"name": sp.get("name"), "label": sp.get("label"),
                    "lat": sp.get("lat"), "lng": sp.get("lng"),
                    "category": sp.get("category"), "address": sp.get("address"),
                    "tail_score": sp.get("tail_score"), "rank": sp.get("rank"),
                    "free": sp.get("free"), "ticket": sp.get("ticket") or _ticket_of(sp),
                    "hook": sp.get("hook"),
                    "jumpUrl": sp.get("jumpUrl"),
                    "food": sp.get("food") or [], "culture": sp.get("culture") or []}
                   for sp in stops]
    _tks = [d.get("ticket") for d in _stop_dicts]
    _paid = [t for t in _tks if t and str(t.get("price")) not in ("免费", "¥0", "0")]
    _free = [t for t in _tks if t and str(t.get("price")) in ("免费", "¥0", "0")]
    _none = [t for t in _tks if not t]
    if _paid:
        _ps = "、".join(f"{t.get('price')}" for t in _paid[:3])
        _ticket_summary = (f"{len(_stop_dicts)} 站：{len(_paid)} 站收费（{_ps}）、"
                           f"{len(_free)} 站免费、{len(_none)} 站查不到票价。"
                           f"收费的报具体数字，免费的写「免费」，查不到的写「票价无数据，现场买」。")
    elif _free and not _none:
        _ticket_summary = f"{len(_stop_dicts)} 站全部免费。"
    elif _free:
        _ticket_summary = (f"{len(_stop_dicts)} 站：{len(_free)} 站免费、{len(_none)} 站查不到票价；"
                           f"查不到的写「票价无数据，现场买」，别说「引擎不返回票价」。")
    else:
        _ticket_summary = (f"{len(_stop_dicts)} 站都查不到票价：写「票价无数据，现场买」，"
                           f"不要说「引擎不返回票价字段」。")

    # 路网可用性：小县城/小景区常常整片没有可步行的路网数据。这种情况**不出方案、
    # 不出图**，只回一句「这里没有步行路网数据」——比硬画一条不存在的路专业得多。
    _leg_ok = int(ROUTE_STATS.get("leg_ok") or 0)
    _leg_fail = int(ROUTE_STATS.get("leg_fail") or 0)
    # 只有「真的去算过路、而且一次都没算出来」才算没有路网；
    # 点太少（凑不出两站）不算，那是数据稀疏，用 sparse 说明。
    # 一条腿都没取到路网 = 这座城没有步行路网数据：
    # 这时即使靠「长尾点补位」凑出了 2 站的线，也不给方案（图更不会有）。
    network_missing = bool(_leg_ok == 0 and _leg_fail >= 2 and _tried)
    if network_missing and plans:
        _kept = [pl for pl in plans if pl.get("map_url")]
        if not _kept:
            print(f"[info] 没有路网：{len(plans)} 条候选方案全部作废（不画不存在的路）",
                  file=sys.stderr)
            plans = []
            _used = 0
    network_note = None
    if network_missing:
        network_note = (
            "这座城（或这个出发点）没取到任何可步行路网：OSRM 与高德都没有返回路径。"
            "按规矩不生成路线、也不画图——宁可不给，也不编一条地图上不存在的路。"
            "可以建议用户：①换到城区/景区正门再试；②改用「附近有什么」的问法，"
            "只列点不给路线；③到地图上确认这里是否只有车行道路。")
        print("[info] 该区域没有步行路网数据，本轮不生成路线", file=sys.stderr)

    # --brief/--auto-order 这条路径原先根本不查酒店（只有单车道路径查），
    # 用户问「今晚住哪」时只能干瞪眼，这里补上：按第一条方案的终点查。
    hotels_by_plan: list[dict[str, Any]] = []
    if a.hotel and plans:
        import datetime as _dt2
        _d2 = a.hotel_date or _dt2.date.today().isoformat()
        try:
            hotels_by_plan = fetch_hotels_by_plan(a.city, plans, _d2, top=2)
        except Exception as _e2:  # noqa: BLE001
            print(f"[warn] 按方案查酒店跳过：{_e2}", file=sys.stderr)

    if a.hotel and plans and not payload_hotels:
        import datetime as _dt
        _d = a.hotel_date or _dt.date.today().isoformat()
        _ord = (plans[0].get("order") or "").split(";")
        _lt = [x for x in _ord if "@" in x]
        if _lt:
            try:
                _la, _ln = _lt[-1].split("@")[1].split(",")[:2]
                payload_hotels = fetch_hotels(a.city, _lt[-1].split("@")[0], _d,
                                              a.hotel_top, (float(_la), float(_ln)))
            except Exception as _e:  # noqa: BLE001
                print(f"[warn] 终点酒店查询跳过：{_e}", file=sys.stderr)

    payload = {
        "city": a.city, "theme": theme_used, "theme_requested": a.theme,
        "theme_fallback": theme_fallback, "hours": a.hours,
        "anchor": {"name": anchor_name, "lat": anchor[0] if anchor else None,
                   "lng": anchor[1] if anchor else None,
                   "unresolved": anchor_failed},
        "stats": {"poi_total": len(pois), "tail_total": len(tail),
                  "hot_excluded": len(hot), "queries": queries, "deduped": deduped,
                  "flyai_ok": STATS.get("flyai_ok"), "flyai_note": FLYAI_READY.get("note"),
                  "flyai_calls_ok": STATS.get("flyai_calls_ok"),
                  "flyai_calls_fail": STATS.get("flyai_calls_fail")},
        "excluded_hot": hot_ctx[:8],
        "clusters": clusters,
        "walk": walk,
        "stops": _stop_dicts,
        "hotels": payload_hotels if (a.order or a.map or a.hotel) else [],
        "hotels_by_plan": hotels_by_plan if a.hotel else [],
        "map": a.map,
        "static_map": static_map_url(stops, walk, (a.amap_key or AMAP_KEY)) if (walk and stops) else None,
        "map_url": _mu,
        # 给模型一个可以原样抄的一行，省得它「忘了贴地图」
        "map_line": ("🗺 路线图：" + _mu) if _mu else None,
        "sparse": sparse_note,
        "network_missing": network_missing,
        "network_note": network_note,
        "over_walk": bool((walk or {}).get("over_walk")),
        "walk_note": (walk or {}).get("walk_note"),
        "plans": plans,
        "ticket_summary": _ticket_summary,
        # 这次哪块数据没拿到、为什么（风控/额度/试用上限），让回答能如实交代
        "data_issues": DATA_ISSUES,
        # 人话版：额度用尽/风控/确实没有，以及我们改用了什么备选
        "data_reason": data_reason_lines(),
        # 飞猪到底调了几次、命中几次缓存——演示前能判断额度风险
        "flyai_usage": {"calls": STATS.get("calls", 0),
                        "cache_hits": STATS.get("cache_hits", 0),
                        "reason": FLYAI_REASON.get("kind") or ""},
    }
    # P1-4：只有两站的方案，替用户挑一个「顺路能补上」的点（不塞进路线，只给建议）。
    # 两站的方案本来就撑不满时长，光说「只够两站」不如再给个具体去处。
    try:
        for _pl in (payload.get("plans") or []):
            # 每条方案都带 order = "名字@纬度,经度;..."，比 stops 更好解析（stops 里可能是字符串）
            _ord = _pl.get("order") or ""
            _pts2: list[tuple[float, float, str]] = []
            for _seg in _ord.split(";"):
                _nm2, _, _co = _seg.partition("@")
                if not _co:
                    continue
                try:
                    _la, _ln = [float(v) for v in _co.split(",")[:2]]
                except ValueError:
                    continue
                _pts2.append((_la, _ln, _nm2.strip()))
            if len(_pts2) != 2:
                continue
            _la2, _ln2, _nm_last = _pts2[-1]
            _used_names = {x[2] for x in _pts2}
            _pool = [m for m in (locals().get("pois") or []) if isinstance(m, dict)] or \
                    [m for c in _ranked_all for m in c["members"] if isinstance(m, dict)]
            if os.environ.get("DETOUR_DEBUG"):
                print("[debug] two_stop pool=%d last=%s" % (len(_pool), _nm_last), file=sys.stderr)
            # 优先推荐「不在榜单上」的点：这产品的立场就是不把人往网红堆里送
            _cands: list[tuple[float, dict[str, Any]]] = []
            for _m in _pool:
                if _m.get("name") in _used_names or _m.get("lat") is None:
                    continue
                _d = haversine((_la2, _ln2), (_m["lat"], _m["lng"]))
                if _d < 60 or _d > 1600:
                    continue
                _cands.append((_d, _m))
            _tail_c = [c for c in _cands if not c[1].get("listRank")]
            _pick = min(_tail_c or _cands, key=lambda c: c[0]) if _cands else None
            _best, _best_d = (_pick[1], _pick[0]) if _pick else (None, None)
            if _best and _best_d is not None:
                _pl["two_stop_suggest"] = {
                    "name": _best.get("name"),
                    "dist_m": int(round(_best_d)),
                    "note": "顺路还能补一个点，走过去约 %d m，这样就不止两站了" % int(round(_best_d)),
                }
                print("[info] 两站方案补建议：%s（%d m）" % (_best.get("name"), int(round(_best_d))),
                      file=sys.stderr)
    except Exception as _e:  # noqa: BLE001
        print("[warn] 两站建议生成失败：%s" % _e, file=sys.stderr)

    if a.brief:
        brief = {
            "city": payload["city"], "theme": payload["theme"], "hours": payload["hours"],
            "anchor": payload["anchor"], "theme_fallback": payload.get("theme_fallback"),
            "stats": {k: payload["stats"][k] for k in
                      ("poi_total", "hot_excluded", "flyai_ok", "flyai_calls_ok",
                       "flyai_calls_fail") if k in payload["stats"]},
            "excluded_hot": payload["excluded_hot"],
            "sparse": payload["sparse"],
            "ticket_summary": payload["ticket_summary"],
            "network_missing": network_missing,
            "network_note": network_note,
            "nearby_note": _nearby_note(),
            "nearby_source": _nearby_source(),
            # 每条方案各自终点的酒店（各 2 家）；飞猪挂了就退高德（只有名字+距离）
            "hotels_by_plan": payload.get("hotels_by_plan") or [],
            # 酒店：飞猪挂了就退高德（只有名字+距离，价格为空，让回答如实说）
            "hotels": [{"name": h.get("name"), "price": h.get("price"),
                        "rate": h.get("rate"), "star": h.get("star"),
                        "dist_m": h.get("dist_m"), "src": h.get("src"),
                        "bookUrl": h.get("bookUrl")}
                       for h in (payload.get("hotels") or [])][:3],
            # 这次哪块数据没拿到、为什么——回答里要如实交代
            "data_issues": payload.get("data_issues") or [],
            "data_reason": payload.get("data_reason") or [],
            "flyai_usage": payload.get("flyai_usage") or {},
            "plans": [{"idx": p.get("idx"), "title": p.get("title"),
                       "stops_n": p.get("stops_n"),
                       "stops": [x.get("name") if isinstance(x, dict) else x
                                 for x in (p.get("stops") or [])],
                       "span_m": p.get("span_m"), "walk_m": p.get("walk_m"),
                       "walk_min": p.get("walk_min"), "order": p.get("order"),
                       "map_line": p.get("map_line"),
                       "map_url": p.get("map_url"),
                       "over_walk": p.get("over_walk"),
                       "walk_note": p.get("walk_note"),
                       # 下面这几项以前被 brief 的字段白名单漏掉了，
                       # 结果模型永远看不到「只够两站」「怎么到出发点」「是否含榜点」
                       "two_stop": p.get("two_stop") or None,
                       "two_stop_note": p.get("two_stop_note"),
                       "two_stop_suggest": p.get("two_stop_suggest") or None,
                       "access_note": p.get("access_note"),
                       "supplement": p.get("supplement") or None,
                       "hot_stops": p.get("hot_stops") or None}
                      for p in (payload.get("plans") or [])],
            "hint": ("首轮直接用上面 3 条 plans（每条自带 map_line），不要再跑引擎；"
                     "用户选定某个方案后，才用 --cluster-idx <idx> 跑一次取明细。"),
        }
        json.dump(brief, sys.stdout, ensure_ascii=False, indent=1)
        return 0

    if a.json_only:
        json.dump(payload, sys.stdout, ensure_ascii=False, indent=1)
        return 0

    print(to_briefing(a.city, theme_used, a.hours, anchor_name, clusters, queries,
                      hot_ctx, anchor_failed, deduped,
                      plans, _ticket_summary, theme_fallback, sparse_note))
    print("\n--- JSON ---")
    json.dump(payload, sys.stdout, ensure_ascii=False, indent=1)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
