#!/usr/bin/env python3
"""重建指定城市的「动漫 / 非遗」主题点库（走飞猪 search-poi，不消耗高德搜索额度）。

用法：
    python3 scripts/rebuild_theme_packs.py 杭州 [--themes 动漫 非遗] [--dry-run]

产物写进 skill-package-engine/data/themes/<theme>_<city>.json 与 data/poi/ 同名文件，
之后重新打包技能包即可让云端生效。
"""
import argparse
import json
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
PKG = os.path.join(ROOT, "skill-package-engine", "data")

# 关键词按「人群 / 场景」拆，比平台类目更贴近真实需求
KEYWORDS = {
    "动漫": ["手办", "谷子", "潮玩", "漫展", "电玩城", "桌游", "剧本杀", "娃娃机"],
    "非遗": ["非遗", "手作", "老字号", "扇庄", "剪刀", "绸庄", "茶庄", "篆刻"],
}


def flyai_poi(city, kw):
    """调 CLI：flyai search-poi --city-name <city> --keyword <kw>"""
    cmd = ["flyai", "search-poi", "--city-name", city, "--keyword", kw]
    try:
        out = subprocess.run(cmd, capture_output=True, text=True, timeout=90).stdout
    except Exception as e:
        print("  ! %s 调用失败：%s" % (kw, e), file=sys.stderr)
        return []
    try:
        data = json.loads(out)
    except Exception:
        return []
    items = ((data.get("data") or {}).get("itemList")) or []
    res = []
    for it in items:
        try:
            lat = float(it.get("latitude") or it.get("lat"))
            lng = float(it.get("longitude") or it.get("lng"))
        except Exception:
            continue
        res.append({"name": (it.get("name") or "").strip(), "lat": lat, "lng": lng,
                    "address": it.get("address") or "",
                    "category": it.get("categoryName") or "",
                    "listRank": it.get("listRank")})
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("city")
    ap.add_argument("--themes", nargs="*", default=["动漫", "非遗"])
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()

    for theme in a.themes:
        kws = KEYWORDS.get(theme) or []
        seen, out = set(), []
        print("[%s·%s] 关键词 %d 个" % (a.city, theme, len(kws)))
        for kw in kws:
            got = flyai_poi(a.city, kw)
            print("  %-6s → %d 个" % (kw, len(got)))
            for it in got:
                if not it["name"] or it["name"] in seen:
                    continue
                seen.add(it["name"])
                out.append(it)
        print("  合计 %d 个点" % len(out))
        if a.dry_run:
            continue
        for d in ("themes", "poi"):
            fp = os.path.join(PKG, d, "%s_%s.json" % (theme, a.city))
            json.dump(out, open(fp, "w", encoding="utf-8"), ensure_ascii=False)
            print("  写入", fp)
    return 0


if __name__ == "__main__":
    sys.exit(main())
